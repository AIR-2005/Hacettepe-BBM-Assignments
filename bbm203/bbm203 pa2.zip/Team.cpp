#include "Team.h"

Team::Team()
    : teamID(-1),
      maxLoadCapacity(0),
      currentWorkload(0),
      missionStack(4) {
}

Team::Team(int id, int maxLoad)
    : teamID(id),
      maxLoadCapacity(maxLoad),
      currentWorkload(0),
      missionStack(4) {
}

int Team::getId() const {
    return teamID;
}

int Team::getMaxLoadCapacity() const {
    return maxLoadCapacity;
}

int Team::getCurrentWorkload() const {
    return currentWorkload;
}

void Team::setId(int id) {
    teamID = id;
}

void Team::setMaxLoadCapacity(int maxLoad) {
    maxLoadCapacity = maxLoad;
}

bool Team::hasActiveMission() const {
    return !missionStack.isEmpty();
}

bool Team::tryAssignRequest(const Request& req) {
    //Implement tryAssignRequest function as explained in the PDF.
    (void)req;
    if(req.computeWorkloadContribution() + getCurrentWorkload() > getMaxLoadCapacity()){
        return false;
    }
    else{
        currentWorkload += req.computeWorkloadContribution();
        return missionStack.push(req);
    }
}

void Team::rollbackMission(RequestQueue& supplyQueue, RequestQueue& rescueQueue) {
    //Implement rollbackMission function as explained in the PDF.
    (void)supplyQueue;
    (void)rescueQueue;
    Request curr;
    int s = 0;
    int r = 0;
    int quS = 0;
    int quR = 0;
    Request quSArr[supplyQueue.getCapacity()];
    Request quRArr[rescueQueue.getCapacity()];
    Request sArr[missionStack.getCapacity()];
    Request rArr[missionStack.getCapacity()];
    while (!supplyQueue.isEmpty())
    {
        supplyQueue.dequeue(curr);
        quSArr[quS++] = curr;
    }
    while (!rescueQueue.isEmpty())
    {
        rescueQueue.dequeue(curr);
        quRArr[quR++] = curr;
    }
    while(hasActiveMission()){
        missionStack.pop(curr);
        if(curr.getType() == "SUPPLY"){
            sArr[s++] = curr;
        }
        else if(curr.getType() == "RESCUE"){
            rArr[r++] = curr;
        }
    }
    for (int i = s - 1; i >= 0; i--)
    {
        supplyQueue.enqueue(sArr[i]);
    }
    for (int i = 0; i < quS; i++)
    {
        supplyQueue.enqueue(quSArr[i]);
    }
    for (int i = r - 1; i >= 0; i--)
    {
        rescueQueue.enqueue(rArr[i]);
    }
    for (int i = 0; i < quR; i++)
    {
        rescueQueue.enqueue(quRArr[i]);
    }
    currentWorkload = 0;
}

void Team::clearMission() {
    missionStack.clear();
    currentWorkload = 0;
}

const MissionStack& Team::getMissionStack() const {
    return missionStack;
}
