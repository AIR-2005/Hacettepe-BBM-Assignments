#include "RequestQueue.h"
#include <new> // for std::nothrow

RequestQueue::RequestQueue()
    : data(nullptr),
      capacity(0),
      front(0),
      rear(0),
      count(0) {
    // start with a small default capacity
    resize(4);
}

RequestQueue::RequestQueue(int initialCapacity)
    : data(nullptr),
      capacity(0),
      front(0),
      rear(0),
      count(0) {
    if (initialCapacity < 1) {
        initialCapacity = 4;
    }
    resize(initialCapacity);
}

RequestQueue::~RequestQueue() {
    delete[] data;
}

bool RequestQueue::isEmpty() const {
    return count == 0;
}

bool RequestQueue::isFull() const {
    return count == capacity;
}

int RequestQueue::size() const {
    return count;
}

int RequestQueue::nextIndex(int idx) const {
    if (capacity == 0) return 0;
    return (idx + 1) % capacity;
}

bool RequestQueue::enqueue(const Request& req) {
    //Implement enqueue function as explained in the PDF.
    if(isFull()){
        resize(capacity * 2);
        rear = nextIndex(rear);
    }
    else if(!isEmpty()){
        rear = nextIndex(rear);
    }
    data[rear] = req;
    count++;
    return true;
}

bool RequestQueue::dequeue(Request& outReq) {
    //Implement dequeue function as explained in the PDF.
    if(!isEmpty()){
        outReq = data[front];
        if (count == 1)
        {
            rear = 0;
            front = 0;
        }
        else{
            front = nextIndex(front);
        }
        count--;
        return true;
    }
    return false;
}

bool RequestQueue::peek(Request& outReq) const {
    //Implement peek function as explained in the PDF.
    if (isEmpty())
    {
        return false;
    }
    outReq = data[front];
    return true;
}

void RequestQueue::clear() {
    front = 0;
    rear = 0;
    count = 0;
}


bool RequestQueue::removeById(const std::string& id) {
    //Implement removeById function as explained in the PDF.
    if (isEmpty())
    {
        return false;
    }
    
    int i = front;
    bool found = false;
    while (i != rear)
    {
        if (data[i].getId() == id)
        {
            found = true;
            break;
        }
        i = nextIndex(i);
    }
    if (data[i].getId() == id)
    {
        found = true;
    }

    if (!found)
    {
        return false;
    }

    if ((count == 1) && (i == front))
    {
        front = 0;
        rear = 0;
    }
    else if ((front == i))
    {
        front = nextIndex(front);
    }
    else{
        for (int j = i; j != rear; j = nextIndex(j))
        {
            data[j] = data[nextIndex(j)];
        }
        if (rear != 0)
        {
            rear = (rear - 1) % (capacity);
        }
    }
    count--;
    return true;
}


bool RequestQueue::resize(int newCapacity) {
    //Implement resize function as explained in the PDF.
    Request *temp = data;
    data = new Request[newCapacity];
    if (!isEmpty())
    {
        for(int i = 0; i < count; i++){
            data[i] = temp[(front+i) % capacity];
        }
        delete[] temp;
        front = 0;
        rear = count - 1;
    }
    capacity = newCapacity;
    return true;
}
