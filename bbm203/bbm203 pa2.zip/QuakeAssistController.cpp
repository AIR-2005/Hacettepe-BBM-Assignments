#include "QuakeAssistController.h"
#include <iostream>
#include <sstream>

QuakeAssistController::QuakeAssistController()
    : teams(nullptr),
      teamCount(0),
      supplyQueue(4),
      rescueQueue(4) {
}

QuakeAssistController::~QuakeAssistController() {
    delete[] teams;
}

bool QuakeAssistController::parseAndExecute(const std::string& line) {
    //Read the input file line by line and execute realtime.
    std::istringstream split(line);

    //Get command
    std::string command;
    split >> command;
    
    if (command == "INIT_TEAMS")
    {
        int numTeams;
        if (!(split >> numTeams))
        {
            return false;
        }
        return initializeTeams(numTeams);
    }
    else if(command == "SET_TEAM_CAPACITY"){
        int teamId;
        int maxLoadCapacity;
        if (!(split >> teamId >> maxLoadCapacity))
        {
            return false;
        }
        return handleSetTeamCapacity(teamId,maxLoadCapacity);
    }
    else if(command == "ADD_SUPPLY"){
        std::string id;
        std::string city;
        std::string supplyType;
        int amount;
        int emergencyLevel;
        if (!(split >> id >> city >> supplyType >> amount >> emergencyLevel))
        {
            return false;
        }
        return handleAddSupply(id,city,supplyType,amount,emergencyLevel);
    }
    else if(command == "ADD_RESCUE"){
        std::string id;
        std::string city;
        int numPeople;
        std::string buildingRisk;
        int emergencyLevel;
        if (!(split >> id >> city >> numPeople >> buildingRisk >> emergencyLevel))
        {
            return false;
        }
        return handleAddRescue(id,city,numPeople,buildingRisk,emergencyLevel);
    }
    else if(command == "REMOVE_REQUEST"){
        std::string id;
        if (!(split >> id))
        {
            return false;
        }
        return handleRemoveRequest(id);
    }
    else if(command == "HANDLE_EMERGENCY"){
        int teamId;
        int k;
        if (!(split >> teamId >> k))
        {
            return false;
        }
        return handleHandleEmergency(teamId,k);
    }
    else if(command == "DISPATCH_TEAM"){
        int teamId;
        if (!(split >> teamId))
        {
            return false;
        }
        return handleDispatchTeam(teamId);
    }
    else if(command == "PRINT_QUEUES"){
        printQueues();
        return true;
    }
    else if(command == "PRINT_TEAM"){
        int teamId;
        if (!(split >> teamId))
        {
            return false;
        }
        printTeam(teamId);
        return true;
    }
    else if(command == "CLEAR"){
        clear();
        return true;
    }
    else{
        std::cout << "Error: Unknown command '" << command << "'." << std::endl;
        return true;
    }
}

bool QuakeAssistController::initializeTeams(int numTeams) {
    //Create a team array and initialize it with teams.
    supplyQueue.clear();
    rescueQueue.clear();
    teams = new Team[numTeams];
    for(int i = 0; i < numTeams; i++){
        teams[i].setId(i);
    }
    teamCount = numTeams;
    std::cout << "Initialized " << numTeams << " teams." << std::endl;
    return true;
}

int QuakeAssistController::findTeamIndexById(int teamId) const {
    //Find the index of the team using teamId.
    for(int i = 0; i < teamCount; i++){
        if(teams[i].getId() == teamId){
            return i;
        }
    }
    return -1;
}

bool QuakeAssistController::handleSetTeamCapacity(int teamId, int capacity) {
    //Find the index of team in the array, update the capacity value of the team.
    int index = findTeamIndexById(teamId);
    if (index == -1)
    {
        std::cout << "Error: Team " << teamId << " not found." << std::endl;
        return true;
    }
    teams[index].setMaxLoadCapacity(capacity);
    std::cout << "Team " << teamId << " capacity set to " << capacity << "." << std::endl;
    return true;
}

bool QuakeAssistController::handleAddSupply(const std::string& id,
                                            const std::string& cityStr,
                                            const std::string& supplyTypeStr,
                                            int amount,
                                            int emergencyLevel) {
    //Create new supply request, and add it to the SUPPLY queue.
    Request newReq = Request(id,cityStr,supplyTypeStr,amount,emergencyLevel);
    bool add = supplyQueue.enqueue(newReq);
    std::cout << "Request " << newReq.getId() << " added to SUPPLY queue." << std::endl;
    return add;
}

bool QuakeAssistController::handleAddRescue(const std::string& id,
                                            const std::string& cityStr,
                                            int numPeople,
                                            const std::string& riskStr,
                                            int emergencyLevel) {
    //Create new rescue request, and add it to the RESCUE queue.
    Request newReq = Request(id,cityStr,numPeople,riskStr,emergencyLevel);
    bool add = rescueQueue.enqueue(newReq);
    std::cout << "Request " << newReq.getId() << " added to RESCUE queue." << std::endl;
    return add;
}

bool QuakeAssistController::handleRemoveRequest(const std::string& id) {
    //Remove request using request ID from request(SUPPLY, RESCUE) queue. 
    if(supplyQueue.removeById(id) || rescueQueue.removeById(id)){
        std::cout << "Request " << id << " removed from queues." << std::endl;
        return true;
    }
    else{
        std::cout << "Error: Request " << id << " not found." << std::endl;
        return true;
    }
}

bool QuakeAssistController::handleHandleEmergency(int teamId, int k) {
    // TODO: Implement:
    // 1) Find team by id.
    // 2) For up to k steps:
    //    - Look at front of supplyQueue and rescueQueue using peek().
    //    - Use Request::computeEmergencyScore() to decide which to take.
    //    - If both empty -> break.
    //    - Try teams[teamIdx].tryAssignRequest(chosenRequest).
    //       * If this returns false, print overload message and
    //         call teams[teamIdx].rollbackMission(supplyQueue, rescueQueue),
    //         then break.
    //       * Else, dequeue chosen request from its queue and continue.
    int supplyCount = 0;
    int rescueCount = 0;
    int index = findTeamIndexById(teamId);
    if (index == -1)
    {
        std::cout << "Error: Team " << teamId << " not found." << std::endl;
        return true;
    }
    bool rollBool = false;
    for (int i = 0; i < k; i++)
    {
        Request supplyFront;
        Request rescueFront;
        if (!supplyQueue.peek(supplyFront) && !rescueQueue.peek(rescueFront))
        {
            break;
        }
        supplyQueue.peek(supplyFront);
        rescueQueue.peek(rescueFront);
        int supplyScore = supplyFront.computeEmergencyScore();
        int rescueScore = rescueFront.computeEmergencyScore();
        if(supplyScore > rescueScore || rescueQueue.isEmpty())
        {
            bool assignBool = teams[index].tryAssignRequest(supplyFront);
            if (!assignBool)
            {
                std::cout << "Overload on Team " << teamId << ": rolling back mission." << std::endl;
                teams[index].rollbackMission(supplyQueue,rescueQueue);
                rollBool = true;
                break;
            }
            else{
                supplyQueue.dequeue(supplyFront);
                supplyCount++;
            }
        }
        else if(supplyScore <= rescueScore || supplyQueue.isEmpty()){
            bool assignBool = teams[index].tryAssignRequest(rescueFront);
            if (!assignBool)
            {
                std::cout << "Overload on Team " << teamId << ": rolling back mission." << std::endl;
                teams[index].rollbackMission(supplyQueue,rescueQueue);
                rollBool = true;
                break;
            }
            else{
                rescueQueue.dequeue(rescueFront);
                rescueCount++;
            }
        }
    }
    if (!rollBool)
    {
        std::cout << "Team "<< teamId << " assigned " << rescueCount + supplyCount << " requests ("<< supplyCount << " SUPPLY, " << rescueCount <<" RESCUE), total workload "<< teams[index].getCurrentWorkload() << "." << std::endl;
    }
    return true;
}

bool QuakeAssistController::handleDispatchTeam(int teamId) {
    int idx = findTeamIndexById(teamId);
    if (idx == -1) {
        std::cout << "Error: Team " << teamId << " not found." << std::endl;
        return true;
    }
    Team& t = teams[idx];
    if (!t.hasActiveMission()) {
        std::cout << "Error: Team " << teamId << " has no active mission." << std::endl;
        return true;
    }
    int workload = t.getCurrentWorkload();
    std::cout << "Team " << teamId << " dispatched with workload " << workload << "." << std::endl;
    t.clearMission();
    return true;
}

void QuakeAssistController::printQueues() const {
    //Print queues.
    int index;
    int supplyCount = supplyQueue.getCount();
    int front = supplyQueue.getFrontIndex();
    int cap = supplyQueue.getCapacity();
    Request *supplyData = supplyQueue.getData();
    std::cout << "SUPPLY QUEUE:" << std::endl;
    for (int i = 0; i < supplyCount; i++)
    {
        index = (front + i) % cap;
        std::cout << supplyData[index].getId() << " " << supplyData[index].getCity() << " " << supplyData[index].getSupplyType() << " " << supplyData[index].getAmount() << " " << supplyData[index].getEmergencyLevel() << std::endl;
    }
    int rescueCount = rescueQueue.getCount();
    front = rescueQueue.getFrontIndex();
    cap = rescueQueue.getCapacity();
    Request *rescueData = rescueQueue.getData();
    std::cout << "RESCUE QUEUE:" << std::endl;
    for (int i = 0; i < rescueCount; i++)
    {
        index = (front + i) % cap;
        std::cout << rescueData[index].getId() << " " << rescueData[index].getCity() << " " << rescueData[index].getNumPeople() << " " << rescueData[index].getRisk() << " " << rescueData[index].getEmergencyLevel() << std::endl;
    }
}

void QuakeAssistController::printTeam(int teamId) const {
    //Print team data using teamId.
    int index = findTeamIndexById(teamId);
    if (index == -1)
    {
        std::cout << "Error: Team " << teamId << " not found." << std::endl;
        return;
    }
    Request *data = teams[index].getMissionStack().getData();
    int size = teams[index].getMissionStack().size();
    std::cout << "TEAM " << teamId << " STACK:" << std::endl;
    for (int i = size - 1; i >= 0; i--)
    {
        Request req = data[i];
        if (req.getType() == "SUPPLY")
        {
            std::cout << req.getId() << " " << req.getCity() << " " << req.getSupplyType() << " " << req.getAmount() << " " << req.getEmergencyLevel() << std::endl;
        }
        else if (req.getType() == "RESCUE")
        {
            std::cout << req.getId() << " " << req.getCity() << " " << req.getNumPeople() << " " << req.getRisk() << " " << req.getEmergencyLevel() << std::endl;
        }
    }
}

void QuakeAssistController::clear() {
    //Clear data.
    supplyQueue.clear();
    rescueQueue.clear();
    for (int i = 0; i < teamCount; i++)
    {
        teams[i].clearMission();
    }
    std::cout << "System cleared." << std::endl;
}
