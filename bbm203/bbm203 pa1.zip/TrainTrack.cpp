#include "TrainTrack.h"
#include <iostream>

bool TrainTrack::autoDispatch = false;

TrainTrack::TrainTrack()
    : firstLocomotive(nullptr),
      lastLocomotive(nullptr),
      destination(Destination::OTHERS),
      totalWeight(0), trainCounter(0)
{
}

TrainTrack::TrainTrack(Destination _dest)
    : firstLocomotive(nullptr),
      lastLocomotive(nullptr),
      destination(_dest),
      totalWeight(0), trainCounter(0)
{
}

TrainTrack::~TrainTrack()
{
    // TODO: If track is deconstucting, 
    // depart all of the trains
    // Handle pointers as necessary
    Train *t = firstLocomotive;
    this->firstLocomotive = nullptr;
    this->lastLocomotive = nullptr;
    /*
    while (t)
    {
        Train *temp = t;
        t = t->getNext();
        delete temp;
    }
    */
}

// Given to you ready
std::string TrainTrack::generateTrainName()
{
    ++trainCounter;
    return "Train_" + destinationToString(destination) + "_" + std::to_string(trainCounter);
}

void TrainTrack::addTrain(Train *train)
{
    // TODO: Add a train to the end (rear) of this track

    //If track is empty
    if(isEmpty()){
        //Set first locomotive to given train
        this->firstLocomotive = train;
    }
    //Else
    else{
        //Set last train's next to given train
        this->getLast()->setNext(train);
    }
    //Set last locomotive to given train
    this->lastLocomotive = train;
    //Add given train's weight to total weight
    this->totalWeight += train->getTotalWeight();

    // TODO: Hadle Auto-dispatch rule:
    //   If adding this train causes AUTO_DISPATCH_LIMIT to overflow
    //   and auto-dispatch is enabled, repeatedly dispatch (depart) trains
    //   from the front until there is enough capacity.
    //      use: std::cout << "Auto-dispatch: departing " << departed->getName() << " to make room.\n";
    while (this->totalWeight > AUTO_DISPATCH_LIMIT && autoDispatch)
    {
        Train *t = departTrain();
        std::cout << "Auto-dispatch: departing " << t->getName() << " to make room.\n";
        delete t;
    }
}

Train *TrainTrack::departTrain()
{
    // TODO: Remove the first train (front of the track) and return it.
    // use: std::cout << "Train " << removed->name << " departed from Track " << destinationToString(destination) << "." << std::endl;

    //Get first train
    Train *first = this->getFirst();
    //If there is a first train
    if(first){
        //If first train is also last train
        if (first == this->getLast())
        {
            //Set last locomotive to null
            this->lastLocomotive = nullptr;
        }
        //Remove first trains's weight from total weight
        this->totalWeight -= first->getTotalWeight();
        //Set first locomotive to first train's next train
        this->firstLocomotive = first->getNext();
        //Set first train's next train to nullptr
        first->setNext(nullptr);
        //Print message
        std::cout << "Train " << first->getName() << " departed from Track " << destinationToString(destination) << "." << std::endl;
        //Return first train
        return first;
    }
    //Else(there isn't a first train)
    else{
        //Return nullptr
        return nullptr;
    }
}

bool TrainTrack::isEmpty() const
{
    // TODO: Return true if there are no trains on this track.
    //If can't get first or last locomotive, return true
    if(!this->firstLocomotive && !this->lastLocomotive){
        return true;
    }
    //Else
    else{
        //Return false
        return false;
    }
}


Train *TrainTrack::findTrain(const std::string &name) const
{
    // TODO: Search for a train by name.
    // Return pointer to train if found, nullptr otherwise.
    //Set train to first train
    Train *train = this->getFirst();
    //While there is train
    while (train)
    {
        //If train has wanted name, return train
        if(train->getName() == name){
            return train;
        }
        //Else move to next train
        else{
            train = train->getNext();
        }
    }
    //Return nullptr if can't find train
    return nullptr;
}

// Given to you ready
void TrainTrack::printTrack() const
{

    if (isEmpty())
        return;

    Train *current = firstLocomotive;

    std::cout << "[Track " << static_cast<int>(firstLocomotive->destination) << "] ";
    while (current)
    {
        std::cout << current->getName() << "(" << current->getTotalWeight() << "ton)-" << current->wagons << " -> ";
        current = current->getNext();
    }
    std::cout << std::endl;
    return;
}