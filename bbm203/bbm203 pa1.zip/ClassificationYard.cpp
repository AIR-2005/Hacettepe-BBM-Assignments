#include "ClassificationYard.h"
#include <iostream>

ClassificationYard::ClassificationYard() {}
ClassificationYard::~ClassificationYard() { clear(); }

WagonList &ClassificationYard::getBlockTrain(int destination, int cargoType)
{
    return blockTrains[destination][cargoType];
}

WagonList *ClassificationYard::getBlocksFor(Destination dest)
{
    return blockTrains[static_cast<int>(dest)];
}

// Inserts vagon to the correct place at the yard
void ClassificationYard::insertWagon(Wagon *w)
{
    if (!w)
        return;
    int dest = static_cast<int>(w->getDestination());
    int cargo = static_cast<int>(w->getCargoType());
    blockTrains[dest][cargo].insertSorted(w);
}

// Merges multiple blocks into a train while keeping blocks grouped
Train *ClassificationYard::assembleTrain(Destination dest, const std::string &trainName)
{
    // TODO: Collect wagons of the same destination and assemble them into a single Train.

    /**
     * - Blocks of the same cargo type must remain grouped together.
     * - These groups must be appended to the train in descending order
     *   based on their heaviest wagon.
     * - Hazardous cargo (e.g., OIL) must always be placed at the very end of the train,
     *   and only one hazardous block can be included per train.*/

    //Set new train, train wagon list and hazardous wagon
    Train *newTrain = new Train(trainName, dest);
    WagonList trainWagons = WagonList();
    Wagon *addHaz = nullptr;
    //For each cargo type
    for (int i = 0; i < NUM_CARGOTYPES_INT; i++){
        //Get the current wagon list for given destination and current cargo type
        WagonList &currDestCargo = getBlockTrain(static_cast<int>(dest), i);
        //If cargo type is hazardous
        if(i == static_cast<int>(CargoType::HAZARDOUS) && currDestCargo.getFront()){
            //Set hazardous wagon to front of hazardous wagon list
            addHaz = currDestCargo.detachById(currDestCargo.getFront()->getID());
        }
        //Else
        else{
            //Add current wagon list to train's wagon list
            trainWagons.appendList(std::move(currDestCargo));
        }
    }
    //If there is a hazardous wagon 
    if(addHaz){
        //Add it to train's wagon list's rear
        trainWagons.addWagonToRear(addHaz);
    }
    //Add train's wagon list to new train
    newTrain->appendWagonList(trainWagons);
    //Return new train
    return newTrain;
}

bool ClassificationYard::isEmpty() const
{
    /** TODO: Check if the entire classification yard is empty.
     *
     * The yard is empty if every blockTrain list for all destination-cargo pairs is empty.
     */

    //For each destination
    for(int i = 0; i < NUM_DESTINATIONS_INT; i++){
        //For each cargo type
        for (int j = 0; j < NUM_CARGOTYPES_INT; j++)
        {
            //If current block is not empty
            if(!blockTrains[i][j].isEmpty()){
                //Return false
                return false;
            }
        } 
    }
    //If no block is found, return true
    return true;
}

void ClassificationYard::clear()
{
    /** TODO: Clear all wagons from the classification yard.
     *
     * Used when resetting or ending the simulation.
     */

    //For each destination
    for(int i = 0; i < NUM_DESTINATIONS_INT; i++){
        //For each cargo type
        for (int j = 0; j < NUM_CARGOTYPES_INT; j++)
        {
            //Clear wagon list in current block
            blockTrains[i][j].clear();
        } 
    } 
}

// Print function is already implemented to keep output uniform
void ClassificationYard::print() const
{
    for (int i = 0; i < static_cast<int>(Destination::NUM_DESTINATIONS); ++i)
    {
        auto dest = destinationToString(static_cast<Destination>(i));
        std::cout << "Destination " << dest << ":\n";
        for (int j = 0; j < static_cast<int>(CargoType::NUM_CARGOTYPES); ++j)
        {
            if (!blockTrains[i][j].isEmpty())
            {
                auto type = cargoTypeToString(static_cast<CargoType>(j));
                std::cout << "  CargoType " << type << ": ";
                blockTrains[i][j].print();
            }
        }
    }
}