#include "Train.h"
#include <iostream>

Train::Train() : name(""), destination(Destination::OTHERS), totalWeight(0), nextLocomotive(nullptr) {}
Train::Train(const std::string &_name, Destination _dest) : name(_name), destination(_dest), totalWeight(0), nextLocomotive(nullptr) {}
Train::~Train() { clear(); }

// This function is given to you ready
void Train::appendWagonList(WagonList &wl)
{
    // Makes appendList use move semantics
    wagons.appendList(std::move(wl));
    totalWeight = wagons.getTotalWeight();
}

// This function is given to you ready
void Train::addWagonToRear(Wagon *w)
{
    wagons.addWagonToRear(w);
    totalWeight = wagons.getTotalWeight();
}

void Train::clear()
{ 
    //TODO: Do the cleaning as necesssary
    this->wagons.clear();
    this->nextLocomotive = nullptr;
    this->totalWeight = 0;
}

// This function is given to you ready
void Train::print() const
{
    std::cout << "Train " << name << " (" << totalWeight << " tons): ";
    std::cout << wagons << std::endl;
}

Train *Train::verifyCouplersAndSplit(int splitCounter)
{

    // TODO: Verify whether any wagon’s coupler is overloaded.
    // You must traverse from the rear (backmost wagon) toward the front.
    //
    // Splitting rule:
    // Split the train AFTER the overloaded wagon (the overloaded one stays).
    // Use WagonList::splitAtById to detach the overloaded segment into a new WagonList.
    //
    // If no overload occurs, return nullptr (no split needed).
    //
    // If a valid split occurs:
    // new Train should be named "<oldName>_split_<splitCounter>".
    // print message
    // std::cout << "Train " << name << " split due to coupler overload before Wagon " << splitId << std::endl;
    // std::cout << newTrain->wagons << std::endl;

    //Set current wagon to rear wagon
    Wagon *currWag = wagons.getRear();
    //Set previous weight(weight after current wagon) to 0
    int preWeight = 0;
    //While there is current wagon
    while (currWag && currWag->getPrev()){
        //Add current wagon's weight to previous weight
        preWeight += currWag->getWeight();
        //Set current wagon to wagon before current wagon
        Wagon *prev = currWag->getPrev();
        //If previous weight is greater than max coupler load
        if (preWeight > prev->getMaxCouplerLoad()){
            //Split wagon list to two and set new train's list from next wagon to end
            WagonList newWagonList = this->wagons.splitAtById(currWag->getID());
            //Remove previous weight from total weight
            this->totalWeight -= preWeight;
            //Create new train and add new wagon list to it
            Train *newTrain = new Train(this->getName() + "_split_" + std::to_string(splitCounter), this->getDestination());
            newTrain->appendWagonList(newWagonList);
            //Print message
            std::cout << "Train " << name << " split due to coupler overload before Wagon " << currWag->getID() << std::endl;
            std::cout << newTrain->getWagons() << std::endl;
            //Return new train
            return newTrain;
        }
        currWag = prev;
    }
    
    //Return nullptr if no split occurs
    return nullptr;
    
}