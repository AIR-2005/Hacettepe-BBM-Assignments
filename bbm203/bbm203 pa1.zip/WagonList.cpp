#include "WagonList.h"

#include <iostream>

WagonList::~WagonList() { clear(); }

void WagonList::clear()
{
    // TODO: Delete all Wagon objects in this list and reset pointers.
    Wagon *w = this->getFront();
    while (w)
    {
        Wagon *temp = w;
        w = w->getNext();
        delete temp;
    }
    this->front = nullptr;
    this->rear = nullptr;
}

WagonList::WagonList(WagonList &&other) noexcept
{
    // TODO: Implement move constructor.
    // Transfer ownership of 'other' list’s nodes into this list
    // and leave 'other' in an empty but valid state.

    //Set this list's rear,front and weight as other's
    this->rear = other.getRear();
    this->front = other.getFront();
    this->totalWeight = other.getTotalWeight();

    //Empty other list
    other.front = nullptr;
    other.rear = nullptr;
    other.totalWeight = 0;
}

WagonList &WagonList::operator=(WagonList &&other) noexcept
{
    // Operation version of the move constructor.
    // TODO: Implement it.

    //Set this list's rear,front and weight as other's
    this->rear = other.getRear();
    this->front = other.getFront();
    this->totalWeight = other.getTotalWeight();

    //Empty other list
    other.front = nullptr;
    other.rear = nullptr;
    other.totalWeight = 0;
    return *this;
}

Wagon *WagonList::findById(int id)
{
    // TODO: Find and return the Wagon with given ID.
    // Return nullptr if not found.

    //Set current wagon to front
    Wagon *currWag = this->getFront();
    //While current wagon is not null
    while (currWag)
    {   
        //Check current wagons id and if it matches return current wagon
        if (currWag->getID() == id){
            return currWag;
        }
        //Else set current wagon to next wagon
        else{
            currWag = currWag->getNext();
        }
    }
    //If not found return nullptr
    return nullptr;
}

void WagonList::addWagonToRear(Wagon *w)
{
    // TODO: Add a Wagon to the rear (end) of the list.
    // This function does not respect the weight order
    // it inserts to end regardless of the weight

    //If current list is empty
    if(isEmpty()){
        //Set front to given wagon
        this->front = w;
    }
    //Get rear wagon, link given wagon and rear wagon 
    else{
        Wagon *rearWag = this->getRear();
        rearWag->setNext(w);
        w->setPrev(rearWag);
        w->setNext(nullptr);
    }
    //Set rear wagon to given wagon, add to total weight
    this->rear = w;
    this->totalWeight += w->getWeight();
}

int WagonList::getTotalWeight() const { return totalWeight; }

bool WagonList::isEmpty() const
{
    // TODO: Return true if the list has no wagons

    //If can't find front or rear, return true
    if (!front && !rear)
    {
        return true;
    }
    //Else 
    else{
        //Return false
        return false;
    }
    
}

void WagonList::insertSorted(Wagon *wagon)
{
    // TODO: Insert wagon into this list in descending order of weight.

    //If wagon list is empty
    if(isEmpty()){
        //Set front and rear to wagon
        this->front = wagon;
        this->rear = wagon;

        //Add to total weight
        this->totalWeight += wagon->getWeight();
    }
    //If wagon is greater than all
    else if (wagon->getWeight() > this->getFront()->getWeight())
    {
        //Add wagon to front
        this->front->setPrev(wagon);
        wagon->setNext(this->getFront());
        this->front = wagon;

        //Add to total weight
        this->totalWeight += wagon->getWeight();
    }
    //If wagon is lesser than all
    else if(wagon->getWeight() < this->getRear()->getWeight()){
        //Add wagon to rear
        this->getRear()->setNext(wagon);
        wagon->setPrev(this->getRear());
        this->rear = wagon;

        //Add to total weight
        this->totalWeight += wagon->getWeight();
    }
    //Else
    else{
        //Try to find wagon that should come after given wagon
        Wagon *nextWag = this->getFront();

        //While next wagon's weight is greater than wagon weight, move it
        while (nextWag->getWeight() > wagon->getWeight())
        {
            nextWag = nextWag->getNext();
        }
        //Set previous wagon to next wagon's previous wagon
        Wagon *preWag = nextWag->getPrev();

        //Link next wagon and given wagon
        nextWag->setPrev(wagon);
        wagon->setNext(nextWag);

        //Link previous wagon and given wagon
        preWag->setNext(wagon);
        wagon->setPrev(preWag);

        //Add to total weight
        this->totalWeight += wagon->getWeight();
    }
}

void WagonList::appendList(WagonList &&other)
{
   // TODO: Append another WagonList to this one (merge them).
   // Use move semantics to avoid deep copies. (Double && at the parameter already makes it so)
   // 'other' should end up empty after this operation
   // At merge lists (blocks) will be protected 
   // But the one with heavier wagon at the front will be before the other list

   //If other is empty, exit by return
   if(other.isEmpty()){
        return;
   }
   //If this is empty
   else if(this->isEmpty())
   {    
        //Move other list to this list
        *this = std::move(other);
   }
   else{
        //If given wagon list's front wagon weight is greater than all
        if (other.front->getWeight() > this->getFront()->getWeight())
        {
            this->front->setPrev(other.rear);
            other.rear->setNext(this->front);
            this->front = other.front;
        }
        //Else
        else{
            //Find next wagon list that should come after given wagon list
            Wagon *nextWag = this->getFront();
            Wagon *w = this->getFront()->getNext();
            while(w){
                if (w->getPrev()->getCargoType() != w->getCargoType() && w->getWeight() < other.front->getWeight())
                {
                    nextWag = w;
                    break;
                }
                w = w->getNext();
            }
            //If there is no such wagon list
            if (!w)
            {
                //Put given wagon list at end
                this->rear->setNext(other.front);
                other.front->setPrev(this->rear);
                this->rear = other.rear;
            }
            //Else
            else{
                //Get previous wagon that should come before
                Wagon *prevWag = nextWag->getPrev();
                //Put given wagon list between previous wagon and next wagon
                prevWag->setNext(other.front);
                other.front->setPrev(prevWag);
                nextWag->setPrev(other.rear);
                other.rear->setNext(nextWag);
            }
        }
        this->totalWeight += other.totalWeight;
        //Reset other list
        other.front = nullptr;
        other.rear = nullptr;
        other.totalWeight = 0;
   }
}

Wagon *WagonList::detachById(int id)
{
    // TODO: Remove a specific wagon (by ID) from this list and return it.
    // Use: std::cout << "Wagon " << toRemove->id << " detached from Wagon List. " << std::endl;
    // Return nullptr if wagon not found.

    //Find wagon with given id
    Wagon *wantedWag = this->findById(id);
    //If wanted wagon is found
    if (wantedWag)
    {   
        //If wanted wagon is the only wagon
        if(wantedWag == this->getFront() && wantedWag == this->getRear()){
            this->front = nullptr;
            this->rear = nullptr;
        }
        //Else if wanted wagon is in front
        else if (wantedWag == this->getFront())
        {
            this->front = wantedWag->getNext();
            this->front->setPrev(nullptr);
        }
        //Else if wanted wagon is in rear
        else if (wantedWag == this->getRear())
        {
            this->rear = wantedWag->getPrev();
            this->rear->setNext(nullptr);
        }
        //Else
        else{
            //Set previous and next wagons and link them
            Wagon *preWag = wantedWag->getPrev();
            Wagon *nextWag = wantedWag->getNext();
            preWag->setNext(nextWag);
            nextWag->setPrev(preWag);
        }

        //Remove from total weight
        this->totalWeight -= wantedWag->getWeight();
        //Remove wanted wagon's next and previous connections
        wantedWag->setNext(nullptr);
        wantedWag->setPrev(nullptr);
        //Print message
        std::cout << "Wagon " << wantedWag->getID() << " detached from Wagon List. " << std::endl;
        //Return wanted wagon
        return wantedWag;
    }
    //Return null if wagon not found
    else{
        return nullptr;
    }
}


WagonList WagonList::splitAtById(int id)
{
    // TODO: Split this list into two lists at the wagon with given ID.
    // The wagon with 'id' becomes the start of the new list.
    // Return the new WagonList (move return).
    // If 'id' not found, return an empty list.

    //Find wagon with given id
    WagonList newList; // return-by-value (will be moved automatically)
    Wagon *wantedWag = this->findById(id);
    //If wanted wagon is found
    if (wantedWag)
    {
        //If wanted wagon is at front
        if (wantedWag == this->getFront())
        {
            newList.appendList(std::move(*this));
        }
        //If wanted wagon is at rear
        else if(wantedWag == this->getRear()){
            //Set rear to previous wagon and add wanted wagon to new list
            this->rear = wantedWag->getPrev();
            this->rear->setNext(nullptr);
            newList.addWagonToRear(wantedWag);
            //Remove wanted wagon's weight
            this->totalWeight -= wantedWag->getWeight();
        }
        //Else
        else{
            //Seperate wagons between wanted wagon and rear from this list and add them to new list
            newList.rear = this->getRear();
            Wagon *preWag = wantedWag->getPrev();
            wantedWag->setPrev(nullptr);
            if (preWag)
            {
                preWag->setNext(nullptr);
                this->rear = preWag;
            }
            newList.front = wantedWag;

            //Calculate total weight, set new list total weight to it and remove it from this list's weight
            Wagon *wagon = wantedWag;
            int total = 0;
            while (wagon)
            {
                total += wagon->getWeight();
                wagon = wagon->getNext();
            }
            newList.totalWeight = total;
            this->totalWeight -= total;
        }
    }
    return newList; // moved, not copied
}

// Print is already implemented
void WagonList::print() const
{
    std::cout << *this << std::endl;
    return;
}

// << operator is already implemented
std::ostream &operator<<(std::ostream &os, const WagonList &list)
{
    if (list.isEmpty())
        return os;

    Wagon *current = list.front;

    while (current)
    {
        os << "W" << current->getID() << "(" << current->getWeight() << "ton)";
        if (current->getNext())
            os << " - ";
        current = current->getNext();
    }
    return os;
}
