#include "RailMarshal.h"
#include <iostream>
#include <sstream>
#include <algorithm>

RailMarshal::RailMarshal()
{
    // TODO: Initialize each track in the departure yard.
    // Each TrainTrack corresponds to one Destination.
    Destination destArray[5] = {Destination::ANKARA,Destination::IZMIR,Destination::ESKISEHIR,Destination::ADANA,Destination::OTHERS};
    //For each destination
    for (int i = 0; i < NUM_DESTINATIONS_INT; i++)
    {
        //Set departure yard for current destination
        departureYard[i] = TrainTrack(destArray[i]);
    }
    
}

RailMarshal::~RailMarshal()
{
    // TODO: Cleanup remaining trains, prevent memory leaks
    //Clear classificationYard
    //classificationYard.clear();
    //Clear departureYard
    //For each destination
    
    for (int i = 0; i < NUM_DESTINATIONS_INT; i++)
    {
        //Set destination and departure track of current destination
        Destination dest = static_cast<Destination>(i);
        TrainTrack &departure = getDepartureYard(dest);
        //While departure track is not empty
        while(departure.getFirst())
        {
            dispatchFromTrack(dest);
        }
    }
}

// Getter (ready)
ClassificationYard &RailMarshal::getClassificationYard()
{
    return classificationYard;
}

// Getter (ready)
TrainTrack &RailMarshal::getDepartureYard(Destination dest)
{
    int idx = static_cast<int>(dest);
    return departureYard[idx];
}

void RailMarshal::processCommand(const std::string &line)
{
    // TODO: Parse user commands from input lines.
    std::istringstream split(line);

    //Get command
    std::string command;
    split >> command;

    

    // if ADD_WAGON
    // Use: std::cout << "Error: Invalid ADD_WAGON parameters.\n";
    // Use: std::cout << "Wagon " << *w << " added to yard." << std::endl;
    if(command == "ADD_WAGON"){
        //Create id, cargo string, destination string, weight and maxCouplerLoad variables
        int id;
        std::string cargoStr;
        std::string destStr;
        int weight;
        int maxCouplerLoad;
        //Set id, cargo string, destination string, weight and maxCouplerLoad and if can't set them, print error
        if(!(split >> id >> cargoStr >> destStr >> weight >> maxCouplerLoad)){
            //Print error
            std::cout << "Error: Invalid ADD_WAGON parameters.\n";
            //Exit by return
            return;
        }
        //Parse cargo string and destination string
        CargoType cargo = parseCargo(cargoStr);
        Destination dest = parseDestination(destStr);

        //Create new wagon and insert it to classificationYard
        Wagon *w = new Wagon(id,cargo,dest,weight,maxCouplerLoad);
        classificationYard.insertWagon(w);
        std::cout << "Wagon " << *w << " added to yard." << std::endl;
    }

    // if REMOVE_WAGON
    // Use: std::cout << "Error: Invalid REMOVE_WAGON parameters.\n";
    // Use: std::cout << "Wagon " << id << " removed." << std::endl;
    // Use: std::cout << "Error: Wagon " << id << " not found." << std::endl;
    else if(command == "REMOVE_WAGON"){
        //Set id and if can't set it, print error
        int id;
        if(!(split >> id)){
            //Print error
            std::cout << "Error: Invalid REMOVE_WAGON parameters.\n";
            //Exit by return
            return;
        }
        //For each destination
        for(int i = 0; i < NUM_DESTINATIONS_INT; i++){
            //For each cargo type
            for (int j = 0; j < NUM_CARGOTYPES_INT; j++)
            {
                //Try to get wagon from wagon list at destination i and cargo type j of classification yard
                Wagon *w = classificationYard.getBlockTrain(i,j).detachById(id);
                //If get it
                if(w){
                    //Print message and delete it
                    std::cout << "Wagon " << id << " removed." << std::endl;
                    delete w;
                    return;
                }
            } 
        }
        //Print error message if can't get it
        std::cout << "Error: Wagon " << id << " not found." << std::endl;
    }

    // if ASSEMBLE_TRAIN
    //  Use: std::cout << "Error: Invalid ASSEMBLE_TRAIN parameters.\n";
    //  Use: std::cout << "No wagons to assemble for " << destStr << std::endl;
    //  verify couplers and possibly split (deterministic)
    //  Keep splitting the *front* train until no more overloaded couplers found
    //  create new train with same destination and name suffix
    //  use std::cout << "Train " << newTrain->getName() << " assembled after split with "
    //  << newTrain->getWagons()<< " wagons." << std::endl;
    // use std::cout << "Train " << t->getName() << " assembled with " << t->getWagons() << " wagons." << std::endl;
    else if(command == "ASSEMBLE_TRAIN"){
        //Set destination string and if can't set it, print error
        std::string destStr;
        if(!(split >> destStr)){
            //Print error
            std::cout << "Error: Invalid ASSEMBLE_TRAIN parameters.\n";
            //Exit by return
            return;
        }
        Destination dest = parseDestination(destStr);
        //If classificationYard at destination is empty
        WagonList *destList = classificationYard.getBlocksFor(dest);
        //Set destination and departure track of current destination
        TrainTrack &departure = getDepartureYard(dest);
        //Assemble new train
        Train *newTrain = classificationYard.assembleTrain(dest, departure.generateTrainName());
        if (!newTrain->getWagons().getFront())
        {
            std::cout << "No wagons to assemble for " << destStr << std::endl;
            return;
        }
        //Set split count to 0
        int splitCount = 0;
        //Create split train
        Train *splitTrain = newTrain->verifyCouplersAndSplit(++splitCount);
        //While there is a split train
        while (splitTrain)
        {
            //Add it departure track
            departure.addTrain(splitTrain);
            //Print message
            std::cout << "Train " << splitTrain->getName() << " assembled after split with " << splitTrain->getWagons() << " wagons." << std::endl;
            //Check for next split train
            splitTrain = newTrain->verifyCouplersAndSplit(++splitCount);
        }
        //Add new train to departure track
        departure.addTrain(newTrain);
        //Print message
        std::cout << "Train " << newTrain->getName() << " assembled with " << newTrain->getWagons() << " wagons." << std::endl;
    }

    // if DISPATCH_TRAIN
    //  use: std::cout << "Error: Invalid DISPATCH parameters.\n";
    //  use: std::cout << "Error: No trains to dispatch from track " << destStr << ".\n";
    //  use:  std::cout << "Dispatching " << train->getName() << " (" << t->getTotalWeight() << " tons)." << std::endl;
    else if(command == "DISPATCH_TRAIN"){
        //Set destination string and if can't set it, print error
        std::string destStr;
        if(!(split >> destStr)){
            //Print error
            std::cout << "Error: Invalid DISPATCH parameters.\n";
            //Exit by return
            return;
        }
        //Set destination and departure track of current destination
        Destination dest = parseDestination(destStr);
        TrainTrack &departure = getDepartureYard(dest);
        //If there is not a train
        if(!departure.getFirst()){
            //Print error
            std::cout << "Error: No trains to dispatch from track " << destStr << ".\n";
        }
        //Else
        else{
            //Depart train from departure track
            Train *train = departure.departTrain();
            //Print message
            std::cout << "Dispatching " << train->getName() << " (" << train->getTotalWeight() << " tons)." << std::endl;
            //Delete train
            delete train;
        }
    }

    // if PRINT_YARD
    //  use std::cout << "--- classification Yard ---\n";
    else if(command == "PRINT_YARD"){
        //Print message and classification yard
        std::cout << "--- classification Yard ---\n";
        getClassificationYard().print();
    }

    // if PRINT_TRACK
    //  use std::cout << "Error: Invalid PRINT_TRACK parameters.\n";
    else if(command == "PRINT_TRACK"){
        //Set destination string and if can't set it, print error
        std::string destStr;
        if(!(split >> destStr)){
            //Print error
            std::cout << "Error: Invalid PRINT_TRACK parameters.\n";
            //Exit by return
            return;
        };
        //Set destination and print departure track of current destination
        Destination dest = parseDestination(destStr);
        getDepartureYard(dest).printTrack();
    }

    // if AUTO_DISPATCH <ON/OFF>
    // Enable or disable automatic dispatch when weight exceeds limits.
    // std::cout << "Error: Invalid AUTO_DISPATCH parameters.\n";
    // print "Auto dispatch "enabled" / "disabled"
    else if(command == "AUTO_DISPATCH"){
        //Set enable string and if can't set it, print error
        std::string enable;
        if (!(split >> enable))
        {
            //Print error
            std::cout << "Error: Invalid AUTO_DISPATCH parameters.\n";
            //Exit by return
            return;
        }
        
        //If enable is "ON"
        if (enable == "ON")
        {
            //Enable autoDispatch
            TrainTrack::autoDispatch = true;
            //Print message
            std::cout << "Auto dispatch enabled\n";
        }
        //If enable is "OFF"
        else if (enable == "OFF")
        {
            //Disable autoDispatch
            TrainTrack::autoDispatch = false;
            //Print message
            std::cout << "Auto dispatch disabled\n";
        }
    }
    // if CLEAR
    // Completely reset the system (yard + departure tracks).
    // std::cout << "System cleared." << std::endl;
    else if(command == "CLEAR"){
        //Clear departureYard
        //For each destination
        for (int i = 0; i < NUM_DESTINATIONS_INT; i++)
        {
            //Set destination and departure track of current destination
            Destination dest = static_cast<Destination>(i);
            TrainTrack &departure = getDepartureYard(dest);
            //While departure track is not empty
            while(departure.getFirst())
            {
                //Depart front train and delete it 
                Train *t = departure.departTrain();
                delete t;
            }
        }
        //Clear classificationYard
        classificationYard.clear();
        //Print message
        std::cout << "System cleared." << std::endl;
    }
    
    //Else std::cout << "Error: Unknown command '" << cmd << "'" << std::endl;
    else{
        //Print error
        std::cout << "Error: Unknown command '" << command << "'" << std::endl;
    }
}

void RailMarshal::dispatchFromTrack(Destination track)
{
    // TODO: Dispatch the next train (frontmost) from the specified track.
    // std::cout << "Error: No trains to dispatch from Track " << destIndex << ".\n";
    /*std::cout << "Train " << t->getName()
              << " departed from Track " << destIndex
              << " (" << destinationToString(static_cast<Destination>(destIndex)) << ").\n";
     */

    Train *train = getDepartureYard(track).departTrain();
    int destIndex = static_cast<int>(track);
    if(!train){
        std::cout << "Error: No trains to dispatch from Track " << destIndex << ".\n";
    }
    else{
        std::cout << "Train " << train->getName()
              << " departed from Track " << destIndex
              << " (" << destinationToString(static_cast<Destination>(destIndex)) << ").\n";
        delete train;
    }
    
}

void RailMarshal::printDepartureYard() const
{
    for (int i = 0; i < NUM_DESTINATIONS_INT; ++i)
    {
        std::cout << "Track " << i << " ("
                  << destinationToString(static_cast<Destination>(i)) << "):\n";
        departureYard[i].printTrack();
    }
}

// Debug helper functions
void RailMarshal::printStatus() const
{
    std::cout << "--- classification Yard ---\n";
    classificationYard.print();

    std::cout << "--- Departure Yard ---\n";
    for (int i = 0; i < static_cast<int>(Destination::NUM_DESTINATIONS); ++i)
    {
        departureYard[i].printTrack();
    }
}
