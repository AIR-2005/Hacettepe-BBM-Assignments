#include "RedBlackTree.h"

RedBlackTree::RedBlackTree()
    : root(nullptr)
{
}

RedBlackTree::~RedBlackTree()
{
    clear();
}

void RedBlackTree::clear()
{
    clear(root);
    root = nullptr;
}

void RedBlackTree::clear(ResearcherNode *node)
{
    //TODO:
    if (!node)
    {
        return;
    }
    clear(node->left);
    clear(node->right);
    delete node;
}

ResearcherNode *RedBlackTree::findResearcher(const std::string &fullName) const
{
    return find(root, fullName);
}

ResearcherNode *RedBlackTree::find(ResearcherNode *node, const std::string &fullName) const
{

//TODO: search and find researcher by name
    if (!node)
    {
        return nullptr;
    }
    else if(node->data.fullName == fullName){
        return node;
    }
    else if(node->data.fullName > fullName){
        return find(node->left, fullName);
    }
    else if(node->data.fullName < fullName){
        return find(node->right, fullName);
    }
    return nullptr;
}

bool RedBlackTree::insertResearcher(const Researcher &researcher)
{
    //attempt to insert, erturn true if success, false otherwise
    bool inserted = false;
    ResearcherNode *rNode = new ResearcherNode(researcher);
    root = bstInsert(root, rNode, inserted);
    if (!inserted)
    {
        delete rNode;
    }
    
    if (inserted)
    {
        insertFixup(rNode);
    }
    return inserted;//temporary, you may delete this
}

ResearcherNode *RedBlackTree::bstInsert(ResearcherNode *current, ResearcherNode *node, bool &inserted)
{
    // TODO:
    // 1) Standard BST insert by node->data.fullName.
    // 2) If tree is empty, node becomes root (set inserted = true).
    if (!current)
    {
        inserted = true;
        current = node;
        return current;
    }
    // 3) If name already exists, inserted = false and return current without inserting.
    if(node->data.fullName == current->data.fullName)
    {
        inserted = false;
        return current;
    }
    // 4) Otherwise insert and set inserted = true.
    else if (current->data.fullName > node->data.fullName)
    {
        current->left = bstInsert(current->left, node, inserted);
        if (current->left)
        {
            current->left->parent = current;
        }
        
    }
    else if (current->data.fullName < node->data.fullName)
    {
        current->right = bstInsert(current->right, node, inserted);
        if (current->right)
        {
            current->right->parent = current;
        }
    }
    // 5) Do not modify colors here (node->color already RED).
    return current;
}

void RedBlackTree::insertFixup(ResearcherNode *node)
{
    // TODO: Standard Red-Black insertion fixup.
    // While parent is RED, handle cases based on uncle's color and position.
    while(node != root && node->parent->color == RED){
        ResearcherNode *uncle;
        if (node->parent == node->parent->parent->left)
        {
            uncle = node->parent->parent->right;
            //If uncle is RED
            if(uncle && uncle->color == RED){
                uncle->color = BLACK;
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                node = node->parent->parent;
            }
            //If uncle is BLACK
            else{
                if (node == node->parent->right)
                {
                    node = node->parent;
                    rotateLeft(node);
                }
                node->parent->parent->color = RED;
                node->parent->color = BLACK;
                rotateRight(node->parent->parent);
            }
        }
        else{
            uncle = node->parent->parent->left;
            //If uncle is RED
            if(uncle && uncle->color == RED){
                uncle->color = BLACK;
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                node = node->parent->parent;
            }
            //If uncle is BLACK
            else{
                if (node == node->parent->left)
                {
                    node = node->parent;
                    rotateRight(node);
                }
                node->parent->parent->color = RED;
                node->parent->color = BLACK;
                rotateLeft(node->parent->parent);
            }
        }
    }
    // Ensure root becomes BLACK at the end.
    root->color = BLACK;
}

bool RedBlackTree::removeResearcher(const std::string &fullName)
{
    // TODO:
    // 1) Find node z with data.fullName == fullName.
    ResearcherNode *z = findResearcher(fullName);
    // 2) If not found, return false.
    if (!z)
    {
        return false;
    }
    // 3) Perform standard RBT delete:
    if (!z->left && !z->right)
    {
        if (!z->parent)
        {
            root = nullptr;
        }
        else if (z == z->parent->left)
        {
            z->parent->left = nullptr;
        }
        else
        {
            z->parent->right = nullptr;
        }
        if (z->color == BLACK)
        {
            deleteFixup(nullptr, z->parent);
        }
    }
    else if (!z->left)
    {
        ResearcherNode *y = z->right;
        if (!z->parent)
        {
            root = y;
        }
        else if (z == z->parent->left)
        {
            z->parent->left = y;
        }
        else
        {
            z->parent->right = y;
        }
        if (y)
        {
            y->parent = z->parent;
        }
        if (z->color == BLACK)
        {
            deleteFixup(y, z->parent);
        }
    }
    else if (!z->right)
    {
        ResearcherNode *x = z->left;
        if (!z->parent)
        {
            root = x;
        }
        else if (z == z->parent->left)
        {
            z->parent->left = x;
        }
        else
        {
            z->parent->right = x;
        }
        if (x)
        {
            x->parent = z->parent;
        }
        if (z->color == BLACK)
        {
            deleteFixup(x, z->parent);
        }
    }
    else{
        ResearcherNode *leftSuccessor = minimum(z->right);
        ResearcherNode *x = leftSuccessor->right;
        ResearcherNode *deleteParent;
        if (leftSuccessor->parent == z)
        {
            deleteParent = leftSuccessor;
            if (x)
            {
                x->parent = leftSuccessor;
            }
        }
        else{
            deleteParent = leftSuccessor->parent;
            if (leftSuccessor == leftSuccessor->parent->left)
            {
                leftSuccessor->parent->left = x;
            }
            else
            {
                leftSuccessor->parent->right = x;
            }
            if (x)
            {
                x->parent = leftSuccessor->parent;
            }
            leftSuccessor->right = z->right;
            leftSuccessor->right->parent = leftSuccessor;
        }
        if (!z->parent)
        {
            root = leftSuccessor;
        }
        else if (z == z->parent->left)
        {
            z->parent->left = leftSuccessor;
        }
        else
        {
            z->parent->right = leftSuccessor;
        }
        leftSuccessor->parent = z->parent;
        leftSuccessor->left = z->left;
        leftSuccessor->left->parent = leftSuccessor;
        if (leftSuccessor->color == BLACK)
        {
            leftSuccessor->color = z->color;
            deleteFixup(x, deleteParent);
        }
        else{
            leftSuccessor->color = z->color;
        }
    }
    //    - Track original color of removed node.
    //    - If a black node is removed, call deleteFixup on the appropriate child.
    // 4) Free node memory.
    delete z;
    // 5) Return true.
    return true;
}

void RedBlackTree::deleteFixup(ResearcherNode *node, ResearcherNode *parent)
{
    // TODO: Standard Red-Black deletion fixup.
    while (node != root && (!node || node->color == BLACK))
    {
        ResearcherNode *sibling;
        if(node == parent->left){
            sibling = parent->right;
            if (sibling && sibling->color == RED)
            {
                sibling->color = BLACK;
                parent->color = RED;
                rotateLeft(parent);
                sibling = parent->right;
            }
            if ((!sibling || ((!sibling->left || sibling->left->color == BLACK) && (!sibling->right || sibling->right->color == BLACK))))
            {
                if (sibling)
                {
                    sibling->color = RED;
                }
                node = parent;
                parent = parent->parent;
            }
            else{
                if (sibling->left && sibling->left->color == RED)
                {
                    sibling->left->color = BLACK;
                    sibling->color = RED;
                    rotateRight(sibling);
                    sibling = parent->right;
                }
                if (sibling->right && sibling->right->color == RED)
                {
                    sibling->color = parent->color;
                    sibling->right->color = BLACK;
                    parent->color = BLACK;
                    rotateLeft(parent);
                    break;
                }
            }
        }
        else{
            sibling = parent->left;
            if (sibling && sibling->color == RED)
            {
                sibling->color = BLACK;
                parent->color = RED;
                rotateRight(parent);
                sibling = parent->left;
            }
            if((!sibling || ((!sibling->left || sibling->left->color == BLACK) && (!sibling->right || sibling->right->color == BLACK))))
            {
                if (sibling)
                {
                    sibling->color = RED;
                }
                node = parent;
                parent = parent->parent;
            }
            else{
                if (sibling->right && sibling->right->color == RED)
                {
                    sibling->right->color = BLACK;
                    sibling->color = RED;
                    rotateLeft(sibling);
                    sibling = parent->left;
                }
                if (sibling->left && sibling->left->color == RED)
                {
                    sibling->color = parent->color;
                    sibling->left->color = BLACK;
                    parent->color = BLACK;
                    rotateRight(parent);
                    break;
                }
            }
        }
    }
    if (node)
    {
        node->color = BLACK;
    }
}

ResearcherNode *RedBlackTree::minimum(ResearcherNode *node) const
{
    // TODO: Return leftmost node in subtree.
    while (node->left)
    {
        node = node->left;
    }   
    return node;
}


void RedBlackTree::rotateLeft(ResearcherNode *x)
{
    // TODO: Standard left rotation.
    ResearcherNode *y = x->right;
    ResearcherNode *newRightChild = y->left;
    x->right = newRightChild;
    if (newRightChild)
    {
        newRightChild->parent = x;
    }
    if (!x->parent)
    {
        root = y;
    }
    else if (x == x->parent->left)
    {
        x->parent->left = y;
    }
    else
    {
        x->parent->right = y;
    }
    y->left = x;
    y->parent = x->parent;
    x->parent = y;
}

void RedBlackTree::rotateRight(ResearcherNode *y)
{
    // TODO: Standard right rotation.
    ResearcherNode *x = y->left;
    ResearcherNode *newLeftChild = x->right;
    y->left = newLeftChild;
    if (newLeftChild)
    {
        newLeftChild->parent = y;
    }
    if (!y->parent)
    {
        root = x;
    }
    else if (y == y->parent->left)
    {
        y->parent->left = x;
    }
    else
    {
        y->parent->right = x;
    }
    x->right = y;
    x->parent = y->parent;
    y->parent = x;
}

int RedBlackTree::getResearcherCount() const
{
    return getResearcherCount(root);
}

int RedBlackTree::getResearcherCount(ResearcherNode *node) const
{
    // TODO: return size of subtree.
    if (node)
    {
        return 1 + getResearcherCount(node->left) + getResearcherCount(node->right);
    }
    return 0;
}

int RedBlackTree::getTotalLoad() const
{
    return getTotalLoad(root);
}

int RedBlackTree::getTotalLoad(ResearcherNode *node) const
{
    // TODO: sum of data.numAssigned in subtree.
    if (node)
    {
        return node->data.numAssigned + getTotalLoad(node->left) + getTotalLoad(node->right);
    }
    return 0;
}

void RedBlackTree::traversePreOrderForStats() const
{
    traversePreOrderForStats(root);
}

void RedBlackTree::traversePreOrderForStats(ResearcherNode *node) const
{
    // TODO:
    // Pre-order traversal (node, left, right).
    // Students will decide what exactly to print in PRINT_STATS.
    //Print node
    if (!node)
    {
        return;
    }
    Researcher researcher = node->data;
    std::cout << researcher.fullName << " " << researcher.capacity << " " << researcher.numAssigned << std::endl;
    traversePreOrderForStats(node->left);
    traversePreOrderForStats(node->right);
}
