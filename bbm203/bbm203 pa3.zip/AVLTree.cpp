#include "AVLTree.h"

AVLTree::AVLTree()
    : root(nullptr)
{
}

AVLTree::~AVLTree()
{
    clear();
}

void AVLTree::clear()
{
    clear(root);
    root = nullptr;
}

void AVLTree::clear(ArtifactNode *node)
{
//TODO
    if (!node)
    {
        return;
    }
    clear(node->left);
    clear(node->right);
    delete node;
}

int AVLTree::height(ArtifactNode *node) const
{
    return node ? node->height : -1;
}

int AVLTree::getBalance(ArtifactNode *node) const
{
    if (!node) return 0;
    return height(node->left) - height(node->right);
}

ArtifactNode *AVLTree::rotateLeft(ArtifactNode *x)
{
    // TODO: Standard AVL left rotation.
    ArtifactNode *y = x->right;
    ArtifactNode *newRightChild = y->left;
    x->right = newRightChild;
    y->left = x;
    if (height(x->left) > height(x->right))
    {
        x->height = height(x->left) + 1;
    }
    else if (height(x->left) <= height(x->right))
    {
        x->height = height(x->right) + 1;
    }
    if (height(y->left) > height(y->right))
    {
        y->height = height(y->left) + 1;
    }
    else
    {
        y->height = height(y->right) + 1;
    }
    //return new root
    return y;
}

ArtifactNode *AVLTree::rotateRight(ArtifactNode *y)
{
    // TODO: Standard AVL right rotation (mirror of rotateLeft).
    ArtifactNode *x = y->left;
    ArtifactNode *newLeftChild = x->right;
    y->left = newLeftChild;
    x->right = y;
    if (height(y->left) > height(y->right))
    {
        y->height = height(y->left) + 1;
    }
    else
    {
        y->height = height(y->right) + 1;
    }
    if (height(x->left) > height(x->right))
    {
        x->height = height(x->left) + 1;
    }
    else if (height(x->left) <= height(x->right))
    {
        x->height = height(x->right) + 1;
    }
    //return new root
    return x;
}

ArtifactNode *AVLTree::findMinNode(ArtifactNode *node) const
{
    // TODO: Return leftmost node in this subtree.
    while (node->left)
    {
        node = node->left;
    }   
    return node;
}

ArtifactNode *AVLTree::insert(ArtifactNode *node, const Artifact &artifact, bool &inserted)
{
    // TODO:
    // 1) Standard BST insert by artifactID.
    if (!node)
    {
        inserted = true;
        ArtifactNode *nNode = new ArtifactNode(artifact);
        return nNode;
    }
    if (node->data.artifactID > artifact.artifactID)
    {
        node->left = insert(node->left, artifact, inserted);
    }
    else if (node->data.artifactID < artifact.artifactID)
    {
        node->right = insert(node->right, artifact, inserted);
    }
    // 2) If duplicate ID, set inserted = false and return node unchanged.
    else if (node->data.artifactID == artifact.artifactID)
    {
        inserted = false;
        return node;
    }
    // 3) On actual insertion, update node->height.
    if (height(node->left) > height(node->right))
    {
        node->height = height(node->left) + 1;
    }
    else
    {
        node->height = height(node->right) + 1;
    }
    // 4) Compute balance and apply AVL rotations if needed.
    int balance =  getBalance(node);
    //Single Right Rotation(insertion to left subtree of left child)
    if(balance > 1 && artifact.artifactID < node->left->data.artifactID){
        return rotateRight(node);
    }
    //Left-Right Rotation(insertion to right subtree of the left child)
    else if(balance > 1 && artifact.artifactID > node->left->data.artifactID){
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    //Single Left Rotation(insertion to right subtree of right child)
    else if (balance < -1 && artifact.artifactID > node->right->data.artifactID)
    {
        return rotateLeft(node);
    }
    //Right-Left Rotation(insertion to left subtree of right child)
    else if (balance < -1 && artifact.artifactID < node->right->data.artifactID)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }
    // 5) Return the (possibly new) root of this subtree.
    return node;
}

ArtifactNode *AVLTree::remove(ArtifactNode *node, int artifactID, bool &removed)
{
    // TODO:
    // 1) Standard BST deletion by artifactID.
    // 2) If node not found, leave removed = false.
    if (!node)
    {
        removed = false;
        return node;
    }
    if (node->data.artifactID > artifactID){
        node->left = remove(node->left, artifactID, removed);
    }
    if (node->data.artifactID < artifactID){
        node->right = remove(node->right, artifactID, removed);
    }
    if (node->data.artifactID == artifactID){
        if (!node->left && !node->right){
            delete node;
            node = nullptr;
            removed = true;
        }
        else if (!node->right){
            ArtifactNode *temp = node;
            node = node->left;
            delete temp;
            removed = true;
        }
        else if (!node->left){
            ArtifactNode *temp = node;
            node = node->right;
            delete temp;
            removed = true;
        }
        else{
            ArtifactNode *leftSuccessor = findMinNode(node->right);
            node->data = leftSuccessor->data;
            node->right = remove(node->right, leftSuccessor->data.artifactID, removed);
        }
    }
    // 3) Upon deletion, update heights and rebalance with rotations.
    if (!node)
    {
        return nullptr;
    }
    if (height(node->left) > height(node->right))
    {
        node->height = height(node->left) + 1;
    }
    else
    {
        node->height = height(node->right) + 1;
    }

    int balance =  getBalance(node);
    //Single Right Rotation
    if(balance > 1 && getBalance(node->left) >= 0){
        return rotateRight(node);
    }
    //Left-Right Rotation
    else if(balance > 1 && getBalance(node->left) < 0){
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    //Single Left Rotation
    else if (balance < -1 && getBalance(node->right) <= 0){
        return rotateLeft(node);
    }
    //Right-Left Rotation
    else if (balance < -1 && getBalance(node->right) > 0){
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }
    // 4) Return (possibly new) root of this subtree.
    return node;
}

bool AVLTree::insertArtifact(const Artifact &artifact)
{
    bool inserted = false;//tracks whether operation is succesful
    root = insert(root, artifact, inserted);
    return inserted;
}

bool AVLTree::removeArtifact(int artifactID)
{
    bool removed = false;//tracks whether operation is succesful
    root = remove(root, artifactID, removed);
    return removed;
}

ArtifactNode *AVLTree::findArtifact(int artifactID) const
{
    return find(root, artifactID);
}

ArtifactNode *AVLTree::find(ArtifactNode *node, int artifactID) const
{
    //TODO
    if(!node){
        return nullptr;
    }
    else if(node->data.artifactID == artifactID){
        return node;
    }
    else if(node->data.artifactID > artifactID){
        return find(node->left, artifactID);
    }
    else if(node->data.artifactID < artifactID){
        return find(node->right, artifactID);
    }
    return nullptr;
}

void AVLTree::setAssignedTo(int artifactID, const std::string &researcherName)
{
    //assign artifact to researcher
    ArtifactNode *aNode = findArtifact(artifactID);
    if (aNode)
    {
        aNode->data.assignedToName = researcherName;
    }
}

void AVLTree::clearAssignedTo(int artifactID)
{
    //TODO
    ArtifactNode *aNode = findArtifact(artifactID);
    if (aNode)
    {
        aNode->data.assignedToName = "";
    }
}

void AVLTree::printUnassigned() const
{
    printUnassigned(root);
}

void AVLTree::printUnassigned(ArtifactNode *node) const
{
    // TODO:
    // Inorder traversal.
    if (!node)
    {
        return;
    }
    printUnassigned(node->left);
    if (node->data.assignedToName == "")
    {
        std::cout << node->data.artifactID << " " << node->data.name << " " << node->data.rarityLevel << " " << node->data.researchValue << std::endl;
    }
    printUnassigned(node->right);
    // For each node with data.assignedToName == "", print in required format, e.g.:
    // <id> <name> <rarity> <value>
}

int AVLTree::getArtifactCount() const
{
    return getArtifactCount(root);
}

int AVLTree::getArtifactCount(ArtifactNode *node) const
{
    // TODO: return size of subtree.
    if (node)
    {
        return 1 + getArtifactCount(node->left) + getArtifactCount(node->right);
    }
    return 0;
}

int AVLTree::getTotalRarity() const
{
    return getTotalRarity(root);
}

int AVLTree::getTotalRarity(ArtifactNode *node) const
{
    // TODO: sum of rarityLevel over subtree.
    if (node)
    {
        return node->data.rarityLevel + getTotalRarity(node->left) + getTotalRarity(node->right);
    }
    return 0;
}

void AVLTree::traversePostOrderForStats() const
{
    traversePostOrderForStats(root);
}

void AVLTree::traversePostOrderForStats(ArtifactNode *node) const
{
    // TODO:
    // Post-order traversal (left, right, node).
    if (!node)
    {
        return;
    }
    traversePostOrderForStats(node->left);
    traversePostOrderForStats(node->right);
    Artifact artifact = node->data;
    std::string name;
    
    if (artifact.assignedToName != "")
    {
        name = artifact.assignedToName;
    }
    else{
        name = "UNASSIGNED";
    }
    
    std::cout << artifact.artifactID << " " << artifact.name << " " << artifact.rarityLevel << " " << artifact.researchValue << " " << name << std::endl;
    
    // Students will decide what exactly to print in PRINT_STATS.
}

//Helper Function to call handleMatchRarity(root, minRarity)
void AVLTree::traverseRarity(int minRarity) const{
    traverseRarity(root, minRarity);
}

//Helper Function for handleMatchRarity(inorder traversal)
void AVLTree::traverseRarity(ArtifactNode *node, int minRarity) const{
    if (!node)
    {
        return;
    }
    traverseRarity(node->left, minRarity);
    if (node->data.rarityLevel >= minRarity)
    {
        Artifact artifact = node->data;
        if (artifact.assignedToName != ""){
            std::cout << artifact.artifactID << " " << artifact.name << " " << artifact.rarityLevel << " " << artifact.researchValue << " ASSIGNED:" << artifact.assignedToName << std::endl;
        }
        else{
            std::cout << artifact.artifactID << " " << artifact.name << " " << artifact.rarityLevel << " " << artifact.researchValue << " UNASSIGNED" << std::endl;
        }
    }
    traverseRarity(node->right, minRarity);
}