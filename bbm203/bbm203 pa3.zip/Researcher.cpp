#include "Researcher.h"

Researcher::Researcher()
    : fullName(""),
      capacity(0),
      assignedArtifacts(nullptr),
      numAssigned(0)
{
}

Researcher::Researcher(const std::string &name, int cap)
    : fullName(name),
      capacity(cap),
      assignedArtifacts(nullptr),
      numAssigned(0)
{
    if (capacity > 0)
    {
        assignedArtifacts = new int[capacity];
    }
}

//Copy constructor to prevent assignedArtifacts adress to be same in all Researchers
Researcher::Researcher(const Researcher &other)
    : fullName(other.fullName),
      capacity(other.capacity),
      assignedArtifacts(nullptr),
      numAssigned(other.numAssigned)
{
    if (capacity > 0)
    {
        assignedArtifacts = new int[capacity];

        for (int i = 0; i < numAssigned; i++)
        {
            assignedArtifacts[i] = other.assignedArtifacts[i];
        }
    }
}

Researcher::~Researcher()
{
    delete[] assignedArtifacts;
    assignedArtifacts = nullptr;
}

bool Researcher::addArtifact(int artifactID)
{
    // TODO:
    // 1) If hasArtifact(artifactID) is true, return false (already supervised).
    if (hasArtifact(artifactID))
    {
        return false;
    }
    // 2) If numAssigned >= capacity, return false (at full capacity).
    else if(numAssigned >= capacity){
        return false;
    }
    // 3) Otherwise, insert artifactID at assignedArtifacts[numAssigned] and increment numAssigned.
    else{
        assignedArtifacts[numAssigned] = artifactID;
        numAssigned++;
        return true;
    }
    // 4) Return true.
}

bool Researcher::removeArtifact(int artifactID)
{
    // TODO:
    // 1) Find index i where assignedArtifacts[i] == artifactID.
    bool found = false;
    int ind = 0;
    for (int i = 0; i < numAssigned; i++)
    {
        if (assignedArtifacts[i] == artifactID)
        {
            found = true;
            ind = i;
            break;
        }   
    }
    // 2) If not found, return false.
    if (!found)
    {
        return false;
    }
    // 3) Shift elements after i one step to the left.
    for (int i = ind; i < numAssigned - 1; i++)
    {
        assignedArtifacts[i] = assignedArtifacts[i+1];
    }
    numAssigned--;
    // 4) Decrement numAssigned and return true.
    return true;
}

void Researcher::removeAllArtifacts()
{
    // TODO:
    // Simply reset numAssigned to 0.
    // (The actual artifacts' assignedToName in the AVL tree will be cleared by the controller.)
    numAssigned = 0;
}

bool Researcher::hasArtifact(int artifactID) const
{
    // TODO:
    // Return true if artifactID appears in assignedArtifacts[0..numAssigned-1], false otherwise.
    for (int i = 0; i < numAssigned; i++)
    {
        if (assignedArtifacts[i] == artifactID)
        {
            return true;
        }   
    }
    return false;
}
