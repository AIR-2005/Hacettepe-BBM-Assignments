#include "ArtifactManager.h"
#include <iostream>
#include <sstream>
ArtifactManager::ArtifactManager()
{
}

ArtifactManager::~ArtifactManager()
{
}

int ArtifactManager::tokenize(const std::string &line, std::string tokens[], int maxTokens) const
{
    std::istringstream iss(line);
    std::string tok;
    int count = 0;
    while (iss >> tok && count < maxTokens)
    {
        tokens[count++] = tok;
    }
    return count;
}

void ArtifactManager::parseAndExecute(const std::string &line)
{
    // TODO: read lines and execuıte each command
    std::string tokenArr[5];
    int count = tokenize(line, tokenArr, 5);
    if (count == 0)
    {
        return;
    }
    if (tokenArr[0] == "ADD_ARTIFACT")
    {
        handleAddArtifact(tokenArr, count);
    }
    else if (tokenArr[0] == "REMOVE_ARTIFACT")
    {
        handleRemoveArtifact(tokenArr, count);
    }
    else if (tokenArr[0] == "HIRE_RESEARCHER")
    {
        handleHireResearcher(tokenArr, count);
    }
    else if (tokenArr[0] == "FIRE_RESEARCHER")
    {
        handleFireResearcher(tokenArr, count);
    }
    else if (tokenArr[0] == "REQUEST")
    {
        handleRequest(tokenArr, count);
    }
    else if (tokenArr[0] == "RETURN")
    {
        handleReturn(tokenArr, count);
    }
    else if (tokenArr[0] == "RETURN_ALL")
    {
        handleReturnAll(tokenArr, count);
    }
    else if (tokenArr[0] == "RESEARCHER_LOAD")
    {
        handleResearcherLoad(tokenArr, count);
    }
    else if (tokenArr[0] == "MATCH_RARITY")
    {
        handleMatchRarity(tokenArr, count);
    }
    else if (tokenArr[0] == "PRINT_UNASSIGNED")
    {
        handlePrintUnassigned(tokenArr, count);
    }
    else if (tokenArr[0] == "PRINT_STATS")
    {
        handlePrintStats(tokenArr, count);
    }
    else if (tokenArr[0] == "CLEAR")
    {
        handleClear(tokenArr, count);
    }
    else{
        std::cout << "Error: Unknown command '" << tokenArr[0] << "'." << std::endl;
    }
}

// =================== COMMAND HANDLERS ===================

void ArtifactManager::handleAddArtifact(const std::string tokens[], int count)
{
    // Expected: ADD_ARTIFACT <id> <name> <rarity> <value>
    // TODO:
    // 1) Check parameter count.
    if(count != 5){
        return;
    }
    // 2) Convert <id>, <rarity>, <value> to integers.
    int id = stoi(tokens[1]);
    std::string name = tokens[2];
    int rarity = stoi(tokens[3]);
    int value = stoi(tokens[4]);
    // 3) Create Artifact and attempt to insert into AVL tree.
    bool insertBool = artifactTree.insertArtifact(Artifact(id, name, rarity, value));
    // 4) On success: print "Artifact <id> added."
    // 5) On duplicate: print appropriate error (as in the PDF).
    if (insertBool)
    {
        std::cout << "Artifact " << id << " added." << std::endl;
    }
    else{
        std::cout << "Error: Artifact " << id << " already exists." << std::endl;
    }
}

void ArtifactManager::handleRemoveArtifact(const std::string tokens[], int count)
{
    // Expected: REMOVE_ARTIFACT <id>
    // TODO:
    if(count != 2){
        return;
    }
    // 1) Parse id.
    int id = stoi(tokens[1]);
    // 2) Find artifact in AVL; if not found, print error.
    ArtifactNode *foundArtifact = artifactTree.findArtifact(id);
    if (!foundArtifact)
    {
        std::cout << "Error: Artifact " << id << " not found." << std::endl;
        return;
    }
    // 3) If artifact is assigned , find researcher and
    //    remove artifact from their list.
    if (foundArtifact->data.assignedToName != "")
    {
        ResearcherNode *rNode = researcherTree.findResearcher(foundArtifact->data.assignedToName);
        if (rNode)
        {
            rNode->data.removeArtifact(id);
        }
    }
    bool removedArtifact = artifactTree.removeArtifact(id);
    // 4) Remove artifact from AVL; print success or error message.
    if (removedArtifact)
    {
        std::cout << "Artifact " << id << " removed." << std::endl;
    }
    else{
        std::cout << "Error: Artifact " << id << " not removed." << std::endl;
    }
    
}

void ArtifactManager::handleHireResearcher(const std::string tokens[], int count)
{
    // Expected: HIRE_RESEARCHER <name> <capacity>
    // TODO:
    if(count != 3){
        return;
    }
    // 1) Parse name and capacity.
    std::string name = tokens[1];
    int capacity = stoi(tokens[2]);
    // 2) Create Researcher and insert into RedBlackTree.
    Researcher researcher = Researcher(name, capacity);
    bool insertRes = researcherTree.insertResearcher(researcher);
    // 3) On success: "Researcher <name> hired."
    // 4) On duplicate: error message.
    if (insertRes)
    {
        std::cout << "Researcher " << name << " hired." << std::endl;
    }
    else{
        std::cout << "Error: Researcher " << name << " already exists." << std::endl;
    }
    
}

void ArtifactManager::handleFireResearcher(const std::string tokens[], int count)
{
    // Expected: FIRE_RESEARCHER <name>
    // TODO:
    if(count != 2){
        return;
    }
    std::string name = tokens[1];
    // 1) Find researcher by name. If not found, print error.
    ResearcherNode *rNode = researcherTree.findResearcher(name);
    if(!rNode){
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
        return;
    }
    // 2) For each artifact ID in their assignment list:
    //      - clear assignedToName in AVL.
    for (int i = 0; i < rNode->data.numAssigned; i++)
    {
        artifactTree.clearAssignedTo(rNode->data.assignedArtifacts[i]);
    }
    // 3) Remove researcher from RBT.
    bool fireRes = researcherTree.removeResearcher(name);
    // 4) Print success message.
    if (fireRes)
    {
        std::cout << "Researcher " << name << " fired." << std::endl;
    }
}

void ArtifactManager::handleRequest(const std::string tokens[], int count)
{
    // Expected: REQUEST <researcherName> <artifactID>
    // TODO:
    if(count != 3){
        return;
    }
    // 1) Find researcher by name; error if missing.
    std::string name = tokens[1];
    ResearcherNode *rNode = researcherTree.findResearcher(name);
    if(!rNode){
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
        return;
    }
    // 2) Find artifact by ID; error if missing.
    int id = stoi(tokens[2]);
    ArtifactNode *aNode = artifactTree.findArtifact(id);
    if(!aNode){
        std::cout << "Error: Artifact " << id << " not found." << std::endl;
        return;
    }
    // 3) Check artifact is unassigned; error if already assigned.
    if (aNode->data.assignedToName != "")
    {
        std::cout << "Error: Artifact " << id << " is already assigned." << std::endl;
        return;
    }
    // 4) Check researcher capacity; error if at full capacity.
    if(rNode->data.numAssigned == rNode->data.capacity){
        std::cout << "Error: Researcher " << name << " is at full capacity." << std::endl;
        return;
    }
    // 5) On success: add artifact to researcher list AND set assignedToName in AVL.
    //    Print "Artifact <id> assigned to <name>."
    bool addArt = rNode->data.addArtifact(id);
    if (addArt)
    {
        aNode->data.assignedToName = name;
        aNode->data.updateValueBasedOnUsage();
        std::cout << "Artifact " << id << " assigned to " << name << "." << std::endl;
    }
}

void ArtifactManager::handleReturn(const std::string tokens[], int count)
{
    // Expected: RETURN <researcherName> <artifactID>
    // TODO:
    if(count != 3){
        return;
    }
    // 1) Validate existence of researcher and artifact.
    std::string name = tokens[1];
    ResearcherNode *rNode = researcherTree.findResearcher(name);
    if(!rNode){
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
        return;
    }
    int id = stoi(tokens[2]);
    ArtifactNode *aNode = artifactTree.findArtifact(id);
    if(!aNode){
        std::cout << "Error: Artifact " << id << " not found." << std::endl;
        return;
    }
    // 2) Check that artifact.assignedToName == researcherName.
    // 3) If not, print error.
    if (aNode->data.assignedToName != name)
    {
        std::cout << "Error: Artifact " << id << " not assigned to " << name << "." << std::endl;
        return;
    }
    // 4) Otherwise, remove artifact from researcher list, clear assignedToName in AVL.
    //    Print "Artifact <id> returned by <name>."
    bool removeArt = rNode->data.removeArtifact(id);
    if (removeArt)
    {
        aNode->data.assignedToName = "";
        std::cout << "Artifact " << id << " returned by " << name << "." <<std::endl;
    }
}

void ArtifactManager::handleReturnAll(const std::string tokens[], int count)
{
    // Expected: RETURN_ALL <researcherName>
    // TODO:
    if(count != 2){
        return;
    }
    // 1) Find researcher; error if missing.
    std::string name = tokens[1];
    ResearcherNode *rNode = researcherTree.findResearcher(name);
    if(!rNode){
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
        return;
    }
    // 2) For each artifact they supervise, clear assignedToName in AVL.
    for (int i = 0; i < rNode->data.numAssigned; i++)
    {
        artifactTree.clearAssignedTo(rNode->data.assignedArtifacts[i]);
    }
    // 3) Clear researcher's assignment list (removeAllArtifacts()).
    rNode->data.removeAllArtifacts();
    // 4) Print appropriate confirmation message.
    std::cout << "All artifacts returned by " << name << "." <<std::endl;
}

void ArtifactManager::handleResearcherLoad(const std::string tokens[], int count)
{
    // Expected: RESEARCHER_LOAD <name>
    // TODO:
    if(count != 2){
        return;
    }
    // 1) Find researcher by name.
    // 2) If not found, print error.
    std::string name = tokens[1];
    ResearcherNode *rNode = researcherTree.findResearcher(name);
    if(!rNode){
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
        return;
    }
    // 3) Otherwise, print number of supervised artifacts in required format.
    std::cout << "Number of artifacts assigned to " << name << ": " << rNode->data.numAssigned << std::endl;
}

void ArtifactManager::handleMatchRarity(const std::string tokens[], int count)
{
    // Expected: MATCH_RARITY <minRarity>
    // TODO:
    if(count != 2){
        return;
    }
    // Traverse AVL tree and print all artifacts with rarity >= minRarity.
    // You may choose any reasonable order (probably inorder) unless specified otherwise
    // in your PDF. Artifacts may be assigned or unassigned; print as required.

    int minRarity = stoi(tokens[1]);
    std::cout << "=== MATCH_RARITY " << minRarity << " ==="<< std::endl;
    artifactTree.traverseRarity(minRarity);
}

void ArtifactManager::handlePrintUnassigned(const std::string tokens[], int count)
{
    // Expected: PRINT_UNASSIGNED
    // TODO:
    if(count != 1){
        return;
    }
    // Print a header if needed, then call artifactTree.printUnassigned().
    std::cout << "Unassigned artifacts:" << std::endl;
    artifactTree.printUnassigned();
}

void ArtifactManager::handlePrintStats(const std::string tokens[], int count)
{
    // Expected: PRINT_STATS
    // TODO:
    if(count != 1){
        return;
    }
    // 1) Compute:
    //    - totalArtifacts (artifactTree.getArtifactCount())
    //    - totalResearchers (researcherTree.getResearcherCount())
    //    - average artifact rarity (floor of totalRarity / totalArtifacts)
    //    - average researcher load (floor of totalLoad / totalResearchers)
    // 2) Print summary lines exactly as in the spec.
    // 3) Then:
    //    - Print researchers using preorder traversal:
    //      researcherTree.traversePreOrderForStats()
    //    - Print artifacts using postorder traversal:
    //      artifactTree.traversePostOrderForStats()
    //    (Exact formatting defined in your PDF.)
    int artCount = artifactTree.getArtifactCount();
    int resCount = researcherTree.getResearcherCount();
    int totalRarity = artifactTree.getTotalRarity();
    int totalLoad = researcherTree.getTotalLoad();

    int avgRare;
    int avgLoad;

    if (artCount == 0){
        avgRare = 0;
    }
    else{
        avgRare = totalRarity / artCount;
    }

    if (resCount == 0){
        avgLoad = 0;
    }
    else{
        avgLoad = totalLoad / resCount;
    }
    
    std::cout << "=== SYSTEM STATISTICS ===" << std::endl;
    std::cout << "Artifacts: " << artCount << std::endl;
    std::cout << "Researchers: " << resCount << std::endl;
    std::cout << "Average rarity: " << avgRare << std::endl;
    std::cout << "Average load: " << avgLoad << std::endl;

    std::cout << "Researchers:" << std::endl;
    researcherTree.traversePreOrderForStats();
    std::cout << "Artifacts:" << std::endl;
    artifactTree.traversePostOrderForStats();
}

void ArtifactManager::handleClear(const std::string tokens[], int count)
{
    // Expected: CLEAR
    // TODO:
    if(count != 1){
        return;
    }
    // Clear both trees and print confirmation message.
    artifactTree.clear();
    researcherTree.clear();
    // e.g. "All data cleared."
    std::cout << "All data cleared." << std::endl;
}
