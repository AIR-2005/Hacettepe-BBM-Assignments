`timescale 1s/1ms
// ============================================================
// dead_hand.v  (STUDENT STARTER CODE)
// BBM233 Logic Design Laboratory
// Final Project: World War III – Dead Hand Protocol
//
// IMPORTANT:
// - Do NOT change module name or port list.
// - clk is 1 Hz (1 tick per second).
// - reset is synchronous, active-high.
// - Implement Main FSM + Engagement Sub-FSM.
// ============================================================

module dead_hand(
    input  wire       clk,
    input  wire       reset,
    input  wire [1:0] threat_level,
    input  wire       diplomatic_override,
    input  wire       comms_lost,
    input  wire       system_fault,

    output reg        armed_out,
    output reg        tracking_out,
    output reg        authorization_out,
    output reg        override_ignored,
    output reg [2:0]  main_state_out,
    output reg [1:0]  sub_state_out,
    output reg [31:0] timer_out
);
// Your code starts from here.
    reg[31:0] last_threat_change_time;
    reg[31:0] sub_timer;
    reg[31:0] main_timer;

    always @(posedge clk) begin

        //reset case
        if(reset) begin
            main_state_out <= 3'b000;
            sub_state_out <= 2'b11;
            armed_out <= 1'b0;
            tracking_out <= 1'b0;
            authorization_out <= 1'b0;
            override_ignored <= 1'b0;
            timer_out <= 0;  
            sub_timer <= 0;
            main_timer <= 0;
        end
        else begin
            timer_out <= timer_out + 1;

            //system fault case
            if((main_state_out < 3'b101) && (system_fault == 1'b1)) begin
                main_state_out <= 3'b101;
            end

            //override_ignored(deadlock and global war)
            if(diplomatic_override && main_state_out >= 3'b101)begin
                override_ignored <= 1'b1;
            end
            
            else begin
                //PEACE state
                if(main_state_out == 3'b000) begin
                    if(threat_level >= 2'b01)begin
                        //Escalate main state to ALERT
                        if(main_timer >= 4)begin
                            main_state_out <= 3'b001;
                            main_timer <= 0;
                        end
                        else begin
                            main_timer <= main_timer + 1;
                        end
                    end
                    else begin
                        main_timer <= 0;
                    end
                end
                //ALERT state
                else if(main_state_out == 3'b001) begin
                    if(threat_level >= 2'b10)begin
                        if(main_timer >= 9)begin
                            main_state_out <= 3'b010;
                            main_timer <= 0;
                        end
                        else begin
                            main_timer <= main_timer + 1;
                        end
                    end
                    else if(threat_level == 2'b00)begin
                        if(main_timer >= 3)begin
                            main_state_out <= 3'b000;
                            main_timer <= 0;
                        end
                        else begin
                            main_timer <= main_timer + 1;
                        end
                    end
                    else begin
                        main_timer <= 0;
                    end
                end
                //MOBILIZATION state
                else if(main_state_out == 3'b010) begin
                    if(threat_level == 2'b11 || comms_lost == 1'b1)begin
                        main_state_out <= 3'b011;
                        sub_state_out <= 2'b00;
                        armed_out <= 1'b1;
                        main_timer <= 0;
                        sub_timer <= 0;
                    end
                    else if(threat_level <= 2'b01)begin
                        if(main_timer >= 3)begin
                            main_state_out <= 3'b001;
                            main_timer <= 0;
                        end
                        else begin
                            main_timer <= main_timer + 1;
                        end
                    end
                    else begin
                        main_timer <= 0;
                    end
                end
                //Engagement state            
                else if (main_state_out == 3'b011)begin
                    //ARM sub state
                    if(sub_state_out == 2'b00)begin
                        if (sub_timer >= 3) begin
                                sub_state_out <= 2'b01;
                                sub_timer <= 0;
                                tracking_out <= 1'b1;
                        end 
                        else begin
                            sub_timer <= sub_timer + 1;
                        end
                    end
                    //TRACK sub state
                    else if(sub_state_out == 2'b01)begin
                        if (sub_timer >= 6) begin
                                sub_state_out <= 2'b10;
                                sub_timer <= 0;
                                authorization_out <= 1'b1;
                                tracking_out <= 1'b0;
                        end 
                        else begin
                            sub_timer <= sub_timer + 1;
                        end
                    end
                    //AUTHORIZE sub state
                    else if(sub_state_out == 2'b10)begin
                        //override_ignored(AUTHORIZE)
                        if (sub_timer >= 3) begin
                            main_state_out <= 3'b110;
                            sub_state_out <= 2'b11;
                            armed_out <= 1'b0;
                            authorization_out <= 1'b0;
                            tracking_out <= 1'b0;
                            sub_timer <= 0;
                        end
                        else begin
                            sub_timer <= sub_timer + 1;
                        end
                        if(diplomatic_override && sub_timer > 2)begin
                            override_ignored <= 1'b1;
                        end
                    end
                    //ABORT sub state
                    else if(sub_state_out == 2'b11) begin
                        if (sub_timer >= 5) begin
                            main_state_out <= 3'b010;
                            sub_timer <= 0;
                        end 
                        else begin
                            sub_timer <= sub_timer + 1;
                        end
                    end
                    //diplomatic_override
                    if (diplomatic_override == 1'b1 && override_ignored != 1'b1) begin
                        sub_state_out <= 2'b11;
                        armed_out <= 1'b0;
                        authorization_out <= 1'b0;
                        tracking_out <= 1'b0;
                        sub_timer <= 0;
                    end
                end
            end
        end
    end
endmodule

