`timescale 1ns/10ps
module multiplier_tb;

   // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
   reg[3:0] A;
   reg[1:0] B;
   wire [3:0] p1;
	wire [4:0] p2_shifted;
   integer i;
   integer j;

   multiplier uut(.A(A),.B(B),.p1(p1),.p2_shifted(p2_shifted));
   initial begin
      $dumpfile("multiplier.vcd");
      $dumpvars();
      for(i = 0; i < 16;i++) begin
         A = i[3:0];
         for(j = 0; j < 4;j++) begin
            B = j[2:0];
            #10;
         end
      end
      $finish;
   end

   

endmodule 
