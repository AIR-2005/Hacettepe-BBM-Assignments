`timescale 1ns/1ps
module main_tb;

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    reg [3:0] A;
    reg [1:0] B;
    reg multiply;
    wire [4:0] Result;
    wire Cout;
    integer i;
    integer j;

    main uut(.A(A),.B(B),.multiply(multiply),.Result(Result),.Cout(Cout));

    initial begin
        $dumpfile("main.vcd");
        $dumpvars();
        for(i = 0; i < 16;i++) begin
            multiply = 0;
            A = i[3:0];
            for(j = 0; j < 4;j++) begin
                B = j[1:0]; #10;
                multiply = 0; #10
                multiply = 1; #10;
            end
        end
        $finish;
    end
    
endmodule
