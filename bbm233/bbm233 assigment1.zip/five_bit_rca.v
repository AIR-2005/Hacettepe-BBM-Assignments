module five_bit_rca(
    input [4:0] A,
    input [4:0] B,
    input Cin,
    output [4:0] S,
    output Cout
);

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    wire C1,C2,C3,C4;
    
    full_adder f0(.A(A[0]),.B(B[0]),.Cin(Cin),.S(S[0]),.Cout(C1));
    full_adder f1(.A(A[1]),.B(B[1]),.Cin(C1),.S(S[1]),.Cout(C2));
    full_adder f2(.A(A[2]),.B(B[2]),.Cin(C2),.S(S[2]),.Cout(C3));
    full_adder f3(.A(A[3]),.B(B[3]),.Cin(C3),.S(S[3]),.Cout(C4));
    full_adder f4(.A(A[4]),.B(B[4]),.Cin(C4),.S(S[4]),.Cout(Cout));
endmodule