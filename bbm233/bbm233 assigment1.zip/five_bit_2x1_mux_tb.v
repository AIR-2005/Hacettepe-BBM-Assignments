`timescale 1ns/10ps
module five_bit_2x1_mux_tb;
	
	// Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
	reg [4:0] In_1;
	reg [4:0] In_0;
	reg Select;
	wire [4:0] Out;
	integer i;
	integer j;

	five_bit_2x1_mux uut(.In_0(In_0),.In_1(In_1),.Select(Select),.Out(Out));

	initial begin
		$dumpfile("five_bit_2x1_mux.vcd");
		$dumpvars();
		for(i = 0; i < 32; i++) begin
			In_0 = i[4:0];
			for(j = 0; j < 32; j++) begin
				In_1 = j[4:0];
				Select = 1'b0; #10;
				Select = 1'b1; #10;
			end
		end
		$finish;
	end
endmodule
