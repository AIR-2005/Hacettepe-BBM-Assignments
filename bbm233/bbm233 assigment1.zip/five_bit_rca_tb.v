`timescale 1 ns/10 ps
module five_bit_rca_tb;

  // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
	reg [4:0] A;
	reg [4:0] B;
	reg Cin;
	wire [4:0] S;
	wire Cout;
	integer i;
	integer j;


	five_bit_rca uut(.A(A),.B(B),.Cin(Cin),.S(S),.Cout(Cout));

	initial begin
		$dumpfile("five_bit_rca.vcd");
		$dumpvars();
		for(i = 0; i < 32; i++) begin
			A = i[4:0];
			for(j = 0; j < 32; j++) begin
				B = j[4:0];
				Cin = 1'b0; #10;
				Cin = 1'b1; #10;
			end
		end
		$finish;
  	end

endmodule