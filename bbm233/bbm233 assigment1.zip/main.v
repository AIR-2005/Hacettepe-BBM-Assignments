module main(A, B, multiply, Result, Cout);
    input [3:0] A;
    input [1:0] B;
    input multiply;
    output [4:0] Result;
    output Cout;

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    wire [3:0] p1; wire [4:0] p2,w1,w2;
    multiplier mul1(.A(A),.B(B),.p1(p1),.p2_shifted(p2));
    five_bit_2x1_mux mux1(.In_0({3'b000, B}),.In_1(p2),.Select(multiply),.Out(w1));
    five_bit_2x1_mux mux2(.In_0({1'b0, A}),.In_1({1'b0, p1}),.Select(multiply),.Out(w2));
    five_bit_rca rca1(.A(w1),.B(w2),.Cin(1'b0),.S(Result),.Cout(Cout));

endmodule
