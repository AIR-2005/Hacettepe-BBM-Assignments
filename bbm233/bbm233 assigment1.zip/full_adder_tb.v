`timescale 1 ns/10 ps
module full_adder_tb;

    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!

    reg A;
    reg B;
    reg Cin;
    wire S;
    wire Cout;
    integer i;

    full_adder uut(.A(A),.B(B),.Cin(Cin),.S(S),.Cout(Cout));
    initial begin
        $dumpfile("full_adder.vcd");
        $dumpvars();
        for(i = 0; i < 8; i++) begin
            {A,B,Cin} = i[3:0];
            #10;
        end
        $finish;
    end

endmodule