module multiplier (
    input [3:0] A,
    input [1:0] B,
    output [3:0] p1,
	output [4:0] p2_shifted
);
    
    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    assign p1[0] = A[0] & B[0];
    assign p1[1] = A[1] & B[0];
    assign p1[2] = A[2] & B[0];
    assign p1[3] = A[3] & B[0];

    assign p2_shifted[0] = 1'b0;
    assign p2_shifted[1] = A[0] & B[1];
    assign p2_shifted[2] = A[1] & B[1];
    assign p2_shifted[3] = A[2] & B[1];
    assign p2_shifted[4] = A[3] & B[1];


endmodule  
