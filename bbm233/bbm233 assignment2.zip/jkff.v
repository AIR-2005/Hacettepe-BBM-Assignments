module jkff (
    input J,      // Data input
    input K,      // Data input
    input CLK,    // Clock input
    input RESET,  // Asynchronous reset, active high
    output reg Q  // Output
);
    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    always@(posedge CLK or posedge RESET)
    begin
        if(RESET)
            Q <= 1'b0;
        else
            Q <= (J & ~Q) | (~K & Q);
    end
endmodule