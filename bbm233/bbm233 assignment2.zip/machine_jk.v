module machine_jk(
    input wire x,
    input wire CLK,
    input wire RESET,
    output wire F,
    output wire [2:0] S
);
    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    assign F = S[2] & S[1]; 
    jkff jk2(.J((S[1] & S[0] & ~x)|(~S[1] & S[0] & x)),.K((S[0] & ~x)|(S[1])),.CLK(CLK),.RESET(RESET),.Q(S[2]));
    jkff jk1(.J((S[2] & ~S[0] & ~x)|(~S[2] & ~S[0] & x)),.K((S[2])|(~S[0] & ~x)),.CLK(CLK),.RESET(RESET),.Q(S[1]));
    jkff jk0(.J((~S[2])|(~S[1] & x)),.K(1),.CLK(CLK),.RESET(RESET),.Q(S[0]));
endmodule