`timescale 1ns / 1ps

module machine_jk_tb;
    // Your code goes here.  DO NOT change anything that is already given! Otherwise, you will not be able to pass the tests!
    reg x;
    reg CLK;
    reg RESET;
    wire F;
    wire [2:0] S;
    integer i;

    machine_jk uut(.x(x),.CLK(CLK),.RESET(RESET),.F(F),.S(S));

    always begin
        #5;
        CLK = ~CLK; 
    end
    initial begin
        $dumpfile("machine_d.vcd");
        $dumpvars();
        CLK = 0;
        RESET = 1'b1;
        x = 1'b0;
        #100;
        RESET = 1'b0;
        for(i = 0; i < 2; i++) begin
            x = i[0];
            #100;
        end
        $finish;
    end
endmodule
