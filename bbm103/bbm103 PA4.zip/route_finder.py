import sys

def file_input_to_list(input_file):
    """Returns given input file as a list of path and a list of costs"""
    path = []
    list_of_cost = []
    f = open(input_file,"r")
    for i,line in enumerate(f.readlines()):
        if i == 0:
            for cost in line.split():
                list_of_cost.append(int(cost))
        else:
            path.append(line.split())
    f.close()
    return path, list_of_cost

def find_cost(y,x,path,list_of_costs):
    """Returns the cost of a tile"""
    #Set boundaries for y and x values next to our tile to prevent errors
    if y <= 0:
        y_low = 0
    else:
        y_low = y - 1

    if y >= len(path) - 1:
        y_high = len(path) - 1
    else:
        y_high = y + 1

    if x <= 0:
        x_low = 0
    else:
        x_low = x - 1

    if x >= len(path[0]) - 1:
        x_high = len(path[0]) - 1
    else:
        x_high = x + 1

    if "0" in [path[y][x_high], path[y_high][x], path[y_low][x], path[y][x_low]]:
        return list_of_costs[2]  #Cost 3
    elif "0" in [path[y_high][x_high], path[y_low][x_high], path[y_high][x_low], path[y_low][x_low]]:
        return list_of_costs[1]  #Cost 2
    else:
        return list_of_costs[0]  #Cost 1


def find_shortest_path(given_path_list, list_of_costs):
    """Returns the lowest cost path in a given path list"""
    def move(y, x, location_history, path, low_cost_path,low_cost,current_cost):
        """Recursive move function for finding the lowest cost path"""
        possible_directions = ((0,1), (-1,0), (1,0), (0,-1))
        for y_change,x_change in possible_directions:
            next_y = y + y_change
            next_x = x + x_change
            #Case where next tile is at the last column
            if next_x == len(path[0]) - 1 and 0 <= next_y <= len(path) - 1 and path[next_y][next_x] != "0" and [next_y,next_x] not in location_history:
                #Add next tile and its cost
                location_history.append([next_y, next_x])
                current_cost += find_cost(next_y,next_x,path,list_of_costs)
                #Check if current path's cost(including next tile) is lower than the lowest cost path found so far
                if low_cost_path == None or (low_cost_path != None and current_cost < low_cost):
                    low_cost_path = location_history.copy()
                    low_cost = current_cost
                #Remove next tile and its cost and try the next direction
                current_cost += find_cost(next_y, next_x, path, list_of_costs)
                location_history.remove([next_y,next_x])
            #Case where next tile is not at the last column
            elif 0 <= next_y <= len(path) - 1 and 0 <= next_x < len(path[0]) - 1 and path[next_y][next_x] != "0" and [next_y,next_x] not in location_history:
                #Add next tile and its cost
                location_history.append([next_y,next_x])
                current_cost += find_cost(next_y, next_x, path, list_of_costs)
                #Check if current path's cost(including next tile) is greater than the lowest cost path's cost so far
                if low_cost_path != None and current_cost >= low_cost:
                    #Remove next tile and its cost and try the next direction
                    current_cost -= find_cost(next_y, next_x, path, list_of_costs)
                    location_history.remove([next_y,next_x])
                else:
                    low_cost,low_cost_path = move(next_y,next_x,location_history,path,low_cost_path,low_cost,current_cost) #Move to the next tile
                    #Remove next tile and its cost and try the next direction
                    current_cost -= find_cost(next_y, next_x, path, list_of_costs)
                    location_history.remove([next_y,next_x])
            else:
                continue
        return low_cost,low_cost_path

    #Check each starting tile at the beginning column
    lowest_cost_path = None
    lowest_cost = None
    for row in range(len(given_path_list)):
        if given_path_list[row][0] != "0": #Checks if the starting tile is 0
            starting_cost = find_cost(row,0,given_path_list,list_of_costs)
            #Lowest cost path and its cost for given starting tile
            latest_cost,latest_path = move(row,0,[[row,0]],given_path_list.copy(),None,None,starting_cost)
            #Compare given starting tiles path and lowest cost path found so far
            if lowest_cost_path == None and lowest_cost == None or latest_cost < lowest_cost:
                lowest_cost,lowest_cost_path = latest_cost,latest_path
        else:
            continue
    return lowest_cost,lowest_cost_path

def write_output(output_location_history,output_cost,path,output_file_path):
    """Writes the output file to the given file path"""
    f = open(output_file_path,"w")
    if output_location_history == None:
        f.write("There is no possible route!")
    else:
        for y,x in output_location_history:
            path[y][x] = "X" #Mark the path according to given location history
        f.write(f"Cost of the route: {output_cost}\n")
        for i in range(len(path)):
            line = path[i]
            for j in range(len(line)):
                if j == len(line) - 1:
                    f.write(line[j])
                else:
                    f.write(line[j] + " ")
            if i != len(path) - 1:
                f.write("\n")
    f.close()

def main():
    """Main function"""
    path_list, cost_list = file_input_to_list(sys.argv[1])
    found_cost,found_path = find_shortest_path(path_list, cost_list)
    write_output(found_path,found_cost,path_list.copy(),sys.argv[2])

if __name__ == "__main__":
    main()


