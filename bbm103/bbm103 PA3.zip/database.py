import sys

#Get the rows where conditions are satisfied (also returns error column if a column error is detected)
def condition_check(conditions, table_rows, table_info):
        conditions_id = {}
        selected_rows = []
        if len(conditions) == 0 or conditions == "*": #If no conditions are given all rows are returned
            selected_rows = table_rows
        else:
            try:
                for condition in conditions:
                    column = condition.split(": ")[0].strip("\" ")
                    error_column = column
                    column_id = table_info.index(column)
                    value = condition.split(": ")[1].strip("\" ")
                    conditions_id[column_id] = value
            except ValueError:
                return selected_rows, error_column

            for row in table_rows:
                is_met_condition = True
                for i, value in conditions_id.items():
                    if row[i] != value:
                        is_met_condition = False
                if is_met_condition:
                    selected_rows.append(row)
        return selected_rows, None

#Print the output of given table
def table_output(table,table_name):
    #A function for printing filler lines
    def print_filler():
        print("+",end="")
        for length in column_len_list:
            print("-" * length, end="")
            print("+",end="")
        print()

    column_len_list = []
    for i in range(len(table[0])):
        largest_len = 0
        for row in table:
            if len(row[i]) > largest_len:
                largest_len = len(row[i])
        column_len_list.append(largest_len + 2)

    print()
    print(f"Table: {table_name}")
    print_filler()
    write_column_names = True
    for row in table:
        print("|", end="")
        for i in range(len(row)):
            column_len = column_len_list[i]
            element = row[i]
            column_str = " " + element + " " * (column_len - len(element) - 1)
            print(column_str,end="")
            print("|", end="")
        print()
        if write_column_names:
            print_filler()
            write_column_names = False
    print_filler()

#CREATE_TABLE Function(Creates a table with the given name and columns)
def create_table_db(cmd_line,database):

    new_database = database
    table_name = cmd_line.split(" ",1)[0]
    columns = cmd_line.split(" ",1)[1].split(",")
    new_database[table_name] = [columns]

    #Output
    print(f"Table \'{table_name}\' created with columns: ",end="")
    print(columns)

    return new_database

#INSERT Function(Inserts a row into the given table)
def insert_db(cmd_line, database):
    try:
        new_database = database
        table_name = cmd_line.split(" ",1)[0]
        data = list(cmd_line.split(" ",1)[1].split(","))

        new_database[table_name].append(data)

        #Output
        data_out = str(data).replace("[", "(").replace("]", ")")
        print(f"Inserted into '{table_name}': " + data_out)
        table_output(new_database[table_name],table_name)

        return new_database
    except KeyError: #Table Error
        print(f"Table {table_name} not found")
        data_out = str(data).replace("[", "(").replace("]", ")")
        print(f"Inserted into '{table_name}': " + data_out)
        return database

#SELECT function(Selects rows which satisfies the conditions)
def select_db(cmd_line, database):
    try:
        error_column = None
        is_error = False

        # Checking if conditions are stated or not
        if "WHERE" not in cmd_line:
            conditions = ""
            parameters_before_where = cmd_line
            conditions_out = "*"
        else:
            parameters_before_where = cmd_line.split(" WHERE")[0]
            conditions = cmd_line.split("WHERE ")[1].strip(" {}").split(",")
            conditions_out = str(cmd_line.split("WHERE ")[1]).replace("\"", "'")

        table_name = parameters_before_where.split(" ", 1)[0]
        table_info = database[table_name][0]
        table_rows = database[table_name][1:]

        #Get the wanted columns of the selected rows and compare wanted columns and tables columns for errors
        wanted_columns = parameters_before_where.split(" ", 1)[1].strip()
        if wanted_columns == "*":
            wanted_columns_list = table_info
        else:
            wanted_columns_list = wanted_columns.split(",")

        wanted_columns_id = []
        info_of_selected_rows = []

        for column in wanted_columns_list:

            if column not in table_info:
                error_column = column
                raise ValueError
            for i in range(len(table_info)):
                if table_info[i] == column:
                    wanted_columns_id.append(i)

        #Get the rows where conditions are satisfied
        selected_rows,error_column = condition_check(conditions,table_rows, table_info)
        if error_column is not None:
            raise ValueError

        #Add the wanted columns of the selected rows to a list
        for row in selected_rows:
            current_row = []
            for i in wanted_columns_id:
                current_row.append(row[i])
            info_of_selected_rows.append(current_row)

    except KeyError: #Table Error
        print(f"Table {table_name} not found")
        is_error = True
    except ValueError: #Column Error
        print(f"Column {error_column.strip()} does not exist")
        is_error = True
    #Output
    finally:
        print(f"Condition: {conditions_out}")
        print(f"Select result from '{table_name}':", end=" ")
        if is_error:
            print("None")
        else:
            print("[", end="")
            i = 1
            for row in info_of_selected_rows:
                row_out = str(row).replace("[", "(").replace("]", ")")
                print(row_out, end="")
                if i < len(info_of_selected_rows):
                    print(", ",end="")
                i += 1
            print("]")

#UPDATE function(Updates the given columns of rows which satisfies the conditions)
def update_db(cmd_line, database):
    try:
        error_column = None

        # Checking if conditions are stated or not
        if "WHERE" not in cmd_line:
            conditions = ""
            parameters_before_where = cmd_line
            conditions_out = "*"
        else:
            parameters_before_where = cmd_line.split(" WHERE")[0]
            conditions = cmd_line.split("WHERE ")[1].strip(" {}").split(",")
            conditions_out = str(cmd_line.split("WHERE ")[1]).replace("\"", "'")

        table_name = parameters_before_where.split(" ", 1)[0]
        updates = parameters_before_where.split(" ", 1)[1].strip(" {}").split(", ")
        updates_out = str(parameters_before_where.split(" ", 1)[1]).replace("\"", "'")
        table_info = database[table_name][0]
        table_rows = database[table_name][1:]
        new_database = database

        #Get the rows where conditions are satisfied
        selected_rows,error_column = condition_check(conditions, table_rows, table_info)
        if error_column != None:
            raise ValueError

        #Update the selected rows
        updates_id = {}
        updated_rows = database[table_name]

        for update in updates:
            column = update.split(":")[0].strip("\" ")
            if column not in table_info:
                error_column = column
                raise ValueError
            column_id = table_info.index(column)
            value = update.split(":")[1].strip("\" ")
            updates_id[column_id] = value

        for row in updated_rows:
            if row in selected_rows:
                for i, value in updates_id.items():
                    row[i] = value

        updated_row_count = len(selected_rows)
        new_database[table_name] = updated_rows

        #Output
        print(f"Updated '{table_name}' with {updates_out} where {conditions_out}")
        print(f"{updated_row_count} rows updated.")
        table_output(new_database[table_name], table_name)

        return new_database
    except KeyError: #Table Error
        updated_row_count = 0
        print(f"Updated '{table_name}' with {updates_out} where {conditions_out}")
        print(f"Table {table_name} not found")
        print(f"{updated_row_count} rows updated.")
        return database
    except ValueError: #Column Error
        updated_row_count = 0
        print(f"Updated '{table_name}' with {updates_out} where {conditions_out}")
        print(f"Column {error_column} does not exist")
        print(f"{updated_row_count} rows updated.")
        table_output(new_database[table_name], table_name)
        return database

#DELETE function(Deletes the rows where conditions are satisfied)
def delete_db(cmd_line, database):
    try:
        error_column = None

        # Checking if conditions are stated or not
        if "WHERE" not in cmd_line:
            conditions = ""
            parameters_before_where = cmd_line
            table_name = parameters_before_where
            conditions_out = "*"
        else:
            parameters_before_where = cmd_line.split(" WHERE")[0]
            conditions = cmd_line.split("WHERE ")[1].strip(" {}").split(",")
            table_name = parameters_before_where.split(" ", 1)[0]
            conditions_out = str(cmd_line.split("WHERE ")[1]).replace("\"", "'").strip()

        table_info = database[table_name][0]
        table_rows = database[table_name][1:]

        # Get the rows where conditions are satisfied
        selected_rows,error_column = condition_check(conditions, table_rows, table_info)
        if error_column != None:
            raise ValueError

        #Delete the selected rows
        updated_rows = database[table_name]
        for row in table_rows:
            if row in selected_rows:
                updated_rows.remove(row)

        new_database = database
        new_database[table_name] = updated_rows
        deleted_row_count = len(selected_rows)

        #Output
        print(f"Deleted from '{table_name}' where {conditions_out}")
        print(f"{deleted_row_count} rows deleted.")
        table_output(database[table_name],table_name)

        return new_database
    except KeyError: #Table Error
        updated_row_count = 0
        print(f"Deleted from '{table_name}' where {conditions_out}")
        print(f"Table {table_name} not found")
        print("0 rows deleted.")
        return database
    except ValueError: #Column Error
        updated_row_count = 0
        print(f"Deleted from '{table_name}' where {conditions_out}")
        print(f"Column {error_column} does not exist")
        print("0 rows deleted.")
        table_output(database[table_name],table_name)
        return database

#JOIN function(joins the given tables and prints an output)
def join_db(cmd_line,database):
    try:
        table_name = ""
        common_column = cmd_line.split("ON ")[1]
        table_list = cmd_line.split(" ON")[0].split(",")

        table1 = table_list[0]
        table2 = table_list[1]

        table_name = table1
        table1_columns = database[table1][0]
        table_name = table2
        table2_columns = database[table2][0]

        table_name = table1
        table1_rows = database[table1][1:]
        table_name = table2
        table2_rows = database[table2][1:]

        #Checking if given column exist in table 1 or table 2
        if common_column not in table1_columns or common_column not in table2_columns:
            error_column = common_column
            raise ValueError

        #Joining Tables
        table1_common_column_id = table1_columns.index(common_column)
        table2_common_column_id = table2_columns.index(common_column)

        joined_columns = table1_columns + table2_columns
        joined_table = [joined_columns]

        for row1 in table1_rows:
            for row2 in table2_rows:
                if row1[table1_common_column_id] == row2[table2_common_column_id]:
                    joined_row = row1 + row2
                    joined_table.append(joined_row)
        #Output
        print(f"Join tables {table1} and {table2}")
        print(f"Join result ({len(joined_table) - 1} rows):")
        table_output(joined_table,"Joined Table")
    except KeyError:
        print(f"Join tables {table1} and {table2}")
        print(f"Table {table_name} does not exist")
    except ValueError:
        print(f"Join tables {table1} and {table2}")
        print(f"Column {error_column} does not exist")

#COUNT function(Counts the rows where conditions are satisfied)
def count_db(cmd_line,database):
    try:
        # Checking if conditions are stated or not
        if "WHERE" not in cmd_line:
            conditions = ""
            parameters_before_where = cmd_line
        else:
            parameters_before_where = cmd_line.split(" WHERE")[0]
            conditions = cmd_line.split("WHERE ")[1].strip(" {}").split(",")

        table_name = parameters_before_where.split(" ", 1)[0]
        table_info = database[table_name][0]
        table_rows = database[table_name][1:]

        #Get the rows where conditions are satisfied
        selected_rows,error_column = condition_check(conditions, table_rows, table_info)
        if error_column != None:
            raise ValueError

        #Count the selected rows
        count = len(selected_rows)

        #Output
        print(f"Count: {count}")
        print(f"Total number of entries in '{table_name}' is {count}")
    except KeyError:#Table Error
        print(f"Table {table_name} not found")
        print(f"Total number of entries in '{table_name}' is 0")
    except ValueError:#Column Error
        print(f"Column {error_column} does not exist")
        print(f"Total number of entries in '{table_name}' is 0")


#Main Function
def main():
    try:
        input_file = open(sys.argv[1])
    except IOError:
        print("File can not be found!")
    except:
        print("Something went wrong!")

    database = {}
    try:
        for command_line in input_file.readlines():
            command_line = command_line.strip("\n")
            command = command_line.split(" ", 1)[0]
            cmd_line_except_cmd = command_line.split(" ", 1)[1]
            if command == "CREATE_TABLE":
                print(f"###################### CREATE #########################")
                database = create_table_db(cmd_line_except_cmd,database)
            elif command == "INSERT":
                print(f"###################### INSERT #########################")
                database = insert_db(cmd_line_except_cmd, database)
            elif command == "SELECT":
                print(f"###################### SELECT #########################")
                select_db(cmd_line_except_cmd,database)
            elif command == "UPDATE":
                print(f"###################### UPDATE #########################")
                database = update_db(cmd_line_except_cmd,database)
            elif command == "DELETE":
                print(f"###################### DELETE #########################")
                database = delete_db(cmd_line_except_cmd,database)
            elif command == "JOIN":
                print(f"####################### JOIN ##########################")
                join_db(cmd_line_except_cmd,database)
            elif command == "COUNT":
                print(f"###################### COUNT #########################")
                count_db(cmd_line_except_cmd, database)
            else:
                print("#######################################################")
                raise SyntaxError
            print("#######################################################")
            print()
    except:
        print("Invalid Input Line")
        print("#######################################################")

if __name__ == "__main__":
    main()