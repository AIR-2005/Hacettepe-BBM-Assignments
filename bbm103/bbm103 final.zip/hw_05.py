import os
# Custom pseudorandom number generator with a random initial seed
class PRNG:
    def __init__(self, seed=None):
        # Use a truly random seed if no seed is provided
        if seed is None:
            seed = int.from_bytes(os.urandom(4), 'big')  # Generate a random 32-bit integer
        self.state = seed

    def randint(self, low, high):
        # Simple linear congruential generator (LCG)
        self.state = (1103515245 * self.state + 12345) % (2**31)
        return low + (self.state % (high - low + 1))

# Generate logistics dataset
def generate_logistics_dataset(num_warehouses=100, max_packages=1000, seed=None):
    """Generates a logistics dataset with a random or specified seed."""
    prng = PRNG(seed)  # Initialize PRNG with the seed or a random one
    data = []
    for i in range(1, num_warehouses + 1):
        warehouse_id = f"WH-{str(i).zfill(3)}"
        priority_level = prng.randint(1, 5)
        package_count = prng.randint(0, max_packages)
        data.append([warehouse_id, priority_level, package_count])
    return data

# Save dataset to a CSV file
def save_to_csv(data, file_name):
    """Saves the dataset to a CSV file."""
    with open(file_name, "w") as file:
        # Write the header
        file.write("Warehouse_ID,Priority_Level,Package_Count\n")
        # Write each row
        for row in data:
            file.write(",".join(map(str, row)) + "\n")


######### YOUR CODE GOES HERE ---  You should define here two_level_sorting and the 3 sorting functions
def two_level_sorting(sort_type, data):
    """Two Level Sorting"""
    try:
        global counter
        #Return data if it has length of 1 or 0
        if len(data) <= 1:
            return data, 0, 0

        counter = 0
        pl_list = [[element[1], element[0], element[2]] for element in data] #Create a new list with order of [Priority_Level,Warehouse_Name,Package Count]
        sorted_pl_list = sort_type(pl_list) #Sort given list by priority level
        pl_count = counter #Set priority level count to counter

        counter = 0
        sorted_pc_list = []
        last_split = 0 #Variable to keep last index where list was split
        #Split every priority level and sort them
        for i in range(len(sorted_pl_list) - 1): #Priority levels except last one
            if sorted_pl_list[i][0] != sorted_pl_list[i + 1][0]: #Case where current element's and next element's priority level is different
                split_list = [x[::-1] for x in sorted_pl_list[last_split:i + 1]] #Create a new split list with order of [Package Count,Warehouse_Name,Priority_Level]
                sorted_split_list = sort_type(split_list)  # Sort given list by package count
                sorted_pc_list.extend(sorted_split_list)  # Add sorted split list to sorted package count list
                last_split = i + 1  # Save last split index
            elif i+1 == len(sorted_pl_list) - 1: #Last priority level
                split_list = [x[::-1] for x in sorted_pl_list[last_split:]] #Create a new split list with order of [Package Count,Warehouse_Name,Priority_Level]
                sorted_split_list = sort_type(split_list) #Sort given list by package count
                sorted_pc_list.extend(sorted_split_list) #Add sorted split list to sorted package count list
        pc_count = counter
        final_list = [[x[1],x[2],x[0]] for x in sorted_pc_list] #Arrange sorted list into order of [Warehouse_Name,Priority_Level,Package Count]

        return final_list,pl_count,pc_count
    except: #Error
        print("Comparison went wrong")
        return [], 0, 0
    
### Your three sorting functions should have global variable named as counter. So do not return it.
def bubble_sort(array):
    """Bubble Sort"""
    global counter
    n = len(array) - 1
    for i in range(n, 0, -1):#From last index to index 1
        for j in range(i):#From index 0 to index i
            counter += 1
            #Swap if next element is smaller
            if array[j] > array[j+1]:
                array[j], array[j+1] = array[j+1], array[j]
    return array

def merge_sort(array):
    """Merge Sort"""
    def merge(half1, half2):
        """Merge function"""
        global counter
        merged_list = []
        i1 = 0 #First half's index
        i2 = 0 #Second half's index

        #While both halves are in range of their index
        while i1 < len(half1) and i2 < len(half2):
            #If second half's element is smaller than first half's element
            if half2[i2] < half1[i1]:
                counter += 1
                merged_list.append(half2[i2]) #Add second half's element to merged list
                i2 += 1 #Move to the next index for second half
            else:
                merged_list.append(half1[i1]) #Add first half's element to merged list
                i1 += 1 #Move to the next index for first half

        #Add remaining elements to the merged list
        merged_list.extend(half1[i1:])
        merged_list.extend(half2[i2:])
        return merged_list

    #Return the array itself if length of array is 1 or 0
    if len(array) <= 1:
        return array
    #Else split the array in half, sort the halves, then merge them
    else:
        midpoint = len(array)// 2
        return merge(merge_sort(array[:midpoint]),merge_sort(array[midpoint:]))

def quick_sort(array):
    """Quick Sort"""
    global counter
    array_len = len(array)
    #Return array if array length is 1 or 0
    if array_len <= 1:
        return array
    else:
        counter += 1
        midpoint = array_len // 2
        pivot = array[midpoint][0] #Pivot value
        pivots = []
        smaller_list = []
        larger_list = []
        for element in array:
            #If element's first value is equal to pivot's value
            if element[0] == pivot:
                pivots.append(element) #Add to pivot list
            #If element's first value is less than pivot's value
            elif element[0] < pivot:
                smaller_list.append(element) #Add to smaller list
            #If element's first value is bigger than pivot's value
            elif element[0] > pivot:
                larger_list.append(element) #Add to larger list
        return quick_sort(smaller_list) + pivots + quick_sort(larger_list)

#########

def write_output_file(
    bubble_sorted, merge_sorted, quick_sorted,
    bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
    bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
    merge_check, quick_check
):
    """Write sorted results and comparisons to the output file."""
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as file:
        file.write("=== Bubble Sorted Results ===\n")
        # file.write(bubble_sorted.to_string() + "\n\n")
        file.write("Warehouse_ID  Priority_Level  Package_Count\n")
        file.write("-" * 40 + "\n")
        for row in bubble_sorted:
            file.write(f"{row[0]:<12}  {row[1]:<14}  {row[2]:<13}\n")
        file.write("\n")
        file.write("=== Comparison Results ===\n")
        if merge_check:
            file.write("Merge and Bubble sorts are identical.\n")
        else:
            file.write("Merge and Bubble sorts differ.\n")
        
        if quick_check:
            file.write("Quick and Bubble sorts are identical.\n")
        else:
            file.write("Quick and Bubble sorts differ.\n")
        
        file.write("\n=== Sort Performance Metrics ===\n")
        file.write(f"Bubble priority sort iteration count: {bubble_sort_pl_iterations}\n")
        file.write(f"Merge priority sort n_of right array is smaller than left: {merge_sort_pl_counter}\n")
        file.write(f"Quick priority sort recursive step count: {quick_sort_pl_counter}\n\n")
        
        file.write(f"Bubble package count sort iteration count: {bubble_sort_pc_iterations}\n")
        file.write(f"Merge package count n_of right array is smaller than left: {merge_sort_pc_counter}\n")
        file.write(f"Quick package count sort recursive step count: {quick_sort_pc_counter}\n")
    
    print(f"Results written to {OUTPUT_FILE}")
    
if __name__ == "__main__":
    # File paths and dataset size
    # Specify paths for input and output files
    INPUT_FILE = "hw05_input.csv"   # Path where the generated dataset will be saved
    OUTPUT_FILE = "hw05_output.txt"  # Path where the sorted results and metrics will be saved
    SIZE = 10  # Number of warehouses in the dataset

    # Generate the dataset
    dataset = generate_logistics_dataset(SIZE, max_packages=100)  # Generate a dataset with SIZE warehouses and max_packages packages
    
    # Save the generated dataset to the input file
    save_to_csv(dataset, INPUT_FILE)


    ###############################################################################################################
    # Perform sorting and counting operations
    # Sort using Bubble Sort and count iterations for Priority Level (_pl_) and Package Count (_pc_)
    bubble_sorted, bubble_sort_pl_iterations, bubble_sort_pc_iterations = two_level_sorting(bubble_sort, dataset)
    
    # Sort using Merge Sort and count recursive steps for Priority Level and Package Count
    merge_sorted, merge_sort_pl_counter, merge_sort_pc_counter = two_level_sorting(merge_sort, dataset)
    
    # Sort using Quick Sort and count recursive steps for Priority Level and Package Count
    quick_sorted, quick_sort_pl_counter, quick_sort_pc_counter = two_level_sorting(quick_sort, dataset)

    ###############################################################################################################
    
    
    # Comparisons
    # Check if Merge Sort results match Bubble Sort results
    merge_check = merge_sorted == bubble_sorted

    # Check if Quick Sort results match Bubble Sort results
    quick_check = quick_sorted == bubble_sorted

    # Write results and metrics to the output file
    write_output_file(
        bubble_sorted, merge_sorted, quick_sorted,
        bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
        bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
        merge_check, quick_check
    )


   
