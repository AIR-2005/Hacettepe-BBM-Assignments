import sys
import locale

locale.setlocale(locale.LC_ALL, "en_US")

#Function for getting text from given file
def get_input():
    inp = open(sys.argv[1],"r")
    text = inp.read()
    inp.close()
    return text

#Gives a list of each word in a text that's given without punctuations and white-space
def give_list(text):
    text_list = text.split()
    word_list = []

    for word in text_list:

        while not word[0].isalnum():
            word = word[1:]
        while not word[-1].isalnum():
            word = word[:-1]

        word = word.lower()
        word_list.append(word)

    return word_list

#Gives amount of words in a text
def count_words(text):
    word_list = give_list(text)
    count = len(word_list)
    return count

#Gives amount of sentences in a text
def count_sentence(text):
    count = 0
    for end in [".", "!", "?"]:
        count += text.count(end)
    #Makes triple dots counted as 1 instead of 3
    for end in ["..."]:
        count -= 2 * text.count(end)
    return count

#Gives average number of words per sentence in a text
def avg_num_words(word_count, sentence_count):
    count = word_count / sentence_count
    return count


#Gives amount of characters in a text
def char_count_all(text):
    count = len(text)
    return count

#Gives amount of characters(excluding punctuations and white-spaces) in a text
def char_count_exclude(text):
    word_list = give_list(text)
    count = 0

    for word in word_list:
        word_len = len(word)
        count += word_len

    return count

#Gives a dictionary with frequency of each unique word
def count_frequency(text):
    word_list = give_list(text)
    word_count = {}

    for word in word_list:
        if not word in word_count:
            word_count[word] = word_list.count(word) / len(word_list)

    word_count = dict(sorted(word_count.items()))
    word_count = dict(sorted(word_count.items(), key= lambda word_item: word_item[1], reverse=True))

    return word_count

#Returns the shortest words and their length
def shortest_words(text, word_frequency):
    word_list = give_list(text)
    words = [word_list[0]]
    length = len(word_list[0])

    for word in word_list:
        if word not in words:
            if length > len(word):
                words = [word]
                length = len(word)
            elif length == len(word):
                words.append(word)

    words.sort()

    return words

#Returns the longest words and their length
def longest_words(text, word_frequency):
    word_list = give_list(text)
    words = [word_list[0]]
    length = len(word_list[0])

    for word in word_list:
        if word not in words:
            if length < len(word):
                words = [word]
                length = len(word)
            elif length == len(word):
                words.append(word)

    words.sort()

    return words

#Creates an output text file using given parameters
def create_output(word_num, sent_num, avg_num, char_num, char_num_exc, short_words, long_words, word_frequency):
    out = open(sys.argv[2], "w")
    out.write(f"Statistics about {sys.argv[1]:7}:\n")
    out.write("{:24}: {}\n".format("#Words", word_num))
    out.write("{:24}: {}\n".format("#Sentences",sent_num))
    out.write("{:24}: {:.2f}\n".format("#Words/#Sentences",avg_num))
    out.write("{:24}: {}\n".format("#Characters",char_num))
    out.write("{:24}: {}\n".format("#Characters (Just Words)",char_num_exc))

    if len(short_words) == 1:
        out.write("{:24}: {:24} ({:.4f})\n".format("The Shortest Word",short_words[0],word_frequency[short_words[0]]))
    else:
        out.write("{:24}:\n".format("The Shortest Words"))
        for word in short_words:
            out.write("{:24} ({:.4f})\n".format(word,word_frequency[word]))

    if len(long_words) == 1:
        out.write("{:24}: {:24} ({:.4f})\n".format("The Longest Word",long_words[0],word_frequency[long_words[0]]))
    else:
        out.write("{:24}:\n".format("The Longest Words"))
        for word in long_words:
            out.write("{:24} ({:.4f})\n".format(word, word_frequency[word]))

    out.write("{:24}:\n".format("Words and Frequencies"))

    i = 0 #Prevents writing a new line character at the end of output
    for word in word_frequency.items():
        out.write("{:24}: {:.4f}".format(word[0],word[1]))
        i += 1
        if i != len(word_frequency):
            out.write("\n")
    out.close()

#Main Function
def main():
    text = get_input()
    word_num = count_words(text)
    sent_num = count_sentence(text)
    avg_num = avg_num_words(word_num, sent_num)
    char_count = char_count_all(text)
    char_count_exc = char_count_exclude(text)
    word_frequency = count_frequency(text)
    short_words = shortest_words(text, word_frequency)
    long_words = longest_words(text, word_frequency)
    create_output(word_num,sent_num,avg_num,char_count,char_count_exc,short_words,long_words,word_frequency)

if __name__ == "__main__":
    main()