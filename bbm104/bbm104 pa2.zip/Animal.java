import java.util.ArrayList;
import java.util.Objects;

public abstract class Animal {
    //Animal Variables
    private String name;
    private int age;
    private double mealSize;
    private static ArrayList<Animal> animalList = new ArrayList<>();

    //Animal Constructor
    Animal(String name, int age, double mealSize){
        this.name = name;
        this.age = age;
        this.mealSize = mealSize;
        //Add constructed animal to animalList
        animalList.add(this);
    }

    //Get-Set methods for animals
    public String getName(){
        return this.name;
    }
    public double getMealSize(){
        return this.mealSize;
    }

    /*
    A method that finds given animal using name
     */
    public static Animal findAnimal(String name) throws AnimalNotFound {
        //Search animalList for given name
        for(Animal ani : animalList){
            if (Objects.equals(ani.getName(), name)){
                return ani;
            }
        }
        //Throw AnimalNotFound exception if an animal with given name can't be found
        throw new AnimalNotFound("Error: There are no animals with the name "+ name +".\n");
    }

    //Eat and Clean Methods for Animals
    public abstract String eat(double[] foods,int mealNumber);
    public abstract String clean();
}
