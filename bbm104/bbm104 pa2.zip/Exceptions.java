//Java File for Custom Exceptions
public class Exceptions {
}
class VisitorFeedException extends Exception{
    VisitorFeedException(String message){
        super(message);
    }
}
class NotEnoughFood extends Exception{
    NotEnoughFood(String message){
        super(message);
    }
}
class AnimalNotFound extends Exception{
    AnimalNotFound(String message){
        super(message);
    }
}
class PeopleNotFound extends Exception{
    PeopleNotFound(String message){
        super(message);
    }
}
class InvalidCommand extends Exception{
    InvalidCommand(String message){
        super(message);
    }
}
