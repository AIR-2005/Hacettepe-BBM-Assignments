import java.util.Locale;

public class Elephant extends Animal{
    //Elephant Constructor
    Elephant(String name, int age){
        super(name, age, 10+(age-20)*0.015);
    }

    //Eat Method of Elephant
    @Override
    public String eat(double[] foods, int mealNumber){
        try {
            //Round totalMeal to have 3 decimal places
            double totalMeal = this.getMealSize() * mealNumber;
            if(totalMeal > foods[2]){
                //Throw NotEnoughFood for Plant if totalMeal is bigger than available Plant
                throw new NotEnoughFood("Error: Not enough Plant\n");
            }
            else {
                //Remove totalMeal amount from Plant
                foods[2] -= totalMeal;
            }
            return String.format(Locale.US,"%s has been given %.3f kgs assorted fruits and hay\n",this.getName(),totalMeal);
        }
        catch (NotEnoughFood e){
            //Return error message
            return e.getMessage();
        }
    }

    //Clean Method of Elephant
    @Override
    public String clean(){
        return "Cleaning " + this.getName() + "'s habitat: Washing the water area.\n";
    }
}
