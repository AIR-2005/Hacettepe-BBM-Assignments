import java.util.ArrayList;
import java.util.Objects;

public abstract class People {
    //People Variables
    private String name;
    private String id;
    private static ArrayList<People> peopleList = new ArrayList<>();

    //People Constructor
    People(String name, String id){
        this.name = name;
        this.id = id;
        //Add constructed person to peopleList
        peopleList.add(this);

    }
    //Get-Set methods for people
    public String getId(){
        return this.id;
    }
    public String getName() {
        return name;
    }

    /*
    Check if a person with given id exists in peopleList
    (To make sure each id is unique)
     */
    public static boolean isIdExists (String id){
        for(People people : peopleList){
            if (people.getId() == id){
                return true;
            }
        }
        return false;
    }

    /*
    A method that finds given person using id
     */
    public static People findPeople(String id) throws PeopleNotFound{
        //Search peopleList for given name
        for(People people : peopleList){
            if (Objects.equals(people.getId(), id)){
                return people;
            }
        }
        //Throw PeopleNotFound exception if a person with given id can't be found
        throw new PeopleNotFound("Error: There are no visitors or personnel with the id " + id + "\n");
    }

    //Feed and Visit Methods for People
    public abstract String feed(String animalName,double[] foods,int mealNumber);
    public abstract String visit(String animalName);
}
