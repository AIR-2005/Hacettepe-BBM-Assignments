import java.util.Locale;

public class Chimpanzee extends Animal{
    //Penguin Constructor
    Chimpanzee(String name, int age){
        super(name,age,3+(age-10)*0.0125);
    }

    //Eat Method of Chimpanzee
    @Override
    public String eat(double[] foods, int mealNumber){
        try {
            //Round totalMeal to have 3 decimal places
            double totalMeal = this.getMealSize() * mealNumber;
            if(totalMeal > foods[0]){
                //Throw NotEnoughFood for Meat if totalMeal is bigger than available Meat
                throw new NotEnoughFood("Error: Not enough Meat\n");
            }
            else if(totalMeal > foods[2]){
                //Throw NotEnoughFood for Plant if totalMeal is bigger than available Plant
                throw new NotEnoughFood("Error: Not enough Plant\n");
            }
            else {
                //Remove totalMeal amount from Meat and Plant
                foods[0] -= totalMeal;
                foods[2] -= totalMeal;
            }
            return String.format(Locale.US,"%s has been given %.3f kgs of meat and %.3f kgs of leaves\n",this.getName(),totalMeal,totalMeal);
        }
        catch (NotEnoughFood e){
            //Return error message
            return e.getMessage();
        }
    }

    //Clean Method of Chimpanzee
    @Override
    public String clean(){
        return "Cleaning " + this.getName() + "'s habitat: Sweeping the enclosure and replacing branches.\n";
    }
}
