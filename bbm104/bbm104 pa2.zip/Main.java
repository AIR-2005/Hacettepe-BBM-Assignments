import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;

public class Main{
    /*
     A method that reads Animal.txt
     */
    public static void readAnimals(String inputFile, String outputFile){
        try(BufferedReader reader = new BufferedReader(new FileReader(inputFile)); FileWriter writer = new FileWriter(outputFile)){
            String line;
            writer.write("***********************************\n");
            writer.write("***Initializing Animal information***\n");
            while ((line = reader.readLine()) != null){
                String[] parts = line.split(",");
                //Create new Animal objects according to animal.txt
                switch (parts[0]){
                    case "Lion":
                        writer.write("Added new Lion with name "+ parts[1] + " aged " + parts[2] + ".\n");
                        new Lion(parts[1],Integer.parseInt(parts[2]));
                        break;
                    case "Elephant":
                        writer.write("Added new Elephant with name "+ parts[1] + " aged " + parts[2] + ".\n");
                        new Elephant(parts[1],Integer.parseInt(parts[2]));
                        break;
                    case "Penguin":
                        writer.write("Added new Penguin with name "+ parts[1] + " aged " + parts[2] + ".\n");
                        new Penguin(parts[1],Integer.parseInt(parts[2]));
                        break;
                    case "Chimpanzee":
                        writer.write("Added new Chimpanzee with name "+ parts[1] + " aged " + parts[2] + ".\n");
                        new Chimpanzee(parts[1],Integer.parseInt(parts[2]));
                        break;
                }
            }
        }
        catch (IOException e) {
            System.out.println("Something went wrong with Files");;
        }
    }

    /*
     A method that reads people.txt
     */
    public static void readPeople(String inputFile, String outputFile){
        try(BufferedReader reader = new BufferedReader(new FileReader(inputFile)); FileWriter writer = new FileWriter(outputFile, true)){
            String line;
            writer.write("***********************************\n");
            writer.write("***Initializing Visitor and Personnel information***\n");
            while ((line = reader.readLine()) != null){
                String[] parts = line.split(",");
                //Create new People objects according to people.txt
                switch (parts[0]){
                    case "Personnel":
                        //If another person with same id doesn't exist, add this person to list
                        if(!People.isIdExists(parts[2])){
                            new Personnel(parts[1], parts[2]);
                            writer.write("Added new Personnel with id "+ parts[2] + " and name " + parts[1] + ".\n");
                        }
                        else {
                            writer.write("Person with id " + parts[2] + " already exists.\n");
                        }
                        break;
                    case "Visitor":
                        //If another person with same id doesn't exist, add this person to list
                        if(!People.isIdExists(parts[2])){
                            new Visitor(parts[1], parts[2]);
                            writer.write("Added new Visitor with id "+ parts[2] + " and name " + parts[1] + ".\n");
                        }
                        else {
                            writer.write("Person with id " + parts[2] + " already exists.\n");
                        }
                        break;
                }
            }
        }
        catch (IOException e) {
            System.out.println("Something went wrong with Files");;
        }
    }

    /*
     A method that reads foods.txt
     */
    public static double[] readFood(String inputFile,String outputFile){
        try(BufferedReader reader = new BufferedReader(new FileReader(inputFile)); FileWriter writer = new FileWriter(outputFile, true)){
            String line;
            double[] foodStock = new double[3];
            writer.write("***********************************\n");
            writer.write("***Initializing Food Stock***\n");
            while ((line = reader.readLine()) != null){
                String[] parts = line.split(",");
                //Create foods array for each type of food using foods.txt
                switch (parts[0]){
                    case "Meat":
                        foodStock[0] = Double.parseDouble(parts[1]);
                        writer.write(String.format(Locale.US,"There are %.3f kg of Meat in stock\n",foodStock[0]));
                        break;
                    case "Fish":
                        foodStock[1] = Double.parseDouble(parts[1]);
                        writer.write(String.format(Locale.US,"There are %.3f kg of Fish in stock\n",foodStock[1]));
                        break;
                    case "Plant":
                        foodStock[2] = Double.parseDouble(parts[1]);
                        writer.write(String.format(Locale.US,"There are %.3f kg of Plant in stock\n",foodStock[2]));
                        break;
                }
            }
            return foodStock;
        }
        catch (IOException e) {
            System.out.println("Something went wrong with Files");
            return null;
        }
    }

    /*
     A method that reads commands.txt
     */

    public static void readCommands(String inputFile,String outputFile,double[] foods){
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));FileWriter writer = new FileWriter(outputFile, true)){
            People person;
            String line;
                //Read each command from commands.txt and execute them
                while ((line = reader.readLine()) != null){
                    try{
                        String[] parts = line.split(",");
                        writer.write("***********************************\n");
                        writer.write("***Processing new Command***\n");
                        switch (parts[0]){
                            case "Feed Animal":
                                //Throw invalid command error if argument length is invalid
                                if (parts.length != 4){
                                    throw new InvalidCommand("Error:Invalid Command: " + line + "\n");
                                }
                                person = People.findPeople(parts[1]);
                                int mealNumber = Integer.parseInt(parts[3]);
                                writer.write(person.feed(parts[2],foods,mealNumber));
                                break;
                            case "Animal Visitation":
                                //Throw invalid command error if argument length is invalid
                                if (parts.length != 3){
                                    throw new InvalidCommand("Error:Invalid Command: " + line + "\n");
                                }
                                person = People.findPeople(parts[1]);
                                writer.write(person.visit(parts[2]));
                                break;
                            case "List Food Stock":
                                //Throw invalid command error if argument length is invalid
                                if (parts.length != 1){
                                    throw new InvalidCommand("Error:Invalid Command: " + line + "\n");
                                }
                                writer.write("Listing available Food Stock:\n");
                                writer.write(String.format(Locale.US,"Plant: %.3f kgs\n",foods[2]));
                                writer.write(String.format(Locale.US,"Fish: %.3f kgs\n",foods[1]));
                                writer.write(String.format(Locale.US,"Meat: %.3f kgs\n",foods[0]));
                                break;
                            //Throw invalid command error if operation type is invalid
                            default:
                                throw new InvalidCommand("Error:Invalid Command: " + line + "\n");
                        }
                    }
                    catch (PeopleNotFound e){
                        writer.write(e.getMessage());
                    }
                    //Error for parseInt in Feed Animal command
                    catch (NumberFormatException e){
                        writer.write("Error processing command: " + line + "\n");
                        writer.write("Error: " + e.getMessage() + "\n");
                    }
                    //Error for Invalid Commands
                    catch (InvalidCommand e) {
                        writer.write("Error processing command: " + line + "\n");
                        writer.write(e.getMessage());
                    }
                }
        }
        catch (IOException e) {
            System.out.println("Something went wrong with Files");;
        }
    }

    /*
    Main Function
     */
    public static void main(String[] args){
        readAnimals(args[0],args[4]);
        readPeople(args[1],args[4]);
        double[] foods = readFood(args[2], args[4]);
        readCommands(args[3], args[4], foods);
    }
}
