public class Visitor extends People{
    //Visitor Constructor
    Visitor(String name,String id){
        super(name,id);
    }

    //Feed Method of Visitor
    @Override
    public String feed(String animalName, double[] foods, int mealNumber){
        String output = this.getName() + " tried to feed " + animalName + "\n";
        try {
            //Throw VisitorFeedException since visitors can't feed animals
            throw new VisitorFeedException("Error: Visitors do not have the authority to feed animals.\n");
        }
        catch (VisitorFeedException e) {
            //Add error message to output
            output += e.getMessage();
        }
        return output;
    }

    //Visit Method of Visitor
    @Override
    public String visit(String animalName){
        String output = this.getName() + " tried to register for a visit to " + animalName + ".\n";
        try{
            //Search given animal
            Animal ani = Animal.findAnimal(animalName);
            output += this.getName() + " successfully visited " + ani.getName() +".\n";
        }
        catch (AnimalNotFound e) {
            //Add error message to output if AnimalNotFound
            output += e.getMessage();
        }
        return output;

    }
}
