import java.util.Locale;

public class Penguin extends Animal{
    //Penguin Constructor
    Penguin(String name, int age){
        super(name,age, 3+(age-4)*0.04);
    }

    //Eat Method of Penguin
    @Override
    public String eat(double[] foods, int mealNumber){
        try {
            //Round totalMeal to have 3 decimal places
            double totalMeal = this.getMealSize() * mealNumber;
            if(totalMeal > foods[1]){
                //Throw NotEnoughFood if totalMeal is bigger than available meal
                throw new NotEnoughFood("Error: Not enough Fish\n");
            }
            else {
                //Remove totalMeal amount from Meat
                foods[1] -= totalMeal;
            }
            return String.format(Locale.US,"%s has been given %.3f kgs of various kinds of fish\n",this.getName(),totalMeal);
        }
        catch (NotEnoughFood e){
            //Return error message
            return e.getMessage();
        }
    }

    //Clean Method of Penguin
    @Override
    public String clean(){
        return "Cleaning " + this.getName() + "'s habitat: Replenishing ice and scrubbing walls.\n";
    }
}
