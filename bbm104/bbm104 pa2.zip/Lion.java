import java.util.Locale;

public class Lion extends Animal{
    //Lion Constructor
    Lion(String name, int age){
        super(name,age,5+(age-5)*0.05);
    }

    //Eat Method of Lion
    @Override
    public String eat(double[] foods, int mealNumber){
        try {
            //Round totalMeal to have 3 decimal places
            double totalMeal = this.getMealSize() * mealNumber;
            if(totalMeal > foods[0]){
                //Throw NotEnoughFood for Meat if totalMeal is bigger than available Meat
                throw new NotEnoughFood("Error: Not enough Meat\n");
            }
            else {
                //Remove totalMeal amount from Meat
                foods[0] -= totalMeal;
            }
            return String.format(Locale.US,"%s has been given %.3f kgs of meat\n",this.getName(),totalMeal);
        }
        catch (NotEnoughFood e){
            //Return error message
            return e.getMessage();
        }
    }

    //Clean Method of Lion
    @Override
    public String clean(){
        return "Cleaning " + this.getName() + "'s habitat: Removing bones and refreshing sand.\n";
    }
}
