public class Personnel extends People{
    //Personnel Constructor
    Personnel(String name,String id){
        super(name,id);
    }

    //Feed Method of Personnel
    @Override
    public String feed(String animalName, double[] foods, int mealNumber){
        String output = this.getName() + " attempts to feed " + animalName + ".\n";
        try {
            //Search given animal and call its eat method
            Animal ani = Animal.findAnimal(animalName);
            output +=  ani.eat(foods,mealNumber);
        }
        catch (AnimalNotFound e){
            //Add error message to output if AnimalNotFound
            output += e.getMessage();
        }
        return output;
    }

    //Visit Method of Personnel
    @Override
    public String visit(String animalName){
        String output = this.getName() + " attempts to clean " + animalName + "'s habitat.\n";
        try {
            //Search given animal and call its clean method
            Animal ani = Animal.findAnimal(animalName);
            output += this.getName() + " started cleaning " + ani.getName()  + "'s habitat.\n" + ani.clean();
        }
        catch (AnimalNotFound e){
            //Add error message to output if AnimalNotFound
            output += e.getMessage();
        }
        return output;
    }
}
