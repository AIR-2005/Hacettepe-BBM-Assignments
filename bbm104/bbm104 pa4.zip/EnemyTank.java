import com.sun.javafx.scene.traversal.Direction;
import javafx.scene.Group;
import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.Random;

public class EnemyTank extends Tank{
    //EnemyTank Variables
    private final static Image[] IMG_ARRAY = {new Image("file:assets/whiteTank1.png"), new Image("file:assets/whiteTank2.png")};
    private final static double MOVEMENT_SPEED = 1.5;

    //Variables for EnemyTank movement
    private static final Random RANDOM = new Random();
    private Direction currentDirection = Direction.DOWN;
    private long directionChangeInterval = (1000000000 + RANDOM.nextInt(4) * 1000000000L);//1-4 seconds
    private long lastDirectionChangeTime = 0;

    //Variables for EnemyTank shooting
    long lastEnemyShotTime = 0;
    long enemyShootCooldown = (1000000000 + RANDOM.nextInt(4) * 1000000000L); //1-4 seconds

    //EnemyTank Constructor
    EnemyTank(double x_cord, double y_cord){
        super(x_cord, y_cord, IMG_ARRAY, MOVEMENT_SPEED);
    }

    /*
    Shoot Method for PlayerTank
     */
    public void shoot(long currentTime, Group gameRoot ,ArrayList<EnemyBullet> enemyBulletsList){
        if (currentTime - lastEnemyShotTime >= enemyShootCooldown) {
            EnemyBullet eBullet = new EnemyBullet(getTranslateX() + getWidth()/2 - 5, getTranslateY() + getHeight()/2 - 5, this.getRotate());
            gameRoot.getChildren().add(eBullet);
            enemyBulletsList.add(eBullet);
            lastEnemyShotTime = currentTime;
            enemyShootCooldown = (1000000000 + RANDOM.nextInt(4) * 1000000000L);
        }
    }

    /*
    A method that sets a direction for EnemyTank in random intervals
     */
    public void setDirection(long currentTime) {
        //If current time minus last time Direction was changed is greater than change interval, change direction
        if (currentTime - lastDirectionChangeTime >= directionChangeInterval){
            //Get a random integer less than 4 and change direction according to integer
            switch (new Random().nextInt(4)) {
                case 0:
                    currentDirection = Direction.UP;
                    break;
                case 1:
                    currentDirection = Direction.DOWN;
                    break;
                case 2:
                    currentDirection = Direction.LEFT;
                    break;
                case 3:
                    currentDirection = Direction.RIGHT;
                    break;
            }
            //Set last Direction change time to current time
            lastDirectionChangeTime = currentTime;
            //Randomly choose a new change interval
            directionChangeInterval = (1000000000 + RANDOM.nextInt(4) * 1000000000L);
        }
    }

    /*
    A method that moves in current direction of EnemyTank
     */
    public void enemyMove(ArrayList<Wall> walls) {
        //Move according to current direction
        switch (currentDirection) {
            case UP:
                moveUp(walls);
                break;
            case DOWN:
                moveDown(walls);
                break;
            case LEFT:
                moveLeft(walls);
                break;
            case RIGHT:
                moveRight(walls);
                break;
        }
    }
}


