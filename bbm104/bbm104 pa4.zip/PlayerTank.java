import javafx.scene.Group;
import javafx.scene.image.Image;

import java.util.ArrayList;

public class PlayerTank extends Tank{
    //PlayerTank Variables
    private final static Image[] IMG_ARRAY = {new Image("file:assets/yellowTank1.png"), new Image("file:assets/yellowTank2.png")};
    private final static double MOVEMENT_SPEED = 2;

    //Variables for PlayerTank shooting
    private long lastPlayerShotTime = 0;
    private long playerShootCooldown = 300000000; //0.3 seconds

    //PlayerTank Constructor
    PlayerTank(double x_cord, double y_cord){
        super(x_cord, y_cord, IMG_ARRAY, MOVEMENT_SPEED);
    }

    /*
    Shoot Method for PlayerTank
     */
    public void shoot(long currentTime, Group gameRoot, ArrayList<PlayerBullet> playerBulletsList){
        if (currentTime - lastPlayerShotTime >= playerShootCooldown){
            PlayerBullet pBullet = new PlayerBullet(getTranslateX() + getWidth()/2 - 5, getTranslateY() + getHeight()/2 - 5, this.getRotate());
            gameRoot.getChildren().add(pBullet);
            playerBulletsList.add(pBullet);
            lastPlayerShotTime = currentTime;
        }
    }
}
