import javafx.scene.image.Image;

public class Wall extends GameObject{
    //Wall Variables
    private final static double WALL_WIDTH = 25;
    private final static double WALL_HEIGHT = 25;
    private final static Image WALL_IMG = new Image("file:assets/wall.png");

    //Wall Constructor
    Wall(int x_cord, int y_cord){
        super(WALL_WIDTH, WALL_HEIGHT, x_cord, y_cord, WALL_IMG);
    }
}
