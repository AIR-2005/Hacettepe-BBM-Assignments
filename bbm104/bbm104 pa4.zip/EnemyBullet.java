public class EnemyBullet extends Bullet{
    //EnemyBullet Constructor
    EnemyBullet(double x_cord, double y_cord, double rotationAngle){
        super(x_cord, y_cord, rotationAngle);
    }
}
