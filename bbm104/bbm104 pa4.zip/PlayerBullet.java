public class PlayerBullet extends Bullet{
    //PlayerBullet Constructor
    PlayerBullet(double x_cord, double y_cord, double rotationAngle){
        super(x_cord, y_cord, rotationAngle);
    }
}
