import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Bounds;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class Main extends Application {
    //Initialize Variables
    private final Random rand = new Random();
    private final Image icon = new Image("file:assets/explosion.png"); //Game Icon
    private int score;
    private int lives;
    private KeyCode movementKey;
    private KeyCode specialKey;
    private Group gameRoot;
    private Group cameraRoot;
    private PlayerTank player;
    private VBox scoreRoot;
    private Text scoreText;
    private Text livesText;
    private Pane totalRoot;
    private VBox pauseRoot;
    private Text pauseText;
    private Text pauseInfoText;
    private VBox overRoot;
    private Text overScoreText;
    private Text overInfoText;
    private AnimationTimer playerTimer;
    private AnimationTimer gameTimer;
    private Scene gameScene;
    private Scene pauseScene;
    private Scene gameOverScene;

    //Variables for enemy spawn
    private long enemySpawnInterval = (1000000000 + rand.nextInt(4) * 1000000000L);//1-4 seconds
    private long lastEnemySpawnTime = 0;

    //Variables for player respawn
    private long lastPlayerLostTime = 0;
    private boolean isPlayerShot = false;
    private final long playerSpawnInterval = 500000000;//0.5 seconds

    //Variables of GameObjects lists
    private ArrayList<EnemyTank> enemyTanksList;
    private ArrayList<PlayerBullet> playerBulletsList;
    private ArrayList<EnemyBullet> enemyBulletsList;
    private ArrayList<Explosion> explosionsList;
    private ArrayList<Wall> wallList;

    //Create bound objects for game object bounds
    private Bounds eBulletBound;
    private Bounds pBulletBound;
    private Bounds wallBound;

    /*
    A method that creates game scene
     */
    public void createGameScene(){
        //Game Scene
        score = 0;
        lives = 3;
        movementKey = null;
        specialKey = null;

        //Game Root
        gameRoot  = new Group();

        //Create camera root to allow scrolling
        cameraRoot = new Group(gameRoot);

        //Create the player and add it to game root
        player = new PlayerTank(1000, 1900);
        gameRoot.getChildren().add(player);

        //Create arrayLists for game objects to keep track of them
        enemyTanksList = new ArrayList<>();
        playerBulletsList = new ArrayList<>();
        enemyBulletsList = new ArrayList<>();
        explosionsList = new ArrayList<>();
        wallList= new ArrayList<>();

        //Score Root
        scoreRoot = new VBox();
        scoreText = new Text("Score: " + score);
        livesText = new Text("Lives: " + lives);
        scoreText.setFill(Color.DARKBLUE);
        livesText.setFill(Color.RED);
        scoreText.setFont(new Font(30));
        livesText.setFont(new Font(30));
        scoreRoot.setAlignment(Pos.TOP_LEFT);
        scoreRoot.getChildren().addAll(scoreText, livesText);

        //Combine the roots to a totalRoot
        totalRoot = new Pane(cameraRoot, scoreRoot);
        //Create Game Scene
        gameScene = new Scene(totalRoot, 900,900, Color.BLACK);
    }

    /*
    A method that generates walls
     */
    public void generateWalls(){
        //Generate Walls
        for (int i = 0; i <= 1975; i+= 25){
            Wall w1 = new Wall(i, 0);
            Wall w2 = new Wall(0, i);
            Wall w3 = new Wall(1975, i);
            Wall w4 = new Wall(i, 1975);

            gameRoot.getChildren().addAll(w1, w2, w3, w4);
            wallList.add(w1);
            wallList.add(w2);
            wallList.add(w3);
            wallList.add(w4);
        }
        for (int i = 500; i <= 1500; i+= 25){
            Wall w1 = new Wall(i, 1000);
            Wall w2 = new Wall(i, 1125);
            Wall w3 = new Wall(i, 1250);

            gameRoot.getChildren().addAll(w1, w2, w3);
            wallList.add(w1);
            wallList.add(w2);
            wallList.add(w3);
        }
        for (int i = 125; i <= 600; i+= 25){
            for (int j = 125; j <= 200; j += 25) {
                Wall w1 = new Wall(j, i);
                Wall w2 = new Wall(1975 - j, i);
                Wall w3 = new Wall(j, 1975 - i);
                Wall w4 = new Wall(1975 - j, 1975 - i);

                gameRoot.getChildren().addAll(w1, w2, w3, w4);
                wallList.add(w1);
                wallList.add(w2);
                wallList.add(w3);
                wallList.add(w4);
            }
        }
        for (int i = 125; i <= 475; i+= 25){
            for (int j = 300; j <= 350; j+=25){
                Wall w1 = new Wall(j, i);
                Wall w2 = new Wall(1975 - j, i);
                Wall w3 = new Wall(j, 1975 - i);
                Wall w4 = new Wall(1975 - j, 1975 - i);

                gameRoot.getChildren().addAll(w1, w2, w3, w4);
                wallList.add(w1);
                wallList.add(w2);
                wallList.add(w3);
                wallList.add(w4);
            }
        }
    }

    /*
    A method that creates pause scene
     */
    public void createPauseScene(){
        //Pause Scene
        pauseRoot = new VBox();
        pauseText = new Text("PAUSED!");
        pauseInfoText = new Text("Press P to continue.\nPress R to restart the game.\nPress ESC to close the game.");
        pauseText.setFill(Color.BLACK);
        pauseInfoText.setFill(Color.BLACK);
        pauseText.setFont(new Font(50));
        pauseInfoText.setFont(new Font(20));
        pauseRoot.getChildren().addAll(pauseText, pauseInfoText);
        pauseRoot.setAlignment(Pos.CENTER);
        pauseScene = new Scene(pauseRoot,900,900, Color.CYAN);
    }

    /*
    A method that creates game over scene
    */
    public void createOverScene(){
        //Game Over Scene
        overRoot = new VBox();
        overScoreText = new Text();
        overInfoText = new Text("Press R to restart the game.\nPress ESC to close the game.");
        overScoreText.setFill(Color.BLACK);
        overInfoText.setFill(Color.BLACK);
        overScoreText.setFont(new Font(50));
        overInfoText.setFont(new Font(20));
        overRoot.getChildren().addAll(overScoreText, overInfoText);
        overRoot.setAlignment(Pos.CENTER);
        gameOverScene = new Scene(overRoot,900,900, Color.DARKORANGE);
    }

    /*
    Pause game and game over methods
     */
    public void pauseGame(Stage stage){
        playerTimer.stop();
        gameTimer.stop();
        stage.setScene(pauseScene);
    }

    public void gameOver(Stage stage){
        playerTimer.stop();
        gameTimer.stop();
        overScoreText.setText("GAME OVER!\nScore: " + score);
        stage.setScene(gameOverScene);
    }

    /*
    A method that creates gameTimer and playerTimer animations
     */
    public void createTimers(Stage stage){
        //Create arrayLists to track game objects that are going to be removed
        ArrayList<Explosion> removedExplosions = new ArrayList<>();
        ArrayList<PlayerBullet> removedPlayerBullets = new ArrayList<>();
        ArrayList<EnemyBullet> removedEnemyBullets = new ArrayList<>();
        ArrayList<EnemyTank> removedEnemyTanks = new ArrayList<>();

        //Get explosion image change interval
        long explosionImgChangeInterval = Explosion.getImgChangeInterval();

        //AnimationTimer for game Scene
        gameTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                //If lives are 0 or lower, end the game
                if (lives <= 0){
                    gameOver(stage);
                }
                else {
                    //Respawn and Send player back to starting point if enough time has passed
                    if (isPlayerShot && now - lastPlayerLostTime >= playerSpawnInterval){
                        gameRoot.getChildren().add(player);
                        isPlayerShot = false;
                        player.setTranslateX(1000);
                        player.setTranslateY(1900);

                    }
                    //Create array lists for game objects to be removed to prevent errors in loops
                    removedExplosions.clear();
                    removedPlayerBullets.clear();
                    removedEnemyBullets.clear();
                    removedEnemyTanks.clear();

                    //Check every explosion, add them to remove list and explosion list if they are over
                    for (Explosion explosion : explosionsList){
                        //If all the image array has been used and enough time passed, end explosion
                        if (explosion.getCurrentImg() >= 2 && now - explosion.getLastImageChangeTime() >= explosionImgChangeInterval){
                            removedExplosions.add(explosion);
                        }
                        //Else just enough time has passed, continue with next image
                        else if (now - explosion.getLastImageChangeTime() >= explosionImgChangeInterval){
                            explosion.setNextImage(now);
                        }
                    }

                    //Check every player bullet
                    for (PlayerBullet pBullet : playerBulletsList){
                        //Check if player bullet is removed
                        if (!removedPlayerBullets.contains(pBullet)){
                            //Move player bullet
                            pBullet.moveBullet();
                            //Check every enemy tank for collision with player bullet
                            pBulletBound = pBullet.getBoundsInParent();
                            for (EnemyTank eTank : enemyTanksList){
                                //If player bullet collides with enemy tank
                                if (pBulletBound.intersects(eTank.getBoundsInParent())){
                                    //Add enemy bullet to remove list, create an explosion and increment score by 1
                                    removedPlayerBullets.add(pBullet);
                                    removedEnemyTanks.add(eTank);
                                    Explosion explosion = new Explosion(eTank.getTranslateX() + eTank.getWidth()/2, eTank.getTranslateY() + eTank.getHeight()/2);
                                    gameRoot.getChildren().add(explosion);
                                    explosionsList.add(explosion);
                                    score++;
                                }
                            }
                            //Check every wall for collision with player bullet
                            for (Wall wall : wallList){
                                //If player bullet collides with wall
                                wallBound = wall.getBoundsInParent();
                                if (wallBound.intersects(pBulletBound)){
                                    //Add enemy bullet to remove list and create an explosion
                                    removedPlayerBullets.add(pBullet);
                                    Explosion explosion = new Explosion(pBullet.getTranslateX() + pBullet.getWidth()/2, pBullet.getTranslateY() + pBullet.getHeight()/2);
                                    gameRoot.getChildren().add(explosion);
                                    explosionsList.add(explosion);
                                }
                            }
                        }

                    }
                    //Check every enemy bullet
                    for (EnemyBullet eBullet : enemyBulletsList){
                        //Check if enemy bullet is removed
                        if (!removedEnemyBullets.contains(eBullet)){
                            //Move enemy bullet
                            eBullet.moveBullet();
                            //If enemy bullet collides with player
                            eBulletBound = eBullet.getBoundsInParent();
                            if (eBulletBound.intersects(player.getBoundsInParent()) && !isPlayerShot) {
                                //Wait player to respawn for 0.5 seconds and decrement lives by 1
                                gameRoot.getChildren().remove(player);
                                isPlayerShot = true;
                                lastPlayerLostTime = now;
                                lives--;
                                //Add enemy bullet to remove list and create an explosion
                                removedEnemyBullets.add(eBullet);
                                Explosion explosion = new Explosion(player.getTranslateX() + player.getWidth() / 2, player.getTranslateY() + player.getHeight() / 2);
                                gameRoot.getChildren().add(explosion);
                                explosionsList.add(explosion);
                            }
                            //Check every wall
                            for (Wall wall : wallList){
                                //If enemy bullet collides with wall
                                if (wall.getBoundsInParent().intersects(eBulletBound)){
                                    //Add enemy bullet to remove list and create an explosion
                                    removedEnemyBullets.add(eBullet);
                                    Explosion explosion = new Explosion(eBullet.getTranslateX() + eBullet.getWidth()/2, eBullet.getTranslateY() + eBullet.getHeight()/2);
                                    gameRoot.getChildren().add(explosion);
                                    explosionsList.add(explosion);
                                }
                            }
                        }

                    }
                    //Check every enemy tank
                    for (EnemyTank eTank : enemyTanksList){
                        //Check if enemy tank is removed
                        if (!removedEnemyTanks.contains(eTank)){
                            //EnemyTank shoots, sets a new direction and moves
                            eTank.shoot(now, gameRoot, enemyBulletsList);
                            eTank.setDirection(now);
                            eTank.enemyMove(wallList);
                            //If enemy tank collides with player
                            if (eTank.getBoundsInParent().intersects(player.getBoundsInParent()) && !isPlayerShot){
                                //Wait player to respawn for 0.5 seconds and decrement lives by 1
                                gameRoot.getChildren().remove(player);
                                isPlayerShot = true;
                                lastPlayerLostTime = now;
                                lives--;
                                //Add enemy tank to remove list and create an explosion
                                removedEnemyTanks.add(eTank);
                                Explosion explosion = new Explosion(player.getTranslateX() + player.getWidth() / 2, player.getTranslateY() + player.getHeight() / 2);
                                gameRoot.getChildren().add(explosion);
                                explosionsList.add(explosion);
                            }
                        }
                    }

                    //Generate random enemy tank if enough time passed and there are less than 15 tanks
                    if (now - lastEnemySpawnTime >= enemySpawnInterval  && enemyTanksList.size() <= 15){
                        //Check if x and y points far away from player to prevent collision
                        int spawnX = rand.nextInt(1900) + 30;
                        int spawnY = rand.nextInt(50) + 30;
                        if (Math.abs(spawnX - player.getTranslateX()) > 75 && Math.abs(spawnY - player.getTranslateY()) > 75){
                            //Add new enemyTank in a random location in upper parts
                            EnemyTank eTank = new EnemyTank(spawnX, spawnY);
                            gameRoot.getChildren().add(eTank);
                            enemyTanksList.add(eTank);
                            //Set last enemy spawn time to now
                            lastEnemySpawnTime = now;
                            //Randomly choose a new enemy spawn interval
                            enemySpawnInterval = (1000000000 + rand.nextInt(4) * 1000000000L);//1-4 seconds
                        }
                    }

                    //Remove removed game objects from their lists and game root
                    explosionsList.removeAll(removedExplosions);
                    enemyTanksList.removeAll(removedEnemyTanks);
                    enemyBulletsList.removeAll(removedEnemyBullets);
                    playerBulletsList.removeAll(removedPlayerBullets);
                    gameRoot.getChildren().removeAll(removedExplosions);
                    gameRoot.getChildren().removeAll(removedEnemyTanks);
                    gameRoot.getChildren().removeAll(removedEnemyBullets);
                    gameRoot.getChildren().removeAll(removedPlayerBullets);

                    //Set X and Y offset for Camera
                    double XOffSet = player.getTranslateX() - (gameScene.getWidth() / 2) + (player.getWidth() / 2);
                    double YOffSet = player.getTranslateY() - (gameScene.getHeight() / 2) + (player.getHeight() / 2);

                    //Prevent Camera from showing outside the walls
                    XOffSet = Math.max(0, Math.min(XOffSet, 2000 - gameScene.getWidth()));
                    YOffSet = Math.max(0, Math.min(YOffSet, 2000 - gameScene.getHeight()));

                    //Make Camera follow player
                    cameraRoot.setTranslateX(-XOffSet);
                    cameraRoot.setTranslateY(-YOffSet);

                    //Update score and live texts
                    scoreText.setText("Score: " + score);
                    livesText.setText("Lives: " + lives);
                }
            }
        };

        //PlayerTimer for player movement and shooting
        playerTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (movementKey != null && !isPlayerShot){
                    switch (movementKey) {
                        //RIGHT Key(Move player to right)
                        case RIGHT:
                            player.moveRight(wallList);
                            break;
                        //LEFT Key(Move player to left)
                        case LEFT:
                            player.moveLeft(wallList);
                            break;
                        //UP Key(Move player to up)
                        case UP:
                            player.moveUp(wallList);
                            break;
                        //DOWN Key(Move player to down)
                        case DOWN:
                            player.moveDown(wallList);
                            break;
                    }
                }
                if (specialKey != null && !isPlayerShot){
                    //X Key(Player shoots bullet)
                    switch (specialKey){
                        case X:
                            player.shoot(System.nanoTime(), gameRoot, playerBulletsList);
                            break;
                        //P Key(Pause the game)
                        case P:
                            pauseGame(stage);
                            break;
                    }
                }
            }
        };
    }

    /*
    A method that reset game for restart
     */
    private void resetGame(Stage stage) {
        //Stop timers
        playerTimer.stop();
        gameTimer.stop();

        //Clear all lists
        enemyTanksList.clear();
        playerBulletsList.clear();
        enemyBulletsList.clear();
        explosionsList.clear();
        wallList.clear();

        //Clear game root
        gameRoot.getChildren().clear();

        //Reset key, score, lives and isPlayerShot
        movementKey = null;
        specialKey = null;
        score = 0;
        lives = 3;
        isPlayerShot = false;

        //Reset player position
        player.setTranslateX(1000);
        player.setTranslateY(1900);

        //Add player back to game root
        gameRoot.getChildren().add(player);

        //Generate walls
        generateWalls();

        //Reset score and lives texts
        scoreText.setText("Score: " + score);
        livesText.setText("Lives: " + lives);

        //Start Timers
        gameTimer.start();
        playerTimer.start();

        //Set game scene
        stage.setScene(gameScene);
    }

    /*
    Start Function
     */
    @Override
    public void start(Stage stage) {
        //An array for checking for player shooting or pausing
        HashSet<KeyCode> movementKeySet = new HashSet<>();
        movementKeySet.add(KeyCode.UP);
        movementKeySet.add(KeyCode.DOWN);
        movementKeySet.add(KeyCode.RIGHT);
        movementKeySet.add(KeyCode.LEFT);
        //Set game title and icon
        stage.setTitle("Tank Game");
        stage.getIcons().add(icon);
        createGameScene();
        createPauseScene();
        createOverScene();
        createTimers(stage);
        generateWalls();
        stage.setScene(gameScene);
        playerTimer.start();
        gameTimer.start();

        //Game Scene Key Detection
        //Set Key to pressed key if it isn't set
        gameScene.setOnKeyPressed(event -> {
            KeyCode currentKey = event.getCode();
            if (movementKeySet.contains(currentKey)){
                movementKey = currentKey;
            }
            else {
                specialKey = currentKey;
            }
        });

        //Set Key to null when key is released
        gameScene.setOnKeyReleased(event -> {
            KeyCode currentKey = event.getCode();
            if (currentKey == movementKey){
                movementKey = null;
            }
            if (currentKey == specialKey){
                specialKey = null;
            }
        });

        //Pause Scene Key Detection
        pauseScene.setOnKeyPressed(event -> {
            switch (event.getCode()){
                //P Key(Continue the game)
                case P:
                    //Reset the key
                    movementKey = null;
                    specialKey = null;
                    gameTimer.start();
                    playerTimer.start();
                    stage.setScene(gameScene);
                    break;
                //ESC Key(Close the game)
                case ESCAPE:
                    stage.close();
                    break;
                //R Key(Restart the game)
                case R:
                    //Reset the key
                    resetGame(stage);
                    break;
            }
        });

        //Game Over Scene Key Detection
        gameOverScene.setOnKeyPressed(event -> {
            switch (event.getCode()){
                //ESC Key(Close the game)
                case ESCAPE:
                    stage.close();
                    break;
                //R Key(Restart the game)
                case R:
                    resetGame(stage);
                    break;
            }
        });

        //Show the game
        stage.show();
    }

    /*
    Main function
    */
    public static void main(String[] args) {
        launch(args);
    }
}

