import javafx.scene.image.Image;

public abstract class Bullet extends GameObject{
    //Bullet Variables
    private final static double BULLET_WIDTH = 10;
    private final static double BULLET_HEIGHT = 10;
    private final static double BULLET_SPEED = 5;
    private final static Image BULLET_IMG = new Image("file:assets/bullet.png");

    //Bullet Constructor
    Bullet(double x_cord, double y_cord, double rotationAngle) {
        super(BULLET_WIDTH,BULLET_HEIGHT,x_cord, y_cord, BULLET_IMG);
        this.setRotate(rotationAngle);
    }

    /*
    A method for bullet movement
     */
    public void moveBullet(){
        //Move according to rotation of bullet
        switch ((int) this.getRotate()){
            case 0:
                moveRight();
                break;
            case 90:
                moveDown();
                break;
            case 180:
                moveLeft();
                break;
            case 270:
                moveUp();
                break;
        }
    }

    /*
    Move methods for bullet
     */
    public void moveRight() {
        this.setTranslateX(this.getTranslateX() + BULLET_SPEED);
    }
    public void moveLeft() {
        this.setTranslateX(this.getTranslateX() - BULLET_SPEED);
    }
    public void moveDown(){
        this.setTranslateY(this.getTranslateY() + BULLET_SPEED);
    }
    public void moveUp(){
        this.setTranslateY(this.getTranslateY() - BULLET_SPEED);
    }
}
