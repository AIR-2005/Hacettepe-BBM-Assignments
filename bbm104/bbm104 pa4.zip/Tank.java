import javafx.scene.image.Image;
import java.util.ArrayList;

public abstract class Tank extends GameObject{
    //Tank Variables
    private final double movementSpeed;
    private final static double TANK_WIDTH = 50;
    private final static double TANK_HEIGHT = 50;

    //Variables for Tank Animation
    private final Image[] imgArray;
    private int currentImg = 0;
    private final long imageChangeInterval = 50000000;//0.05 second
    private long lastImageChangeTime = 0;

    //Tank Constructor
    public Tank(double x_cord, double y_cord, Image[] imgArray, double movementSpeed){
        super(TANK_WIDTH,TANK_HEIGHT,x_cord,y_cord,imgArray[0]);
        this.movementSpeed = movementSpeed;
        this.imgArray = imgArray;
    }

    public void tankAnimate(){
        //Get current time
        long currentTime = System.nanoTime();
        //If current time minus last time Image was changed is greater than change interval, change image
        if (currentTime - lastImageChangeTime >= imageChangeInterval){
            setImg(imgArray[currentImg]);
            currentImg = (currentImg + 1) % 2;
            lastImageChangeTime = currentTime;
        }
    }

    /*
    A method for checking if tank is intersecting a wall
     */
    public boolean isIntersectWall(ArrayList<Wall> wallList) {
        for (Wall wall : wallList) {
            if (wall.getBoundsInParent().intersects(this.getBoundsInParent())) {
                return true;
            }
        }
        return false;
    }

    /*
    Move methods for Tank
     */
    public void moveRight(ArrayList<Wall> wallList) {
        //Call animation method
        tankAnimate();
        //Rotate tank in movement direction
        this.setRotate(0);
        //Move tank
        this.setTranslateX(this.getTranslateX() + movementSpeed);
        //If tank intersects a wall, undo movement
        if (isIntersectWall(wallList)){
            this.setTranslateX(this.getTranslateX() - movementSpeed);
        }
    }
    public void moveLeft(ArrayList<Wall> wallList) {
        //Call animation method
        tankAnimate();
        //Rotate tank in movement direction
        this.setRotate(180);
        //Move tank
        this.setTranslateX(this.getTranslateX() - movementSpeed);
        //If tank intersects a wall, undo movement
        if (isIntersectWall(wallList)){
            this.setTranslateX(this.getTranslateX() + movementSpeed);
        }
    }
    public void moveDown(ArrayList<Wall> wallList){
        //Call animation method
        tankAnimate();
        //Rotate tank in movement direction
        this.setRotate(90);
        //Move tank
        this.setTranslateY(this.getTranslateY() + movementSpeed);
        //If tank intersects a wall, undo movement
        if (isIntersectWall(wallList)){
            this.setTranslateY(this.getTranslateY() - movementSpeed);
        }
    }
    public void moveUp(ArrayList<Wall> wallList){
        //Call animation method
        tankAnimate();
        //Rotate tank in movement direction
        this.setRotate(270);
        //Move tank
        this.setTranslateY(this.getTranslateY() - movementSpeed);
        //If tank intersects a wall, undo movement
        if (isIntersectWall(wallList)){
            this.setTranslateY(this.getTranslateY() + movementSpeed);
        }
    }
}
