import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public abstract class GameObject extends Rectangle {
    //GameObject Constructor
    GameObject(double width, double height, double x_cord, double y_cord, Image img){
        super(width,height);
        setImg(img);
        this.setTranslateX(x_cord);
        this.setTranslateY(y_cord);
    }

    //Get-Set Methods
    public void setImg(Image img){
        this.setFill(new ImagePattern(img));
    }
}
