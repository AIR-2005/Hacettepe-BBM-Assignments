import javafx.scene.image.Image;

public class Explosion extends GameObject{
    //Explosion Variables
    private static final Image[] IMG_ARRAY = {new Image("file:assets/smallExplosion.png"), new Image("file:assets/explosion.png")};

    //Animation variables
    private long lastImageChangeTime = 0;
    private int currentImg = 0;
    private static final long imgChangeInterval = 100000000;//0,1 second
    private final double x_cord;
    private final double y_cord;

    //Explosion Constructor
    Explosion(double x_cord, double y_cord){
        super(0,0, x_cord, y_cord, IMG_ARRAY[0]);
        this.x_cord = x_cord;
        this.y_cord = y_cord;
    }

    //Get-Set Methods
    public long getLastImageChangeTime(){
        return lastImageChangeTime;
    }

    public int getCurrentImg() {
        return currentImg;
    }

    public static long getImgChangeInterval(){
        return imgChangeInterval;
    }

    public void setNextImage(long currentTime){
        //Set image to next Image
        setImg(IMG_ARRAY[currentImg]);
        //Set width, height, x coordinate, y coordinate according to image number
        double size = (currentImg + 1) * 25;
        setWidth(size);
        setHeight(size);
        setTranslateX(x_cord - ((size) / 2));
        setTranslateY(y_cord - ((size) / 2));
        //Increment image number by 1
        currentImg++;
        //Set last image change time to now
        lastImageChangeTime = currentTime;
    }
}
