import java.util.ArrayList;
import java.util.Comparator;

public class LibraryItem {
    //Item variables
    private String item_id;
    private String item_type;
    private String item_title;
    private String item_category;
    private boolean is_borrowed;
    private String borrowed_date;
    private String borrowed_by;
    private static ArrayList<LibraryItem> itemList = new ArrayList<>();

    //Item Constructor
    LibraryItem(String item_id, String item_title, String item_category, String item_type){
        this.item_id = item_id;
        this.item_title = item_title;
        this.item_category = item_category;
        this.item_type = item_type;
        this.is_borrowed = false;
        itemList.add(this);
    }

    //Get Methods
    String getItem_id(){
        return item_id;
    }
    String getItem_type() {
        return item_type;
    }
    String getItem_title(){
        return item_title;
    }
    String getItem_category(){
        return item_category;
    }
    boolean getIs_borrowed(){
        return is_borrowed;
    }
    String getBorrowed_date(){
        return borrowed_date;
    }
    String getBorrowed_by(){
        return borrowed_by;
    }
    static ArrayList<LibraryItem> getItemList(){
        return itemList;
    }

    /*
    A method that finds the item by given Item Id
    */
    public static LibraryItem findItem(String id){
        //Search item in itemList using given item id
        for (LibraryItem item : itemList){
            if (id.equals(item.getItem_id())){
                return item;
            }
        }
        //Return null if item isn't found
        return null;
    }

    /*
    A method that modifies is_borrowed,borrowed_by,borrowed_date variables according to given name and date variables
    */
    void item_borrow(String name,String date){
        is_borrowed = true;
        borrowed_by = name;
        borrowed_date = date;
    }

    /*
    A method that resets is_borrowed,borrowed_by,borrowed_date variables
    */
    void item_return(){
        is_borrowed = false;
        borrowed_by = null;
        borrowed_date = null;
    }

    /*
    Template of a method for returning item information as a String
    */
    String getItemInfo(){
        return null;
    }

    /*
    A method that sorts given items by their id's and returns their information strings
    */
    public static String displayItems(){
        itemList.sort(Comparator.comparing(LibraryItem::getItem_id));
        String output = "\n";
        for (LibraryItem item : itemList){
            output += "\n" + item.getItemInfo();
        }
        return output;
    }
}

class Book extends LibraryItem{
    //Book Variables
    private String author;

    //Book Constructor
    Book(String item_id, String item_title, String author, String item_category, String item_type){
        super(item_id,item_title,item_category,item_type);
        this.author = author;
    }

    /*
    A method for returning book information as a String
    */
    @Override
    String getItemInfo(){
        //Case where book is borrowed
        if (getIs_borrowed()){
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Borrowed " + "Borrowed Date: " + getBorrowed_date() + " Borrowed by: " + getBorrowed_by() +
                    "\nAuthor: "+ author +" Genre: "+ getItem_category() + "\n");
        }
        //Case where book is available
        else{
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Available" +
                    "\nAuthor: "+ author +" Genre: "+ getItem_category() + "\n");
        }

    }
}

class Magazine extends LibraryItem{
    //Magazine Variables
    private String publisher;

    //Magazine Constructor
    Magazine(String item_id, String item_title, String publisher, String item_category, String item_type){
        super(item_id,item_title,item_category,item_type);
        this.publisher = publisher;
    }

    /*
    A method for returning magazine information as a String
    */
    @Override
    String getItemInfo(){
        //Case where magazine is borrowed
        if (getIs_borrowed()){
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Borrowed " + "Borrowed Date: " + getBorrowed_date() + " Borrowed by: " + getBorrowed_by() +
                    "\nPublisher: "+ publisher +" Category: "+ getItem_category() + "\n");
        }
        //Case where magazine is available
        else{
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Available" +
                    "\nPublisher: "+ publisher +" Category: "+ getItem_category() + "\n");
        }
    }
}

class DVD extends LibraryItem{
    //DVD Variables
    private String director;
    private String runtime;

    //DVD Constructor
    DVD(String item_id, String item_title, String director, String item_category, String runtime, String item_type){
        super(item_id,item_title,item_category,item_type);
        this.director = director;
        this.runtime = runtime;
    }

    /*
    A method for returning DVD information as a String
    */
    @Override
    String getItemInfo(){
        //Case where DVD is borrowed
        if (getIs_borrowed()){
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Borrowed " + "Borrowed Date: " + getBorrowed_date() + " Borrowed by: " + getBorrowed_by() +
                    "\nDirector: "+ director +" Category: "+ getItem_category() + " Runtime: " + runtime + "\n");
        }
        //Case where DVD is available
        else{
            return ("------ Item Information for " + getItem_id() + " ------\n" +
                    "ID: " + getItem_id() + " Name: " + getItem_title() + " Status: Available" +
                    "\nDirector: "+ director +" Category: "+ getItem_category() + " Runtime: " + runtime + "\n");
        }
    }
}