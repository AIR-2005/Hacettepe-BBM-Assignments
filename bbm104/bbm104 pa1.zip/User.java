import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class User {
    //User Variables
    private String user_id;
    private String user_name;
    private String phone_number;
    private int penalty;
    private final int MAX_ITEMS;
    private final int MAX_OVERDUE;
    private final String[] RESTRICTED_TYPES;
    private ArrayList<LibraryItem> borrowedItems = new ArrayList<>();
    private static ArrayList<User> userList = new ArrayList<>();

    //User Constructor
    User(String user_name, String user_id,String phone_number,int MAX_ITEMS,int MAX_OVERDUE, String[] RESTRICTED_TYPES){
        this.user_name = user_name;
        this.user_id = user_id;
        this.phone_number = phone_number;
        this.penalty = 0;
        this.MAX_ITEMS = MAX_ITEMS;
        this.MAX_OVERDUE = MAX_OVERDUE;
        this.RESTRICTED_TYPES = RESTRICTED_TYPES;
        userList.add(this);
    }

    //Get Methods
    String getUser_id(){
        return user_id;
    }
    String getUser_name(){
        return user_name;
    }
    String getUser_number(){
        return phone_number;
    }
    int getPenalty(){
        return penalty;
    }
    static ArrayList<User> getUserList(){
        return userList;
    }
    ArrayList<LibraryItem> getBorrowedItems(){
        return borrowedItems;
    }

    //Methods for applying and paying penalty
    void apply_penalty(){
        penalty += 2;
    }
    void pay_penalty(){
        penalty = 0;
    }

    /*
    A method that finds the user by given User Id
    */
    public static User findUser(String id){
        //Search user in userList using given user id
        for (User user : userList){
            if (id.equals(user.getUser_id())){
                return user;
            }
        }
        //Return null if user isn't found
        return null;
    }

    /*
    A method that applies penalties to users
    */
    private void penaltyCheck(){
        //Create a formatter to turn given date from String to LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //Compare each user's borrowed item's borrow date and current date
        for(User user : userList){
            //Create a copy of borrowedItems to prevent exceptions in the for loop when returning item
            ArrayList <LibraryItem> borrowed_Items = new ArrayList<>(user.getBorrowedItems());
            for (LibraryItem item : borrowed_Items){
                //If days between borrow date and current date are higher than overdue, apply penalty and return item
                if(ChronoUnit.DAYS.between(LocalDate.parse(item.getBorrowed_date(),formatter),LocalDate.now()) > MAX_OVERDUE){
                    user.apply_penalty();
                    user.return_borrowedItems(item);
                }
            }
        }
    }

    /*
    A method that checks conditions and borrows given item if it's possible
    */
    String add_borrowedItems(LibraryItem item,String date){
        //Do penalty check
        penaltyCheck();
        //Case where penalty is 6 or greater
        if (penalty >= 6){
            return user_name + " cannot borrow " + item.getItem_title() + ", you must first pay the penalty amount! 6$";
        }
        //Case where item isn't available
        else if (item.getIs_borrowed()) {
            return user_name + " cannot borrow " + item.getItem_title() + ", it is not available!";
        }
        //Case where item's type is restricted for user
        else if (Arrays.asList(RESTRICTED_TYPES).contains(item.getItem_type())){
            return user_name + " cannot borrow " + item.getItem_type() + " item!";
        }
        //Case where user has reached borrow limit for items
        else if (borrowedItems.size() >= MAX_ITEMS){
            return user_name + " cannot borrow " + item.getItem_title() + ", since the borrow limit has been reached!";
        }
        //If item can be borrowed
        else {
            borrowedItems.add(item);
            item.item_borrow(user_name,date);
            return user_name + " successfully borrowed! " + item.getItem_title();
        }
    }

    /*
    A method that returns the given item if it is borrowed
    */
    String return_borrowedItems(LibraryItem item){
        //Checks if item is available
        if (borrowedItems.contains(item)){
            borrowedItems.remove(item);
            item.item_return();
            return user_name + " successfully returned " + item.getItem_title();
        }
        //If item isn't in borrowedItems
        else {
            return user_name + " cannot return " + item.getItem_title() + ", because " + user_name + " doesn't have " + item.getItem_title();
        }
    }

    /*
    Template of a method for returning user information as a String
    */
    String getUserInfo(){
        return null;
    }

    /*
    A method that sorts given users by their id's and returns their information strings
    */
    public static String displayUsers(){
        userList.sort(Comparator.comparing(User::getUser_id));
        String output = "\n";
        for (User user : userList){
            output += "\n" + user.getUserInfo();
        }
        return output;
    }

}

class Student extends User{
    //Student Variables
    private String department;
    private String faculty;
    private String grade;
    private final static int STUDENT_MAX = 5;
    private final static int STUDENT_OVERDUE = 30;
    private final static String[] RESTRICTED_TYPES = {"reference"};

    //Student Constructor
    Student(String user_name, String user_id,String phone_number,String department,String faculty,String grade){
        super(user_name,user_id,phone_number,STUDENT_MAX,STUDENT_OVERDUE,RESTRICTED_TYPES);
        this.department = department;
        this.faculty = faculty;
        this.grade = grade;
    }

    /*
    A method for returning student information as a String
    */
    @Override
    String getUserInfo(){
        //Case where user has penalty
        if (getPenalty() > 0){
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    getUser_name() + " Phone: " + getUser_number() +
                    "\nFaculty: "+ faculty +" Department: "+ department
                    + " Grade: " + grade +"th" + "\n" + "Penalty: " + getPenalty() + "$\n");
        }
        //Case where user doesn't have penalty
        else {
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    getUser_name() + " Phone: " + getUser_number() +
                    "\nFaculty: "+ faculty +" Department: "+ department
                    + " Grade: " + grade +"th" + "\n");
        }
    }
}

class Academic extends User{
    //Academic Variables
    private String department;
    private String faculty;
    private String title;
    private final static  int ACADEMIC_MAX = 3;
    private final static  int ACADEMIC_OVERDUE = 15;
    private final static String[] RESTRICTED_TYPES = {};

    //Academic Constructor
    Academic(String user_name, String user_id,String phone_number,String department,String faculty,String title){
        super(user_name,user_id,phone_number,ACADEMIC_MAX,ACADEMIC_OVERDUE,RESTRICTED_TYPES);
        this.department = department;
        this.faculty = faculty;
        this.title = title;
    }

    /*
    A method for returning academic information as a String
    */
    @Override
    String getUserInfo(){
        //Case where user has penalty
        if (getPenalty() > 0){
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    title + " " + getUser_name() + " Phone: " + getUser_number() +
                    "\nFaculty: "+ faculty +" Department: "+ department + "\n" + "Penalty: " + getPenalty() + "$\n");
        }
        //Case where user doesn't have penalty
        else {
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    title + " " + getUser_name() + " Phone: " + getUser_number() +
                    "\nFaculty: "+ faculty +" Department: "+ department + "\n");
        }

    }
}

class Guest extends User{
    //Guest Variables
    private String occupation;
    private final static  int GUEST_MAX = 1;
    private final static  int GUEST_OVERDUE = 7;
    private final static String[] RESTRICTED_TYPES = {"rare","limited"};

    //Guest Constructor
    Guest(String user_name, String user_id,String phone_number,String occupation){
        super(user_name,user_id,phone_number,GUEST_MAX,GUEST_OVERDUE,RESTRICTED_TYPES);
        this.occupation = occupation;
    }

    /*
    A method for returning guest information as a String
    */
    @Override
    String getUserInfo(){
        //Case where user has penalty
        if (getPenalty() > 0){
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    getUser_name() + " Phone: " + getUser_number() +
                    "\nOccupation: "+ occupation  + "\n" + "Penalty: " + getPenalty() + "$\n");
        }
        //Case where user doesn't have penalty
        else {
            return ("------ User Information for " + getUser_id() + " ------\n" + "Name: " +
                    getUser_name() + " Phone: " + getUser_number() +
                    "\nOccupation: "+ occupation  + "\n");
        }
    }
}