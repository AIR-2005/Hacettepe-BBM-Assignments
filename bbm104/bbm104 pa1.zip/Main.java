import java.util.ArrayList;

public class Main {
    /*
    Main Method
    */
    public static void main(String[] args){
        LibraryManagementSystem.readItems(args[0]);
        LibraryManagementSystem.readUsers(args[1]);
        LibraryManagementSystem.readCommands(args[2],args[3]);
    }
}
