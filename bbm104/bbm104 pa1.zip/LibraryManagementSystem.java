import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

public class LibraryManagementSystem {
    /*
    A method that reads given item.txt and creates an ArrayList of Items
    */
    public static void readItems(String file){
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null){
                String[] parts = line.split(",");
                switch (parts[0]){
                    case "B":
                        Book book = new Book(parts[1],parts[2],parts[3],parts[4],parts[5]);
                        break;
                    case "M":
                        Magazine magazine = new Magazine(parts[1],parts[2],parts[3],parts[4],parts[5]);
                        break;
                    case "D":
                        DVD dvd = new DVD(parts[1],parts[2],parts[3],parts[4],parts[5],parts[6]);
                        break;
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
    A method that reads given users.txt and creates an ArrayList of Users
    */
    public static void readUsers(String file){
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while((line = br.readLine()) != null){
                String[] parts = line.split(",");
                switch (parts[0]){
                    case "S":
                        Student student = new Student(parts[1],parts[2],parts[3],parts[4],parts[5],parts[6]);
                        break;
                    case "A":
                        Academic academic = new Academic(parts[1],parts[2],parts[3],parts[4],parts[5],parts[6]);
                        break;
                    case "G":
                        Guest guest = new Guest(parts[1],parts[2],parts[3],parts[4]);
                        break;
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*
    A method that pays the given users penalties
    */
    public static String pay(String userId){
        User user = User.findUser(userId);
        if (user == null) {
            return "User " + userId + " can't be found";
        }
        else {
            user.pay_penalty();
            return user.getUser_name() + " has paid penalty\n";
        }
    }

    /*
    A method that borrows the given item by the given user
    */
    public static String borrowItem(String userId,String itemId,String date){
        User user = User.findUser(userId);
        LibraryItem item = LibraryItem.findItem(itemId);
        if (user == null){
            return null;
        }
        else{
            return user.add_borrowedItems(item,date);
        }
    }

    /*
    A method that returns the given item by the given user
    */
    public static String returnItem(String userId,String itemId){
        User user = User.findUser(userId);
        LibraryItem item = LibraryItem.findItem(itemId);
        if (user == null){
            return null;
        }
        else{
            return user.return_borrowedItems(item);
        }
    }

    /*
    A method that reads given commands.txt, executes the commands and writes the output of commands to the output.txt
    */
    public static void readCommands(String input_file,String output_file) {
        try (BufferedReader br = new BufferedReader(new FileReader(input_file)); FileWriter writer = new FileWriter(output_file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                switch (parts[0]) {
                    case "borrow":
                        writer.write(borrowItem(parts[1], parts[2], parts[3]) + "\n");
                        break;
                    case "return":
                        writer.write(returnItem(parts[1], parts[2]) + "\n");
                        break;
                    case "pay":
                        writer.write(pay(parts[1]));
                        break;
                    case "displayUsers":
                        writer.write(User.displayUsers());
                        break;
                    case "displayItems":
                        writer.write(LibraryItem.displayItems());
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
