import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class Program extends AcademicEntity{
    //Program Variables
    private Department department;
    private String degreeLevel;
    private int totalCredit;
    private ArrayList<Course> courses = new ArrayList<>();
    private static ArrayList<Program> programList = new ArrayList<>();

    //Program Constructor
    Program(String code, String name, String description, Department department, String degreeLevel, int totalCredit){
        super(code, name, description);
        this.department = department;
        this.degreeLevel = degreeLevel;
        this.totalCredit = totalCredit;
        programList.add(this);
    }

    //Get-Set Methods
    public void setCourse(Course course){
        courses.add(course);
    }

    /*
    A method that finds a Program object using its code
     */
    public static Program findProgram(String code) throws NonExistentProgram {
        for (Program program : programList){
            if (Objects.equals(program.getCode(), code)){
                return program;
            }
        }
        //Throw non-existent program error if can't find given code
        throw new NonExistentProgram(code);
    }

    /*
    A method that prints an output string for Program
     */
    @Override
    public String outputString() {
        String courseString;
        //Check if any courses available in Program and create a courseString accordingly
        if (courses.isEmpty()){
            courseString = "- ";
        }
        else {
            courseString = "{";
            for (Course course : courses){
                courseString += course.getCode() + ",";
            }
            courseString = courseString.substring(0, courseString.length() - 1) + "}";
        }

        return "Program Code: " + getCode() + "\n" +
                "Name: " + getName() + "\n" +
                "Department: " + department.getName() + "\n" +
                "Degree Level: " + degreeLevel + "\n" +
                "Required Credits: " + totalCredit + "\n" +
                "Courses: " + courseString + "\n\n";
    }

    /*
    A method that prints all Programs output String
     */
    public static String classOutputString(){
        programList.sort(Comparator.comparing(Program :: getCode));
        String output = "----------------------------------------\n" +
                "                PROGRAMS\n" +
                "----------------------------------------\n" ;
        for (Program program : programList){
            output += program.outputString();
        }
        return output + "----------------------------------------\n\n";
    }
}

