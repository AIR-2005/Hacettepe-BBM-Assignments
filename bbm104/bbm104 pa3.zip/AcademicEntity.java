public abstract class AcademicEntity implements IOutputString{
    //AcademicEntity Variables
    private String code;
    private String name;
    private String description;

    //AcademicEntity Constructor
    AcademicEntity(String code, String name, String description){
        this.code = code;
        this.name = name;
        this.description = description;
    }
    //Get-Set Methods
    public String getName(){
        return this.name;
    }
    public String getCode(){
        return this.code;
    }
    public String getDescription(){
        return this.description;
    }
}
