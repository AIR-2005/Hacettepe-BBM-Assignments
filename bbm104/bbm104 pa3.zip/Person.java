public abstract class Person implements IOutputString{
    //Person Variables
    private String id;
    private String name;
    private String email;
    private String department;

    //Person Constructor
    Person(String id, String name, String email, String department){
        this.id = id;
        this.name = name;
        this.email = email;
        this.department = department;
    }

    //Get-Set Methods
    public String getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public String getDepartment(){
        return department;
    }

}
