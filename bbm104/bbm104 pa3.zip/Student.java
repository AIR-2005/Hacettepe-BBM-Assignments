import java.util.*;

public class Student extends Person implements IReportOutput{
    //Student Variables
    private LinkedHashMap<Course, String> enrolledCourses = new LinkedHashMap<>();
    private LinkedHashMap<Course, String> completedCourses = new LinkedHashMap<>();
    private static ArrayList<Student> studentList = new ArrayList<>();

    //Student Constructor
    Student(String id, String name, String email, String department){
        super(id, name, email, department);
        studentList.add(this);
    }

    //Get-Set Methods
    public static ArrayList<Student> getStudentList(){
        return studentList;
    }
    public LinkedHashMap<Course, String> getCompletedCourses(){
        return completedCourses;
    }
    public void setCourses(Course course){
        enrolledCourses.put(course, "");
    }
    public void setStudentGrade(Course course, String grade){
        enrolledCourses.remove(course);
        completedCourses.put(course, grade);
    }

    /*
    A method that finds a Student object using its id
     */
    public static Student findStudent(String id) throws NonExistentStudent {
        for (Student student : studentList){
            if (Objects.equals(student.getId(), id)){
                return student;
            }
        }
        //Throw non-existent student error if can't find given id
        throw new NonExistentStudent(id);
    }

    /*
    A method that prints an output string for Student
     */
    @Override
    public String outputString(){
        return "Student ID: " + getId() + "\n" +
                "Name: " + getName() + "\n" +
                "Email: " + getEmail() + "\n" +
                "Major: " + getDepartment() + "\n" +
                "Status: Active\n\n";
    }

    /*
    A method that prints all Students output String
     */
    public static String classOutputString(){
        studentList.sort(Comparator.comparing(Student :: getId));
        String output = "----------------------------------------\n" +
                        "                STUDENTS\n" +
                        "----------------------------------------\n" ;
        for (Student student : studentList){
            output += student.outputString();
        }
        return output + "----------------------------------------\n\n";
    }

    /*
    A method that returns Student report as a string
     */
    @Override
    public String courseReport(){
        String output = "";
        output += outputString() + "\n";
        output += "Enrolled Courses:\n";
        for (Course course: enrolledCourses.keySet()){
            output += "- " + course.getName() + " (" + course.getCode() + ")\n";
        }
        output += "\nCompleted Courses:\n";
        for (Course course: completedCourses.keySet()){
            output += "- " + course.getName() + " (" + course.getCode() + "): " + completedCourses.get(course) + "\n";
        }
        return output;
    }

}
