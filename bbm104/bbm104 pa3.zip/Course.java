import java.util.*;

public class Course extends AcademicEntity implements IReportOutput{
    //Course Variables
    private int credit;
    private String semester;
    private String department;
    private AcademicMember instructor;
    private LinkedHashMap<Student,String> enrolledStudents = new LinkedHashMap<Student, String>();
    private static ArrayList<Course> courseList = new ArrayList<>();

    //Course Constructor
    Course(String code, String name, String department, int credit, String semester, Program program) {
        super(code, name, "");
        this.department = department;
        this.credit = credit;
        this.semester = semester;
        program.setCourse(this);
        courseList.add(this);
    }

    //Get-Set Methods
    public int getCredit(){
        return credit;
    }
    public static ArrayList<Course> getCourseList(){
        return courseList;
    }
    public LinkedHashMap<Student, String> getEnrolledStudents(){
        return enrolledStudents;
    }
    public void setInstructor(AcademicMember instructor){
        this.instructor = instructor;
    }
    public void setEnrolledStudents(Student student){
        enrolledStudents.put(student, "");
    }
    public void setStudentGrade(Student student, String grade){
        enrolledStudents.replace(student, grade);
    }

    /*
    A method that finds a Course object using its code
     */
    public static Course findCourse(String code) throws NonExistentCourse {
        for (Course course : courseList){
            if (Objects.equals(course.getCode(), code)){
                return course;
            }
        }
        //Throw non-existent course error if can't find code
        throw new NonExistentCourse(code);
    }

    /*
    A method that prints an output string for Course
     */
    @Override
    public String outputString() {
        return "Course Code: " + getCode() + "\n" +
                "Name: " + getName() + "\n" +
                "Department: " + department + "\n" +
                "Credits: " + credit + "\n" +
                "Semester: " + semester + "\n\n";
    }

    /*
    A method that prints all Courses output String
     */
    public static String classOutputString(){
        courseList.sort(Comparator.comparing(Course :: getCode));
        String output = "----------------------------------------\n" +
                "                COURSES\n" +
                "----------------------------------------\n" ;
        for (Course course : courseList){
            output += course.outputString();
        }
        return output + "----------------------------------------\n\n";
    }

    /*
    A method that returns Course report as a string
     */
    @Override
    public String courseReport(){
        String output = "";
        output += outputString();
        if (instructor == null){
            output += "Instructor: Not assigned" + "\n\n";
        }
        else{
            output += "Instructor: " + instructor.getName() + "\n\n";
        }
        output += "Enrolled Students:\n";
        for (Student student: enrolledStudents.keySet()){
            output += "- " + student.getName() + " (ID: " + student.getId() + ")\n";
        }
        return output;
    }

}
