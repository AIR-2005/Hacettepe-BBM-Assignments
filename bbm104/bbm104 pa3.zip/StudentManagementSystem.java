import java.io.*;
import java.util.*;

public class StudentManagementSystem {

    /*
    A method that returns a grade letters 4 point equivalent
     */
    public double gradeLetterToPoint(String gradeLetter) throws InvalidGrade {
        switch (gradeLetter){
            case "A1":
                return 4;
            case "A2":
                return 3.5;
            case "B1":
                return 3;
            case "B2":
                return 2.5;
            case "C1":
                return 2;
            case "C2":
                return 1.5;
            case "D1":
                return 1;
            case "D2":
                return 0.5;
            case "F3":
                return 0;
            default:
                //Throw InvalidGrade if grade letter is invalid
                throw new InvalidGrade(gradeLetter);
        }
    }

    /*
    A method that reads person.txt and creates Person Objects
     */
    public void readPerson(String inputFile, String outputFile){
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));FileWriter writer = new FileWriter(outputFile)){
            writer.write("Reading Person Information \n");
            String line;
            while ((line = reader.readLine()) != null) {
                //Create new Person objects according to input file
                try {
                    String[] parts = line.split(",");
                    switch (parts[0]) {
                        case "S":
                            new Student(parts[1], parts[2], parts[3], parts[4]);
                            break;
                        case "F":
                            new AcademicMember(parts[1], parts[2], parts[3], parts[4]);
                            break;
                        //Throw an InvalidPersonType exception if person type is invalid
                        default:
                            throw new InvalidPersonType();
                    }
                }
                catch (InvalidPersonType e){
                    writer.write(e.getMessage() + "\n");
                }
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    /*
    A method that reads departments.txt and creates Department Objects
     */
    public void readDepartment(String inputFile, String outputFile){
        try (FileWriter writer = new FileWriter(outputFile,true); BufferedReader reader = new BufferedReader(new FileReader(inputFile))){
            writer.write("Reading Departments \n");
            String line;
            while ((line = reader.readLine()) != null){
                //Create new Department objects according to input file
                try{
                    String[] parts = line.split(",");
                    new Department(parts[0], parts[1], parts[2]).setHead(AcademicMember.findAcademicMember(parts[3]));
                }
                catch (NonExistentAcademicMember e){
                    writer.write(e.getMessage() + "\n");
                }
            }
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    A method that reads programs.txt and creates Program Objects
     */
    public void readProgram(String inputFile, String outputFile){
        try (FileWriter writer = new FileWriter(outputFile,true); BufferedReader reader = new BufferedReader(new FileReader(inputFile))){
            writer.write("Reading Programs \n");
            String line;
            while ((line = reader.readLine()) != null){
                //Create new Program objects according to input file
                try {
                    String[] parts = line.split(",");
                    new Program(parts[0], parts[1], parts[2], Department.findDepartment(parts[3]), parts[4], Integer.parseInt(parts[5]));
                }
                catch (NonExistentDepartment e){
                    writer.write(e.getMessage() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    A method that reads courses.txt and creates Course Objects
     */
    public void readCourses(String inputFile, String outputFile){
        try (FileWriter writer = new FileWriter(outputFile,true); BufferedReader reader = new BufferedReader(new FileReader(inputFile))){
            writer.write("Reading Courses \n");
            String line;
            while ((line = reader.readLine()) != null){
                //Create new Course objects according to input file
                try {
                    String[] parts = line.split(",");
                    new Course(parts[0], parts[1], parts[2], Integer.parseInt(parts[3]), parts[4], Program.findProgram(parts[5]));
                }
                catch (NonExistentProgram e){
                    writer.write(e.getMessage() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    A method that reads assignments.txt and assigns Instructors or Students/Courses accordingly
     */
    public void readAssignments(String inputFile, String outputFile) {
        try (FileWriter writer = new FileWriter(outputFile,true); BufferedReader reader = new BufferedReader(new FileReader(inputFile))){
            writer.write("Reading Course Assignments \n");
            String line;
            while ((line = reader.readLine()) != null) {
                //Assign persons to their courses according to input file
                try {
                    String[] parts = line.split(",");
                    AcademicMember instructor;
                    Course course;
                    Student student;
                    switch (parts[0]) {
                        case "F":
                            instructor = AcademicMember.findAcademicMember(parts[1]);
                            course = Course.findCourse(parts[2]);
                            course.setInstructor(instructor);
                            break;
                        case "S":
                            student = Student.findStudent(parts[1]);
                            course = Course.findCourse(parts[2]);
                            student.setCourses(course);
                            course.setEnrolledStudents(student);
                            break;
                    }
                }
                catch (NonExistentStudent e){
                    writer.write(e.getMessage() + "\n");
                }
                catch (NonExistentAcademicMember e){
                    writer.write(e.getMessage() + "\n");
                }
                catch (NonExistentCourse e){
                    writer.write(e.getMessage() + "\n");
                }
            }
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    A method that reads grades.txt and assigns grades to Student/Course
     */
    public void readGrades(String inputFile, String outputFile){
        try (FileWriter writer = new FileWriter(outputFile, true); BufferedReader reader = new BufferedReader(new FileReader(inputFile))){
            writer.write("Reading Grades \n");
            String line;
            String[] gradeList = {"A1", "A2", "B1", "B2", "C1", "C2", "D1", "D2", "F3"};
            while ((line = reader.readLine()) != null){
                //Assign grades according to input file
                try {
                    String[] parts = line.split(",");
                    String gradeLetter = parts[0];
                    Student student = Student.findStudent(parts[1]);
                    Course course = Course.findCourse(parts[2]);
                    //Check if grade letter is valid
                    if (Arrays.asList(gradeList).contains(gradeLetter)){
                        student.setStudentGrade(course, gradeLetter);
                        course.setStudentGrade(student, gradeLetter);
                    }
                    else {
                        throw new InvalidGrade(gradeLetter);
                    }
                }
                catch (NonExistentStudent e){
                    writer.write(e.getMessage() + "\n");
                }
                catch (NonExistentCourse e){
                    writer.write(e.getMessage() + "\n");
                }
                catch (InvalidGrade e) {
                    writer.write(e.getMessage() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    A method that returns all Student Objects reports as a string
     */
    public String allStudentsReport() throws InvalidGrade {
        //Initialize Variables
        HashMap<Course, String> completedCourses;
        double courseGrade;
        int courseCredit;
        double totalGrade;
        int totalCredit;
        double gpa;
        ArrayList<Student> studentList = Student.getStudentList();
        studentList.sort(Comparator.comparing(Student :: getId));
        String output = "----------------------------------------\n" +
                "            STUDENT REPORTS\n" +
                "----------------------------------------\n";

        for (Student student : studentList){
            //Add student's report to output
            output += student.courseReport();
            totalGrade = 0;
            totalCredit = 0;
            completedCourses = student.getCompletedCourses();

            //Check every completed course and add their credits and grades to according variables
            for (Course course : completedCourses.keySet()){
                courseCredit = course.getCredit();
                courseGrade = gradeLetterToPoint(completedCourses.get(course));
                totalGrade +=  courseCredit * courseGrade;
                totalCredit += courseCredit;
            }

            //Check if total credit or total grade is 0
            if (totalCredit != 0 && totalGrade != 0){
                gpa = totalGrade / totalCredit;
            }
            else {
                gpa = 0;
            }

            output += String.format(Locale.US, "\nGPA: %.2f\n", gpa);
            output += "----------------------------------------\n\n";
        }
        return output;
    }

    /*
    A method that returns all Course Objects reports as a string
     */
    public String allCoursesReport() throws InvalidGrade {
        //Initialize Variables
        LinkedHashMap<Student, String> enrolledStudents;
        double courseGrade;
        double totalGrade;
        int totalStudent;
        double averageGrade;
        String gradeLetter;
        HashMap<String, Integer> gradeDistribution = new HashMap<>();
        ArrayList<Course> courseList = Course.getCourseList();
        courseList.sort(Comparator.comparing(Course :: getCode));
        String output = "----------------------------------------\n" +
                "             COURSE REPORTS\n" +
                "----------------------------------------\n";

        for (Course course : courseList){
            //Clear grade distribution to make sure each grade distribution is printed correctly
            gradeDistribution.clear();
            //Add course's report to output
            output += course.courseReport();
            totalGrade = 0;
            totalStudent = 0;
            enrolledStudents = course.getEnrolledStudents();

            for (Student student : enrolledStudents.keySet()){
                courseGrade = 0;
                gradeLetter = enrolledStudents.get(student);
                //Check if student has a grade letter
                if (!Objects.equals(gradeLetter, "")){
                    //Check if gradeDistribution has gradeLetter assigned to it
                    if (gradeDistribution.get(gradeLetter) == null){
                        gradeDistribution.put(gradeLetter, 1);
                    }
                    else{
                        gradeDistribution.replace(gradeLetter, gradeDistribution.get(gradeLetter) + 1);
                    }
                    //Get 4 point grade using grade letter
                    courseGrade = gradeLetterToPoint(enrolledStudents.get(student));
                }
                //Add course grade to total grade and increase total student by 1
                totalGrade +=  courseGrade;
                totalStudent += 1;
            }

            //Check if total student or total grade is 0
            if (totalStudent != 0 && totalGrade != 0){
                averageGrade = totalGrade / totalStudent;
            }
            else {
                averageGrade = 0;
            }

            output += "\nGrade Distribution:\n";
            //Put grade distribution to a TreeMap to sort it
            TreeMap<String, Integer> sortedGradeDistribution = new TreeMap<>(gradeDistribution);
            //Add every letter and their number in grade distribution to output
            for (String letter : sortedGradeDistribution.keySet()){
                output += letter + ": " + gradeDistribution.get(letter) + "\n";
            }

            output += String.format(Locale.US, "\nAverage Grade: %.2f\n\n", averageGrade);
            output += "----------------------------------------\n\n";
        }
        return output;
    }

    /*
    A method that executes all read methods
     */
    public void readAllFiles(String personFile, String departmentFile, String programFile, String courseFile, String assignFile, String gradeFile, String outputFile){
        readPerson(personFile, outputFile);
        readDepartment(departmentFile, outputFile);
        readProgram(programFile, outputFile);
        readCourses(courseFile, outputFile);
        readAssignments(assignFile, outputFile);
        readGrades(gradeFile, outputFile);
    }

    /*
    A method that writes all classes output strings to output file
     */
    public void outputAllClasses(String outputFile){
        try (FileWriter writer = new FileWriter(outputFile, true)){
            writer.write(AcademicMember.classOutputString());
            writer.write(Student.classOutputString());
            writer.write(Department.classOutputString());
            writer.write(Program.classOutputString());
            writer.write(Course.classOutputString());
        }
        catch (IOException e){
            throw new RuntimeException(e);
        }
    }

    /*
    A method that writes all reports to output file
     */
    public void outputAllReports(String outputFile){
        try (FileWriter writer = new FileWriter(outputFile, true)){
            try{
                writer.write(allCoursesReport());
                writer.write(allStudentsReport());
            }
            catch (InvalidGrade e){
                writer.write(e.getMessage() + "\n");
            }
        }
        catch (IOException e){
            throw new RuntimeException(e);
        }
    }
}
