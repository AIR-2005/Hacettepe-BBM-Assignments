import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class AcademicMember extends Person{
    //AcademicMember Variables
    private static ArrayList<AcademicMember> memberList = new ArrayList<>();

    //AcademicMember Constructor
    AcademicMember(String id, String name, String email, String department){
        super(id, name, email, department);
        memberList.add(this);
    }

    /*
    A method that finds an AcademicMember object using its id
     */
    public static AcademicMember findAcademicMember(String id) throws NonExistentAcademicMember {
        for (AcademicMember member : memberList){
            if (Objects.equals(member.getId(), id)){
                return member;
            }
        }
        //Throw non-existent AcademicMember error if can't find given id
        throw new NonExistentAcademicMember(id);
    }

    /*
    A method that prints an output string for AcademicMember
     */
    @Override
    public String outputString(){
        return "Faculty ID: " + getId() + "\n" +
                "Name: " + getName() + "\n" +
                "Email: " + getEmail() + "\n" +
                "Department: " + getDepartment() + "\n\n";
    }

    /*
    A method that prints all AcademicMembers output String
     */
    public static String classOutputString(){
        memberList.sort(Comparator.comparing(AcademicMember :: getId));
        String output = "----------------------------------------\n" +
                "            Academic Members\n" +
                "----------------------------------------\n" ;
        for (AcademicMember member : memberList){
            output += member.outputString();
        }
        return output + "----------------------------------------\n\n";
    }


}
