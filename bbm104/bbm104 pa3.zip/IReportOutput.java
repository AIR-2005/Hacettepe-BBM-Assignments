public interface IReportOutput {
    /*
    A method that returns a report as a string
     */
    public String courseReport();
}
