public class Main {
    /*
    Main Method
     */
    public static void main(String[] args){
        //Create a StudentManagementSystem object and read all files, output all classes and output all reports using it
        StudentManagementSystem std = new StudentManagementSystem();
        std.readAllFiles(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
        std.outputAllClasses(args[6]);
        std.outputAllReports(args[6]);
    }
}
