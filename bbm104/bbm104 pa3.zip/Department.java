import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class Department extends AcademicEntity{
    //Department Variables
    private AcademicMember head;
    private static ArrayList<Department> departmentList = new ArrayList<>();

    //Department Constructor
    Department(String code, String name, String description){
        super(code, name, description);
        departmentList.add(this);
    }

    //Get-Set Methods
    public void setHead(AcademicMember head){
        this.head = head;
    }

    /*
    A method that finds a Department object using its name
     */
    public static Department findDepartment(String name) throws NonExistentDepartment {
        for (Department department : departmentList){
            if (Objects.equals(department.getName(), name)){
                return department;
            }
        }
        //Throw non-existent department error if can't find given name
        throw new NonExistentDepartment(name);
    }

    /*
    A method that prints an output string for Department
     */
    @Override
    public String outputString(){
        String headString;
        if (head == null){
            headString = "Not assigned";
        }
        else {
            headString = head.getName();
        }
        return "Department Code: " + getCode() + "\n" +
                "Name: " + getName() + "\n" +
                "Head: " + headString + "\n\n";
    }

    /*
    A method that prints all Departments output String
     */
    public static String classOutputString(){
        departmentList.sort(Comparator.comparing(Department :: getName));
        String output = "----------------------------------------\n" +
                "              DEPARTMENTS\n" +
                "----------------------------------------\n" ;
        for (Department department : departmentList){
            output += department.outputString();
        }
        return output + "----------------------------------------\n\n";
    }
}
