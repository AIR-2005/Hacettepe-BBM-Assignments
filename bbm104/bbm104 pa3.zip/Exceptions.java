class InvalidPersonType extends Exception{
    InvalidPersonType(){
        super("Invalid Person Type");
    }
}
class InvalidGrade extends Exception{
    InvalidGrade(String grade){
        super("The grade " + grade + " is not valid");
    }
}
class NonExistentStudent extends Exception{
    NonExistentStudent(String id){
        super("Student Not Found with ID " + id);
    }
}
class NonExistentAcademicMember extends Exception{
    NonExistentAcademicMember(String id){
        super("Academic Member Not Found with ID " + id);
    }
}
class NonExistentDepartment extends Exception{
    NonExistentDepartment(String name){
        super("Department " + name + " Not Found");
    }
}
class NonExistentProgram extends Exception{
    NonExistentProgram(String code){
        super("Program " + code + " Not Found");
    }
}
class NonExistentCourse extends Exception{
    NonExistentCourse(String code){
        super("Course " + code + " Not Found");
    }
}

