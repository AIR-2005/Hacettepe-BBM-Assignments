public interface IOutputString {
    /*
    A method that prints an output string
     */
    public String outputString();
}
